import fs from 'fs';

let content = fs.readFileSync('src/App.tsx', 'utf8');

const replaceBlock2 = `          const chunkOffset = chunk.startTimeSeconds;

          const processedCues: SubtitleCue[] = (data.subtitles || []).map(
            (cue: SubtitleCue, cueIdx: number) => {
              const relStartSec = typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds) ? cue.startSeconds : srtTimeToSeconds(cue.start);
              const relEndSec = typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds) ? cue.endSeconds : srtTimeToSeconds(cue.end);

              const absStartSec = relStartSec + chunkOffset;
              const absEndSec = relEndSec + chunkOffset;

              return {
                ...cue,
                id: Date.now() + i * 1000 + cueIdx,
                startSeconds: absStartSec,
                endSeconds: absEndSec,
                start: secondsToSrtTime(absStartSec),
                end: secondsToSrtTime(absEndSec),
              };
            }
          );

          allCues = [...allCues, ...processedCues];`;

const newBlock2 = `          const chunkOffset = sliceStartSec; // Use extended slice offset

          let processedCues: SubtitleCue[] = (data.subtitles || []).map(
            (cue: SubtitleCue, cueIdx: number) => {
              const relStartSec = typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds) ? cue.startSeconds : srtTimeToSeconds(cue.start);
              const relEndSec = typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds) ? cue.endSeconds : srtTimeToSeconds(cue.end);

              const absStartSec = relStartSec + chunkOffset;
              const absEndSec = relEndSec + chunkOffset;

              return {
                ...cue,
                id: Date.now() + i * 1000 + cueIdx,
                startSeconds: absStartSec,
                endSeconds: absEndSec,
                start: secondsToSrtTime(absStartSec),
                end: secondsToSrtTime(absEndSec),
              };
            }
          );

          // Filter out overlapping cues at boundaries
          processedCues = processedCues.filter(cue => {
              const mid = (cue.startSeconds + cue.endSeconds) / 2;
              const meetsStart = isFirstChunk ? true : mid >= chunk.startTimeSeconds;
              const meetsEnd = isLastChunk ? true : mid < chunk.endTimeSeconds;
              return meetsStart && meetsEnd;
          });

          allCues = [...allCues, ...processedCues];`;


const replaceBlock4 = `      const chunkOffset = chunk.startTimeSeconds;

      const processedCues: SubtitleCue[] = (data.subtitles || []).map(
        (cue: SubtitleCue, cueIdx: number) => {
          const relStartSec = typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds) ? cue.startSeconds : srtTimeToSeconds(cue.start);
          const relEndSec = typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds) ? cue.endSeconds : srtTimeToSeconds(cue.end);

          const absStartSec = relStartSec + chunkOffset;
          const absEndSec = relEndSec + chunkOffset;

          return {
            ...cue,
            id: Date.now() + chunkIndex * 1000 + cueIdx,
            startSeconds: absStartSec,
            endSeconds: absEndSec,
            start: secondsToSrtTime(absStartSec),
            end: secondsToSrtTime(absEndSec),
          };
        }
      );

      setChunks((prev) =>`;

const newBlock4 = `      const chunkOffset = sliceStartSec;

      let processedCues: SubtitleCue[] = (data.subtitles || []).map(
        (cue: SubtitleCue, cueIdx: number) => {
          const relStartSec = typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds) ? cue.startSeconds : srtTimeToSeconds(cue.start);
          const relEndSec = typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds) ? cue.endSeconds : srtTimeToSeconds(cue.end);

          const absStartSec = relStartSec + chunkOffset;
          const absEndSec = relEndSec + chunkOffset;

          return {
            ...cue,
            id: Date.now() + chunkIndex * 1000 + cueIdx,
            startSeconds: absStartSec,
            endSeconds: absEndSec,
            start: secondsToSrtTime(absStartSec),
            end: secondsToSrtTime(absEndSec),
          };
        }
      );

      processedCues = processedCues.filter(cue => {
          const mid = (cue.startSeconds + cue.endSeconds) / 2;
          const meetsStart = isFirstChunk ? true : mid >= chunk.startTimeSeconds;
          const meetsEnd = isLastChunk ? true : mid < chunk.endTimeSeconds;
          return meetsStart && meetsEnd;
      });

      setChunks((prev) =>`;

content = content.replace(replaceBlock2, newBlock2);
content = content.replace(replaceBlock4, newBlock4);

fs.writeFileSync('src/App.tsx', content);

