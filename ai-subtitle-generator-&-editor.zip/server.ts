import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import multer from 'multer';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';

dotenv.config();

import os from 'os';
import { execSync, spawn } from 'child_process';

function findFFmpegBinary(): string {
  if (process.env.FFMPEG_PATH && fs.existsSync(process.env.FFMPEG_PATH)) {
    return process.env.FFMPEG_PATH;
  }
  if (process.platform === 'win32') {
    const commonPaths = [
      'C:\\ffmpeg\\bin\\ffmpeg.exe',
      'C:\\Program Files\\ffmpeg\\bin\\ffmpeg.exe',
      'C:\\Program Files (x86)\\ffmpeg\\bin\\ffmpeg.exe',
      path.join(process.cwd(), 'bin', 'ffmpeg.exe'),
      path.join(process.cwd(), 'ffmpeg.exe'),
    ];
    for (const p of commonPaths) {
      if (fs.existsSync(p)) return p;
    }
  }
  return 'ffmpeg';
}

function testEncoder(encoder: string): Promise<boolean> {
  return new Promise((resolve) => {
    if (encoder === 'libx264') return resolve(true);

    const ffmpegBin = process.env.FFMPEG_PATH || findFFmpegBinary();
    const testProc = spawn(ffmpegBin, [
      '-f', 'lavfi',
      '-i', 'color=c=black:s=640x480:d=0.1',
      '-c:v', encoder,
      '-f', 'null',
      '-'
    ]);

    testProc.on('close', (code) => {
      resolve(code === 0);
    });

    testProc.on('error', () => {
      resolve(false);
    });
  });
}

async function getTestedOptimalVideoEncoder(): Promise<string> {
  const candidates = ['h264_nvenc', 'h264_amf', 'h264_qsv', 'libx264'];
  for (const candidate of candidates) {
    const works = await testEncoder(candidate);
    if (works) {
      console.log(`[FFmpeg Encoder] Verified candidate '${candidate}' works.`);
      return candidate;
    }
  }
  return 'libx264';
}



function formatSrtTime(sec: number): string {
  if (isNaN(sec) || sec < 0) sec = 0;
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  const ms = Math.floor((sec % 1) * 1000);
  const p = (n: number, sz = 2) => String(n).padStart(sz, '0');
  return `${p(h)}:${p(m)}:${p(s)},${p(ms, 3)}`;
}

function sanitizeCuesServer(cues: any[], maxChars = 42): any[] {
  if (!Array.isArray(cues)) return [];

  const sanitized: any[] = [];

  for (const item of cues) {
    let startSec = typeof item.startSeconds === 'number' && !isNaN(item.startSeconds) ? item.startSeconds : 0;
    let endSec = typeof item.endSeconds === 'number' && !isNaN(item.endSeconds) ? item.endSeconds : 0;

    if (startSec < 0) startSec = 0;

    // Clean inline speaker prefix like "[speaker 1]: " if present in text
    let origText = String(item.text_original || '').replace(/^\[speaker\s*\d+\]:\s*/i, '').trim();
    let transText = String(item.text_translated || '').replace(/^\[speaker\s*\d+\]:\s*/i, '').trim();

    // Fix inverted or zero timestamps (start >= end)
    if (endSec <= startSec) {
      const charCount = Math.max(origText.length, transText.length, 10);
      const estDuration = Math.max(1.8, Math.min(8.0, charCount / 16));
      endSec = startSec + estDuration;
    }

    // Auto-split long sentences (> 85 chars)
    if (origText.length > 85 || transText.length > 85) {
      const transSentences = transText.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);
      const origSentences = origText.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);

      if (transSentences.length > 1) {
        const totalDuration = endSec - startSec;
        const count = transSentences.length;
        const segDur = totalDuration / count;

        for (let i = 0; i < count; i++) {
          const sStart = startSec + i * segDur;
          const sEnd = sStart + segDur;
          sanitized.push({
            startSeconds: Number(sStart.toFixed(3)),
            endSeconds: Number(sEnd.toFixed(3)),
            start: formatSrtTime(sStart),
            end: formatSrtTime(sEnd),
            speaker: item.speaker || null,
            text_original: origSentences[i] || origText,
            text_translated: transSentences[i] || transText,
          });
        }
        continue;
      }
    }

    sanitized.push({
      startSeconds: Number(startSec.toFixed(3)),
      endSeconds: Number(endSec.toFixed(3)),
      start: formatSrtTime(startSec),
      end: formatSrtTime(endSec),
      speaker: item.speaker || null,
      text_original: origText,
      text_translated: transText,
    });
  }

  sanitized.sort((a, b) => a.startSeconds - b.startSeconds);
  return sanitized;
}

function pcmBase64ToWavBase64(base64Pcm: string, sampleRate = 24000, numChannels = 1): string {
  const pcmBuffer = Buffer.from(base64Pcm, 'base64');
  if (pcmBuffer.length > 12 && pcmBuffer.toString('utf8', 0, 4) === 'RIFF') {
    return base64Pcm;
  }

  const dataSize = pcmBuffer.length;
  const header = Buffer.alloc(44);

  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);

  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(sampleRate * numChannels * 2, 28);
  header.writeUInt16LE(numChannels * 2, 32);
  header.writeUInt16LE(16, 34);

  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  const wavBuffer = Buffer.concat([header, pcmBuffer]);
  return wavBuffer.toString('base64');
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set large JSON body parser limits for base64 audio payloads
  app.use(express.json({ limit: '150mb' }));
  app.use(express.urlencoded({ limit: '150mb', extended: true }));

  // Initialize Gemini Client
  const getGeminiClient = () => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('GEMINI_API_KEY is not configured in environment.');
    }
    return new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  };

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  });

  // System & Runtime Info Endpoint
  app.get('/api/runtime-info', async (req, res) => {
    try {
      const isWindows = process.platform === 'win32';
      const ffmpegBin = process.env.FFMPEG_PATH || findFFmpegBinary();

      let ffmpegVersion = 'Unknown';
      try {
        const verOutput = execSync(`"${ffmpegBin}" -version`, { encoding: 'utf-8' });
        ffmpegVersion = verOutput.split('\n')[0] || 'Unknown';
      } catch (e: any) {
        ffmpegVersion = 'FFmpeg binary not accessible in PATH';
      }

      const activeEncoder = await getTestedOptimalVideoEncoder();
      const cpus = os.cpus();
      const cpuModel = cpus && cpus.length > 0 ? cpus[0].model : 'Unknown CPU';
      const totalMemMB = Math.round(os.totalmem() / (1024 * 1024));
      const freeMemMB = Math.round(os.freemem() / (1024 * 1024));

      res.json({
        runtime: isWindows ? 'Local Windows Runtime' : 'Cloud Linux (Cloud Run Container)',
        isCloud: !isWindows,
        os: `${process.platform} (${os.release()})`,
        arch: process.arch,
        ffmpegPath: ffmpegBin,
        ffmpegVersion,
        activeEncoder,
        hardwareAcceleration: activeEncoder !== 'libx264' ? 'Enabled (GPU)' : 'Software (CPU multi-thread)',
        cpuModel,
        cpuCores: cpus.length,
        memory: `${freeMemMB} MB free / ${totalMemMB} MB total`,
      });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Custom Local FFmpeg Path Endpoint
  app.post('/api/settings/ffmpeg-path', (req, res) => {
    try {
      const { customPath } = req.body;
      if (!customPath || typeof customPath !== 'string') {
        return res.status(400).json({ error: 'customPath string parameter is required' });
      }
      if (!fs.existsSync(customPath)) {
        return res.status(404).json({ error: `Path "${customPath}" does not exist on server.` });
      }

      process.env.FFMPEG_PATH = customPath;
      ffmpeg.setFfmpegPath(customPath);
      res.json({ success: true, ffmpegPath: customPath });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Fast Instant Language & Audio Detection Endpoint
  app.post('/api/detect-language', async (req, res) => {
    try {
      const { audioBase64, mimeType = 'audio/wav' } = req.body;

      if (!audioBase64) {
        return res.status(400).json({ error: 'audioBase64 parameter is required' });
      }

      const ai = getGeminiClient();

      const systemInstruction = `You are an expert audio linguist and speech recognition engineer.
Analyze the provided audio sample (first 10-20 seconds) and perform instant language identification and audio diagnostics.

Return strict JSON with:
1. "detectedLanguage": Full language name in English (e.g. "English", "Vietnamese", "Japanese", "Spanish", "Chinese")
2. "isoCode": ISO 639-1 two-letter code (e.g. "en", "vi", "ja", "es", "zh")
3. "confidence": Number from 0.0 to 1.0 indicating confidence score
4. "dialect": Region/accent or dialect if applicable (e.g. "American Accent", "Northern Vietnamese Accent", "Standard Mandarin")
5. "speechSpeed": Speech pace e.g. "Fast", "Normal", "Slow"
6. "audioQuality": Audio clarity e.g. "High Quality", "Moderate Noise", "Background Music Present"
7. "sampleTranscription": Exact transcription of the first 1-2 spoken sentences in original language
8. "hasSpeech": Boolean true if speech is heard`;

      const cascadeModels = ['gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'];

      const { result: response, modelUsed } = await callGeminiWithCascade(cascadeModels, (modelName) =>
        ai.models.generateContent({
          model: modelName,
          contents: [
            {
              inlineData: { mimeType, data: audioBase64 },
            },
            {
              text: 'Detect the primary spoken language, dialect, audio quality, and transcribe a 2-sentence preview sample.',
            },
          ],
          config: {
            systemInstruction,
            temperature: 0.1,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                detectedLanguage: { type: Type.STRING },
                isoCode: { type: Type.STRING },
                confidence: { type: Type.NUMBER },
                dialect: { type: Type.STRING },
                speechSpeed: { type: Type.STRING },
                audioQuality: { type: Type.STRING },
                sampleTranscription: { type: Type.STRING },
                hasSpeech: { type: Type.BOOLEAN },
              },
              required: ['detectedLanguage', 'isoCode', 'confidence', 'sampleTranscription', 'hasSpeech'],
            },
          },
        })
      );

      const parsed = JSON.parse(response.text || '{}');
      return res.json({ ...parsed, modelUsed });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error('Error in /api/detect-language:', errorMessage);
      return res.status(500).json({ error: errorMessage });
    }
  });

  // Transcription API Endpoint
  app.post('/api/transcribe-chunk', async (req, res) => {
    try {
      const {
        audioBase64,
        mimeType = 'audio/wav',
        sourceLanguage = 'auto',
        targetLanguage = 'Vietnamese',
        enableDiarization = true,
        chunkOffsetSeconds = 0,
        maxCharsPerLine = 42,
      } = req.body;

      if (!audioBase64) {
        return res.status(400).json({ error: 'audioBase64 parameter is required' });
      }

      const ai = getGeminiClient();

      const sourceLangPrompt = sourceLanguage && sourceLanguage !== 'auto'
        ? `The primary audio language is confirmed as "${sourceLanguage}". Focus specifically on transcribing spoken ${sourceLanguage} with high precision.`
        : 'Identify the primary spoken language of the audio automatically.';

      // System instruction for precision speech-to-text transcription, SRT timing, and translation
      const systemInstruction = `You are an expert multilingual audio transcriber and subtitler.
Your job is to transcribe the provided audio clip accurately and produce structured subtitle cues.

CRITICAL REQUIREMENTS:
1. AUDIO RECOGNITION & PRECISION:
   - ${sourceLangPrompt}
   - Return language name, ISO code (e.g. "en", "vi", "zh"), and confidence (0.0 to 1.0).
   - If there is NO speech or only background noise, set "hasSpeech": false and return empty subtitles.
   - Do NOT omit any spoken sentence or line, even if fast, faint, accented, or with background noise.

2. SUBTITLE CUE TIMING & FORMATTING:
   - Calculate precise timestamps relative to the start of this audio clip (00:00:00,000).
   - Timestamps MUST be in exact SRT format: "HH:MM:SS,mmm" (e.g. "00:00:01,250") and include "startSeconds" and "endSeconds" numbers.
   - MANDATORY FULL COVERAGE: Transcribe EVERY SINGLE spoken sentence from 00:00:00 until the VERY END of this audio clip. Do NOT stop transcribing before the audio clip finishes.
   - Maximum ${maxCharsPerLine} characters per line.
   - Maximum 2 lines per subtitle cue frame (~17 characters per second reading speed).
   - Automatically split long sentences into multiple properly-timed subtitle frames.

3. DIARIZATION & TRANSLATION:
   - ${enableDiarization ? 'Identify speakers as "Speaker 1", "Speaker 2", etc.' : 'Leave speaker empty or null.'}
   - Translate all transcribed text into "${targetLanguage}". Ensure translations preserve context, tone, and domain terminology without word-for-word robotic errors.

Output must be STRICT JSON matching the schema provided.`;

      const prompt = `Analyze this audio chunk (offset: ${chunkOffsetSeconds}s). Transcribe every spoken word in original language, translate to ${targetLanguage}, format timestamps into SRT standards.`;

      const cascadeModels = ['gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'];

      const { result: response, modelUsed } = await callGeminiWithCascade(cascadeModels, (modelName) =>
        ai.models.generateContent({
          model: modelName,
          contents: [
            {
              inlineData: {
                mimeType: mimeType,
                data: audioBase64,
              },
            },
            {
              text: prompt,
            },
          ],
          config: {
            systemInstruction,
            temperature: 0.2,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                detectedLanguage: {
                  type: Type.STRING,
                  description: 'Detected language name, e.g. English, Vietnamese',
                },
                isoCode: {
                  type: Type.STRING,
                  description: '2-letter ISO 639-1 code e.g. en, vi, zh',
                },
                confidence: {
                  type: Type.NUMBER,
                  description: 'Detection confidence score from 0.0 to 1.0',
                },
                hasSpeech: {
                  type: Type.BOOLEAN,
                  description: 'True if audible speech was detected',
                },
                subtitles: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      start: {
                        type: Type.STRING,
                        description: 'Start SRT timestamp HH:MM:SS,mmm',
                      },
                      end: {
                        type: Type.STRING,
                        description: 'End SRT timestamp HH:MM:SS,mmm',
                      },
                      startSeconds: {
                        type: Type.NUMBER,
                        description: 'Start time in seconds within chunk',
                      },
                      endSeconds: {
                        type: Type.NUMBER,
                        description: 'End time in seconds within chunk',
                      },
                      speaker: {
                        type: Type.STRING,
                        description: 'Speaker label e.g. Speaker 1',
                      },
                      text_original: {
                        type: Type.STRING,
                        description: 'Transcribed text in original language',
                      },
                      text_translated: {
                        type: Type.STRING,
                        description: `Translated text in ${targetLanguage}`,
                      },
                    },
                    required: ['start', 'end', 'startSeconds', 'endSeconds', 'text_original', 'text_translated'],
                  },
                },
              },
              required: ['detectedLanguage', 'isoCode', 'confidence', 'hasSpeech', 'subtitles'],
            },
          },
        })
      );

      const responseText = response.text || '{}';
      let parsedJson: any;
      try {
        parsedJson = JSON.parse(responseText);
        parsedJson.modelUsed = modelUsed;
      } catch {
        return res.status(500).json({
          error: 'Failed to parse Gemini output as JSON',
          rawResponse: responseText,
        });
      }

      // --- OPTIONAL PASS 2: AI REFINEMENT & PROOFREADING PASS ---
      const enableProofreadPass = Boolean(req.body.enableProofreadPass);
      if (enableProofreadPass && parsedJson.subtitles && Array.isArray(parsedJson.subtitles) && parsedJson.subtitles.length > 0) {
        try {
          const pass2SystemInstruction = `You are a Senior Subtitle Quality Control Engineer & Proofreader.
Your job is to review and refine the Pass 1 draft subtitle cues generated from audio transcription.

CRITICAL PASS 2 QUALITY CONTROLS:
1. TIMESTAMP INTEGRITY (ABSOLUTE REQUIREMENT):
   - Check every single cue. "endSeconds" MUST be strictly greater than "startSeconds" (endSeconds > startSeconds).
   - NEVER return negative durations or inverted start/end timestamps (e.g. start=169s, end=143s is A FATAL ERROR).
   - If startSeconds >= endSeconds in Pass 1, re-calculate proper endSeconds = startSeconds + Math.max(1.8, textLength / 16).

2. WALL-OF-TEXT & SENTENCE SPLITTING:
   - Do NOT combine a long paragraph into a single cue.
   - If a cue has more than 12-15 words or multiple sentences, split it into multiple sequential sub-cues across the timeframe.
   - Ensure each cue is max ${maxCharsPerLine} chars per line, max 2 lines per subtitle frame.

3. PROOFREADING & TRANSLATION POLISH:
   - Fix any spelling typos, grammatical errors, weird phrasing, or character corruption in both text_original and text_translated (${targetLanguage}).
   - Clean up inline speaker prefixes like "[speaker 1]:" from inside text fields, putting clean "Speaker 1" in the speaker property instead.

4. CHRONOLOGICAL ORDER:
   - Ensure cues are sorted chronologically by startSeconds.

Output strict JSON with the refined list of subtitles.`;

          const { result: pass2Response } = await callGeminiWithCascade(cascadeModels, (modelName) =>
            ai.models.generateContent({
              model: modelName,
              contents: [
                {
                  text: `PASS 1 DRAFT SUBTITLES TO AUDIT AND REFINE:\n${JSON.stringify(parsedJson.subtitles, null, 2)}\n\nPlease review, fix all timestamp errors, split any long text blocks, proofread translations into ${targetLanguage}, and return the final clean JSON.`,
                },
              ],
              config: {
                systemInstruction: pass2SystemInstruction,
                temperature: 0.1,
                responseMimeType: 'application/json',
                responseSchema: {
                  type: Type.OBJECT,
                  properties: {
                    subtitles: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          start: { type: Type.STRING },
                          end: { type: Type.STRING },
                          startSeconds: { type: Type.NUMBER },
                          endSeconds: { type: Type.NUMBER },
                          speaker: { type: Type.STRING },
                          text_original: { type: Type.STRING },
                          text_translated: { type: Type.STRING },
                        },
                        required: ['start', 'end', 'startSeconds', 'endSeconds', 'text_original', 'text_translated'],
                      },
                    },
                  },
                  required: ['subtitles'],
                },
              },
            })
          );

          const pass2Data = JSON.parse(pass2Response.text || '{}');
          if (
            pass2Data.subtitles &&
            Array.isArray(pass2Data.subtitles) &&
            pass2Data.subtitles.length >= Math.floor(parsedJson.subtitles.length * 0.8)
          ) {
            parsedJson.subtitles = pass2Data.subtitles;
          } else {
            console.warn('Pass 2 returned significantly fewer cues than Pass 1. Keeping Pass 1 to prevent subtitle loss.');
          }
        } catch (pass2Err) {
          console.warn('Pass 2 AI refinement warning (falling back to Pass 1 + server sanitizer):', pass2Err);
        }
      }

      // --- SERVER-SIDE PROGRAMMATIC SANITIZER SAFEGUARD ---
      if (parsedJson.subtitles) {
        parsedJson.subtitles = sanitizeCuesServer(parsedJson.subtitles, maxCharsPerLine);
      }

      return res.json(parsedJson);
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error('Error in /api/transcribe-chunk:', errorMessage);
      return res.status(500).json({ error: errorMessage });
    }
  });

async function callGeminiWithCascade<T>(
  models: string[],
  fnBuilder: (modelName: string) => Promise<T>
): Promise<{ result: T; modelUsed: string }> {
  let lastError: any = null;
  for (const modelName of models) {
    try {
      console.log(`[Gemini Cascade] Invoking model: ${modelName}...`);
      const result = await callGeminiWithRetry(() => fnBuilder(modelName), 2, 800);
      return { result, modelUsed: modelName };
    } catch (err: any) {
      lastError = err;
      const errStr = String(err?.message || err || '');
      console.warn(`[Gemini Cascade] Model ${modelName} error/quota limit: ${errStr.slice(0, 150)}. Retrying with next available model...`);
      await new Promise((res) => setTimeout(res, 400));
    }
  }
  throw lastError || new Error('All Gemini cascade models failed');
}

async function callGeminiWithRetry<T>(fn: () => Promise<T>, maxRetries = 4, initialDelayMs = 1200): Promise<T> {
  let attempt = 0;
  while (true) {
    try {
      return await fn();
    } catch (err: any) {
      attempt++;
      const errStr = String(err?.message || err || '');
      const isHardQuota =
        errStr.includes('Quota exceeded') ||
        errStr.includes('RESOURCE_EXHAUSTED') ||
        errStr.includes('quotaId') ||
        errStr.includes('GenerateRequestsPerDay');

      if (isHardQuota) {
        ttsGeminiQuotaCooldownUntil = Date.now() + 60_000;
        throw err;
      }

      const isRateLimit =
        err?.status === 429 ||
        errStr.includes('429') ||
        errStr.includes('quota') ||
        errStr.includes('rate limit');

      if (isRateLimit && attempt <= maxRetries) {
        const delay = initialDelayMs * Math.pow(1.6, attempt - 1);
        console.log(`[Gemini RateLimit] 429 rate limit. Retrying (${attempt}/${maxRetries}) after ${Math.round(delay)}ms...`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        throw err;
      }
    }
  }
}

let ttsGeminiQuotaCooldownUntil = 0;

async function fetchSingleGTChunk(chunk: string, lang = 'vi'): Promise<Buffer> {
  const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=${lang}&client=tw-ob`;
  const response = await fetch(url, {
    headers: {
      'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    },
  });
  if (!response.ok) {
    throw new Error(`Google Translate TTS fallback HTTP ${response.status}`);
  }
  const arrayBuffer = await response.arrayBuffer();
  return Buffer.from(arrayBuffer);
}

async function fallbackGoogleTranslateTTS(text: string, lang = 'vi'): Promise<string> {
  const cleanText = text.trim();
  if (!cleanText) {
    throw new Error('Text is empty for fallback TTS');
  }

  // If text is short (<= 180 chars), single request
  if (cleanText.length <= 180) {
    const buf = await fetchSingleGTChunk(cleanText, lang);
    return buf.toString('base64');
  }

  // Split into chunks of max 160 characters by sentence / commas
  const chunks: string[] = [];
  let remaining = cleanText;
  while (remaining.length > 0) {
    if (remaining.length <= 160) {
      chunks.push(remaining);
      break;
    }
    // Find split point
    let splitIdx = remaining.slice(0, 160).lastIndexOf('.');
    if (splitIdx === -1 || splitIdx < 50) splitIdx = remaining.slice(0, 160).lastIndexOf(',');
    if (splitIdx === -1 || splitIdx < 50) splitIdx = remaining.slice(0, 160).lastIndexOf(' ');
    if (splitIdx === -1) splitIdx = 160;

    const chunk = remaining.slice(0, splitIdx + 1).trim();
    if (chunk) chunks.push(chunk);
    remaining = remaining.slice(splitIdx + 1).trim();
  }

  const buffers: Buffer[] = [];
  for (const chunk of chunks) {
    const buf = await fetchSingleGTChunk(chunk, lang);
    buffers.push(buf);
  }

  const combined = Buffer.concat(buffers);
  return combined.toString('base64');
}

  // --- TTS SINGLE CUE SYNTHESIS ENDPOINT ---
  app.post('/api/tts/single', async (req, res) => {
    try {
      const {
        text,
        voiceName = 'Kore',
        stylePrompt = '',
        model = 'gemini-3.1-flash-tts-preview',
        engine = '',
        lang = 'vi',
        allowFallback = true,
      } = req.body;

      if (!text || !text.trim()) {
        return res.status(400).json({ error: 'Text is required for TTS' });
      }

      // If user specifically selected fallback engine, skip Gemini
      if (model === 'fallback-gt' || engine === 'fallback-gt') {
        const fallbackBase64 = await fallbackGoogleTranslateTTS(text, lang);
        return res.json({
          audioBase64: fallbackBase64,
          mimeType: 'audio/mp3',
          engine: 'fallback-gt',
          voiceName: 'Google Translate',
        });
      }

      // Circuit Breaker: If Gemini TTS recently hit 429 quota, directly fallback if allowed or cooldown is active
      const isCooldown = Date.now() < ttsGeminiQuotaCooldownUntil;
      if (isCooldown && allowFallback !== false) {
        try {
          const fallbackBase64 = await fallbackGoogleTranslateTTS(text, lang);
          return res.json({
            audioBase64: fallbackBase64,
            mimeType: 'audio/mp3',
            engine: 'fallback-gt',
            isQuotaFallback: true,
            voiceName: 'Google Translate (Dự phòng)',
          });
        } catch (gtErr: any) {
          console.error('[TTS Single] Fallback Google Translate error:', gtErr?.message || gtErr);
        }
      }

      const selectedModel = model || 'gemini-3.1-flash-tts-preview';
      const promptText = stylePrompt
        ? `${stylePrompt}\n\nĐọc câu sau:\n"${text.trim()}"`
        : `Đọc bằng giọng diễn cảm, tự nhiên, ngắt nghỉ đúng câu:\n"${text.trim()}"`;

      try {
        const ai = getGeminiClient();
        const response = await callGeminiWithRetry(
          () =>
            ai.models.generateContent({
              model: selectedModel,
              contents: [{ parts: [{ text: promptText }] }],
              config: {
                responseModalities: ['AUDIO'],
                speechConfig: {
                  voiceConfig: {
                    prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
                  },
                },
              },
            }),
          2, // Retry with backoff on 429
          600
        );

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (base64Audio) {
          const wavBase64 = pcmBase64ToWavBase64(base64Audio, 24000, 1);
          return res.json({
            audioBase64: wavBase64,
            mimeType: 'audio/wav',
            sampleRate: 24000,
            engine: 'gemini',
            modelUsed: selectedModel,
            voiceName,
          });
        }
      } catch (geminiErr: any) {
        const errStr = String(geminiErr?.message || geminiErr || '');
        const isQuota = errStr.includes('429') || errStr.includes('quota') || errStr.includes('RESOURCE_EXHAUSTED') || errStr.includes('Quota exceeded');

        if (isQuota) {
          // Set cooldown so subsequent cues don't freeze on rate limits
          ttsGeminiQuotaCooldownUntil = Date.now() + 60_000;
          console.log(`[TTS Single] Gemini quota reached for "${text.slice(0, 30)}...", switching to fallback engine.`);
        } else {
          console.warn(`[TTS Single] Gemini TTS error for "${text.slice(0, 30)}...":`, geminiErr?.message || geminiErr);
        }

        // Fallback to Google Translate TTS if allowFallback is true or quota is exhausted
        if (allowFallback !== false || isQuota) {
          try {
            const fallbackBase64 = await fallbackGoogleTranslateTTS(text, lang);
            return res.json({
              audioBase64: fallbackBase64,
              mimeType: 'audio/mp3',
              engine: 'fallback-gt',
              isQuotaFallback: true,
              voiceName: 'Google Translate (Dự phòng)',
            });
          } catch (gtErr: any) {
            console.error('[TTS Single] Fallback Google Translate also failed:', gtErr?.message || gtErr);
          }
        }

        return res.status(isQuota ? 429 : 500).json({
          error: isQuota
            ? 'Gemini TTS đang bị giới hạn hạn mức (Quota 429). Hệ thống đã tự động chuyển sang giọng dự phòng hoặc bạn có thể thử lại sau.'
            : (geminiErr?.message || 'Tạo giọng đọc Gemini TTS thất bại.')
        });
      }

      return res.status(500).json({ error: 'Không nhận được dữ liệu âm thanh từ mô hình AI.' });
    } catch (err: any) {
      console.error('Error in /api/tts/single:', err?.message || err);
      return res.status(500).json({ error: err?.message || 'Tạo giọng đọc thất bại.' });
    }
  });

  // --- TTS BATCH DUBBING ENDPOINT ---
  app.post('/api/tts/batch', async (req, res) => {
    try {
      const {
        items,
        voiceName = 'Kore',
        stylePrompt = '',
        lang = 'vi',
        model = 'gemini-3.1-flash-tts-preview',
        allowFallback = false,
      } = req.body;

      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Danh sách phụ đề trống' });
      }

      const results = [];
      const selectedModel = model || 'gemini-3.1-flash-tts-preview';

      for (const item of items) {
        const text = (item.text || '').trim();
        if (!text) continue;

        let audioGenerated = false;

        try {
          const ai = getGeminiClient();
          const promptText = stylePrompt
            ? `${stylePrompt}\n\nĐọc câu sau:\n"${text}"`
            : `Đọc diễn cảm, chuẩn nhịp câu:\n"${text}"`;

          const response = await callGeminiWithRetry(
            () =>
              ai.models.generateContent({
                model: selectedModel,
                contents: [{ parts: [{ text: promptText }] }],
                config: {
                  responseModalities: ['AUDIO'],
                  speechConfig: {
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: voiceName || 'Kore' },
                    },
                  },
                },
              }),
            3,
            800
          );

          const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
          if (base64Audio) {
            const wavBase64 = pcmBase64ToWavBase64(base64Audio, 24000, 1);
            results.push({
              id: item.id,
              startSeconds: item.startSeconds,
              endSeconds: item.endSeconds,
              text: text,
              audioBase64: wavBase64,
              engine: 'gemini-3.1',
            });
            audioGenerated = true;
          }
        } catch (geminiErr: any) {
          console.warn(`[TTS Batch] Item ${item.id} error:`, geminiErr?.message || geminiErr);
        }

        // Only fallback if allowFallback is explicitly enabled by user
        if (!audioGenerated && allowFallback) {
          try {
            const fallbackBase64 = await fallbackGoogleTranslateTTS(text, lang);
            results.push({
              id: item.id,
              startSeconds: item.startSeconds,
              endSeconds: item.endSeconds,
              text: text,
              audioBase64: fallbackBase64,
              engine: 'fallback-gt',
              isQuotaFallback: true,
            });
            audioGenerated = true;
          } catch (gtErr: any) {
            console.error(`[TTS Batch] Google Translate fallback failed for item ${item.id}:`, gtErr?.message || gtErr);
          }
        }
      }

      return res.json({ results, count: results.length });
    } catch (err: any) {
      console.error('Error in /api/tts/batch:', err?.message || err);
      return res.status(500).json({ error: err?.message || 'Lồng tiếng hàng loạt thất bại.' });
    }
  });

  /* ==========================================================================
     THUMBNAIL & VIRAL TITLE GENERATOR ENDPOINT
     ========================================================================== */
  app.post('/api/thumbnail/generate-titles', async (req, res) => {
    try {
      const {
        imageBase64,
        mimeType = 'image/jpeg',
        topic = '',
        provider = 'gemini',
        model = 'gemini-3.6-flash',
        style = 'viral',
      } = req.body;

      const ai = getGeminiClient();

      const promptText = `Bạn là chuyên gia tăng trưởng YouTube/TikTok và nhà sáng tạo Thumbnail Virus số 1 thế giới.
Hãy phân tích hình ảnh thumbnail và chủ đề video: "${topic || 'Chủ đề video hấp dẫn'}" (sử dụng mô hình AI: ${provider} - ${model}, phong cách: ${style}).

Hãy sáng tạo 8 tiêu đề video hấp dẫn nhất bằng Tiếng Việt với chỉ số CTR cực cao, kèm theo các yếu tố gây tò mò, từ khóa SEO và từ/cụm từ dán lên ảnh Thumbnail.

Trả về định dạng JSON nghiêm ngặt với cấu trúc:
{
  "analyzedVisuals": "Tóm tắt ngắn 1-2 câu về màu sắc, cảm xúc và nhân vật trong ảnh...",
  "recommendedOverlayText": "BÍ MẬT SỐC!",
  "recommendedBadge": "🔥 BẮT BUỘC XEM",
  "titles": [
    {
      "id": "t1",
      "title": "Tiêu đề hấp dẫn 1...",
      "ctrScore": 98,
      "hookCategory": "🔥 Giật gân / Tò mò",
      "reason": "Giải thích lý do giật gân thu hút người click...",
      "suggestedTags": ["#viral", "#review", "#top1"]
    }
  ]
}`;

      const contentsParts: any[] = [{ text: promptText }];
      if (imageBase64) {
        contentsParts.push({
          inlineData: {
            mimeType,
            data: imageBase64,
          },
        });
      }

      const response = await callGeminiWithRetry(
        () =>
          ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [{ parts: contentsParts }],
            config: {
              responseMimeType: 'application/json',
            },
          }),
        3,
        1500
      );

      const resText = response.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
      const parsed = JSON.parse(resText);

      return res.json({
        providerUsed: provider,
        modelUsed: model,
        analyzedVisuals: parsed.analyzedVisuals || 'Đã phân tích bối cảnh và bố cục hình ảnh thumbnail.',
        recommendedOverlayText: parsed.recommendedOverlayText || 'CỰC SỐC!',
        recommendedBadge: parsed.recommendedBadge || '🔥 TOP 1',
        titles: Array.isArray(parsed.titles) ? parsed.titles : [],
      });
    } catch (err: any) {
      console.error('Error in /api/thumbnail/generate-titles:', err?.message || err);
      return res.status(500).json({ error: err?.message || 'Tạo tiêu đề & thumbnail thất bại.' });
    }
  });

  /* ==========================================================================
     MANGA / MANHWA / WEBTOON OCR & AI TRANSLATION ENDPOINTS
     ========================================================================== */

  // --- 1. MANGA OCR ENDPOINT ---
  app.post('/api/manga/ocr', async (req, res) => {
    try {
      const { imageBase64, mimeType = 'image/jpeg' } = req.body;

      if (!imageBase64) {
        return res.status(400).json({ error: 'imageBase64 parameter is required' });
      }

      const ai = getGeminiClient();

      const systemInstruction = `You are an expert Manga & Comic Book OCR Vision system.
Detect ALL text regions, speech balloons, dialogue boxes, sound effects, vertical text, slanted text, white text, outlined text, and captions in this comic/manga image.

For EACH text region found, specify its bounding box in normalized [ymin, xmin, ymax, xmax] integer scale from 0 to 1000.
(Where 0 is top/left and 1000 is bottom/right of the image).

Return strict JSON format:
{
  "bubbles": [
    {
      "box": [ymin, xmin, ymax, xmax],
      "text_original": "Extracted text in original language",
      "confidence": 0.95,
      "isVertical": false
    }
  ]
}`;

      const cascadeModels = ['gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'];

      const { result: response, modelUsed } = await callGeminiWithCascade(cascadeModels, (modelName) =>
        ai.models.generateContent({
          model: modelName,
          contents: [
            {
              inlineData: { mimeType, data: imageBase64 },
            },
            {
              text: 'Perform OCR on this manga page image. Extract all text bubbles with exact 0-1000 normalized bounding boxes.',
            },
          ],
          config: {
            systemInstruction,
            temperature: 0.1,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                bubbles: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      box: {
                        type: Type.ARRAY,
                        items: { type: Type.INTEGER },
                        description: '[ymin, xmin, ymax, xmax] in 0..1000 scale',
                      },
                      text_original: { type: Type.STRING },
                      confidence: { type: Type.NUMBER },
                      isVertical: { type: Type.BOOLEAN },
                    },
                    required: ['box', 'text_original'],
                  },
                },
              },
              required: ['bubbles'],
            },
          },
        })
      );

      const parsed = JSON.parse(response.text || '{"bubbles":[]}');
      const bubbles = (parsed.bubbles || []).map((b: any, idx: number) => ({
        id: `bubble_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
        box: Array.isArray(b.box) && b.box.length === 4 ? b.box : [100, 100, 200, 300],
        text_original: String(b.text_original || '').trim(),
        text_translated: '',
        confidence: typeof b.confidence === 'number' ? b.confidence : 0.9,
        isVertical: Boolean(b.isVertical),
      }));

      return res.json({ bubbles, modelUsed });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error('Error in /api/manga/ocr:', errorMessage);
      return res.status(500).json({ error: errorMessage || 'OCR nhận diện chữ thất bại' });
    }
  });

  // --- 2. MANGA TRANSLATION ENDPOINT ---
  app.post('/api/manga/translate', async (req, res) => {
    try {
      const { bubbles, targetLanguage = 'vi', preserveNamesAndSkills = true } = req.body;

      if (!Array.isArray(bubbles) || bubbles.length === 0) {
        return res.json({ translations: [] });
      }

      const ai = getGeminiClient();

      const systemInstruction = `You are a professional Manga, Manhwa, and Webtoon Localization Translator.
Translate comic text dialogue bubbles into ${targetLanguage}.

CRITICAL RULES:
1. PRESERVE ALL proper nouns (character names like Sung Jin-Woo, Naruto, Goku), skill names (like Shadow Extraction, Rasengan, Bankai), locations, levels, stats, and game system terms.
2. Translate naturally according to comic/manga context. Do NOT use literal word-for-word machine translation.
3. Keep emotion and sentence structure concise so it fits inside speech balloons.
4. Return strict JSON matching schema.`;

      const promptText = `Translate the following ${bubbles.length} comic speech bubbles into ${targetLanguage}:\n${JSON.stringify(
        bubbles.map((b: any) => ({ id: b.id, text: b.text_original })),
        null,
        2
      )}`;

      const cascadeModels = ['gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-2.5-flash'];

      const { result: response, modelUsed } = await callGeminiWithCascade(cascadeModels, (modelName) =>
        ai.models.generateContent({
          model: modelName,
          contents: [{ text: promptText }],
          config: {
            systemInstruction,
            temperature: 0.2,
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                translations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      text_translated: { type: Type.STRING },
                    },
                    required: ['id', 'text_translated'],
                  },
                },
              },
              required: ['translations'],
            },
          },
        })
      );

      const parsed = JSON.parse(response.text || '{"translations":[]}');
      return res.json({ translations: parsed.translations || [], modelUsed });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error('Error in /api/manga/translate:', errorMessage);
      return res.status(500).json({ error: errorMessage || 'Dịch thuật AI thất bại' });
    }
  });

  // Serve Vite Dev Server in Development or Static Files in Production
  const outputsDir = path.join(process.cwd(), 'outputs');
  if (!fs.existsSync(outputsDir)) {
    fs.mkdirSync(outputsDir, { recursive: true });
  }
  app.use('/outputs', express.static(outputsDir));

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
