import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { LeftToolRail } from './components/LeftToolRail';
import { RightInspector } from './components/RightInspector';
import { BottomTimeline } from './components/BottomTimeline';
import { FileUpload } from './components/FileUpload';
import { ProgressBar } from './components/ProgressBar';
import { VideoPlayer } from './components/VideoPlayer';
import { SubtitleEditor } from './components/SubtitleEditor';
import { DubbingStudio } from './components/DubbingStudio';
import { DownloadPanel } from './components/DownloadPanel';
import { SessionHistory } from './components/SessionHistory';
import { IntroScreen } from './components/IntroScreen';

import {
  SubtitleCue,
  SubtitleMode,
  ProcessingChunk,
  TranscribeOptions,
  SessionHistoryItem,
  SubtitleStyleConfig,
  DEFAULT_SUBTITLE_STYLE,
  ActiveStudioTool,
  VoicePersonaId,
  VOICE_PERSONAS,
} from './types';
import { decodeFileAudioBuffer, audioBufferToWavBase64, generateFullDubbedAudio } from './utils/audio';
import { srtTimeToSeconds, secondsToSrtTime, sanitizeAndValidateCues } from './utils/srt';

import { ArrowLeft, Sparkles, X, Subtitles, Volume2 } from 'lucide-react';

const LOCAL_STORAGE_KEY = 'subgen_session_history';
const INTRO_SEEN_KEY = 'subgen_intro_seen';
const INTRO_STARTUP_KEY = 'subgen_show_intro_on_startup';

export default function App() {
  // Intro State
  const [showIntro, setShowIntro] = useState<boolean>(() => {
    try {
      const startupSetting = localStorage.getItem(INTRO_STARTUP_KEY);
      if (startupSetting === 'true') return true;
      const seen = localStorage.getItem(INTRO_SEEN_KEY);
      return seen !== 'true';
    } catch {
      return true;
    }
  });

  const [showIntroOnStartup, setShowIntroOnStartup] = useState<boolean>(() => {
    try {
      const startupSetting = localStorage.getItem(INTRO_STARTUP_KEY);
      return startupSetting === 'true';
    } catch {
      return false;
    }
  });

  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);

  // Active Tool state for 3-panel workspace
  const [activeTool, setActiveTool] = useState<ActiveStudioTool>('style');
  const [isRailOpen, setIsRailOpen] = useState<boolean>(true);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(true);
  const [isTimelineOpen, setIsTimelineOpen] = useState<boolean>(true);
  const [isTimelineCollapsed, setIsTimelineCollapsed] = useState<boolean>(false);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Dubbed Audio & Playback state
  const [dubbedAudioUrl, setDubbedAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [seekTime, setSeekTime] = useState<number | null>(null);
  const [selectedPersonaId, setSelectedPersonaId] = useState<VoicePersonaId>('female_lively');
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [originalDucking, setOriginalDucking] = useState<number>(0.15);
  const [isGeneratingDubbing, setIsGeneratingDubbing] = useState<boolean>(false);
  const [dubbingProgress, setDubbingProgress] = useState<number>(0);
  const [dubbingStatusMessage, setDubbingStatusMessage] = useState<string>('');

  // Handler to trigger full dubbing generation from RightInspector
  const handleTriggerDubbing = async () => {
    if (masterSubtitles.length === 0 || isGeneratingDubbing) return;

    setActiveTool('voice');
    setIsGeneratingDubbing(true);
    setDubbingProgress(5);
    setDubbingStatusMessage('Khởi tạo quy trình lồng tiếng AI...');

    try {
      const persona = VOICE_PERSONAS.find((p) => p.id === selectedPersonaId) || VOICE_PERSONAS[0];
      const result = await generateFullDubbedAudio({
        cues: masterSubtitles,
        videoDuration,
        voiceName: persona.voiceName,
        stylePrompt: persona.stylePrompt,
        model: 'gemini-3.1-flash-tts-preview',
        speakingSpeed: speechRate,
        volume: 1.0,
        useTranslated: true,
        onProgress: (percent, msg) => {
          setDubbingProgress(percent);
          setDubbingStatusMessage(msg);
        },
      });

      setMasterSubtitles(result.adjustedCues);
      setDubbedAudioUrl(result.audioUrl);
      setDubbingProgress(100);
      setDubbingStatusMessage('Lồng tiếng thành công!');
    } catch (err: any) {
      console.error('Failed to trigger dubbing:', err);
      setDubbingStatusMessage('Có lỗi xảy ra khi lồng tiếng. Vui lòng thử lại.');
    } finally {
      setIsGeneratingDubbing(false);
    }
  };


  // Processing state
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [overallProgress, setOverallProgress] = useState<number>(0);
  const [currentStage, setCurrentStage] = useState<string>('');
  const [chunks, setChunks] = useState<ProcessingChunk[]>([]);

  // Master Subtitle Cues & Styling
  const [masterSubtitles, setMasterSubtitles] = useState<SubtitleCue[]>([]);
  const [subtitleMode, setSubtitleMode] = useState<SubtitleMode>('bilingual');
  const [showSpeaker, setShowSpeaker] = useState<boolean>(false);
  const [subtitleStyle, setSubtitleStyle] = useState<SubtitleStyleConfig>(DEFAULT_SUBTITLE_STYLE);

  // Language info
  const [detectedLanguage, setDetectedLanguage] = useState<{
    language: string;
    isoCode: string;
    confidence: number;
  } | null>(null);
  const [noSpeechDetected, setNoSpeechDetected] = useState<boolean>(false);

  const [transcribeOptions, setTranscribeOptions] = useState<TranscribeOptions>({
    sourceLanguage: 'auto',
    targetLanguage: 'Vietnamese',
    enableDiarization: true,
    chunkDurationMinutes: 3,
    maxCharsPerLine: 42,
  });

  const [appLogs, setAppLogs] = useState({
    ocrTime: 0,
    translateTime: 0,
  });

  const [historyItems, setHistoryItems] = useState<SessionHistoryItem[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [decodedAudioBuffer, setDecodedAudioBuffer] = useState<AudioBuffer | null>(null);

  // Load session history from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        setHistoryItems(JSON.parse(saved));
      }
    } catch {
      // ignore
    }
  }, []);

  // Save history item helper
  const saveToHistory = (
    cues: SubtitleCue[],
    lang: { language: string; isoCode: string },
    file: File,
    durationSec: number,
    targetLang: string,
    currentVideoUrl?: string | null
  ) => {
    const newItem: SessionHistoryItem = {
      id: Date.now().toString(),
      fileName: file.name,
      fileSize: file.size,
      durationSeconds: durationSec,
      createdAt: new Date().toISOString(),
      detectedLanguage: lang.language,
      isoCode: lang.isoCode,
      subtitles: cues,
      targetLanguage: targetLang,
      videoUrl: currentVideoUrl || undefined,
    };

    const updatedHistory = [newItem, ...historyItems.filter((item) => item.fileName !== file.name)].slice(0, 10);
    setHistoryItems(updatedHistory);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updatedHistory));
    } catch {
      // ignore
    }
  };

  // Start processing uploaded video
  const handleStartProcessing = async (file: File, durationSec: number, options: TranscribeOptions) => {
    setSelectedFile(file);
    setVideoDuration(durationSec);
    setTranscribeOptions(options);

    const objectUrl = URL.createObjectURL(file);
    setVideoUrl(objectUrl);

    setIsProcessing(true);
    setOverallProgress(5);
    setCurrentStage('Giải mã luồng âm thanh từ video...');
    setMasterSubtitles([]);
    setDetectedLanguage(null);
    setNoSpeechDetected(false);

    try {
      const decodeStartTime = performance.now();
      const audioBuffer = await decodeFileAudioBuffer(file, (stage, percent) => {
        setCurrentStage(stage);
        setOverallProgress(Math.min(20, percent * 0.2));
      });
      const ocrTime = (performance.now() - decodeStartTime) / 1000;
      setAppLogs((prev) => ({ ...prev, ocrTime }));

      setDecodedAudioBuffer(audioBuffer);

      const totalDuration = Math.max(audioBuffer.duration || 0, durationSec || 0, 10);
      const chunkLenSec = (options.chunkDurationMinutes || 3) * 60;
      const numChunks = Math.ceil(totalDuration / chunkLenSec);

      const initialChunks: ProcessingChunk[] = [];
      for (let i = 0; i < numChunks; i++) {
        const startSec = i * chunkLenSec;
        const endSec = Math.min(totalDuration, (i + 1) * chunkLenSec);
        initialChunks.push({
          id: `chunk_${i}_${Date.now()}`,
          chunkIndex: i,
          startTimeSeconds: startSec,
          endTimeSeconds: endSec,
          status: 'pending',
          progress: 0,
          subtitles: [],
        });
      }

      setChunks(initialChunks);
      setCurrentStage(`Đang phân tích ${numChunks} phân đoạn âm thanh...`);

      let allCues: SubtitleCue[] = [];
      let primaryLang = { language: 'English', isoCode: 'en', confidence: 0.95 };
      const transcribeStartTime = performance.now();

      for (let i = 0; i < numChunks; i++) {
        const chunk = initialChunks[i];

        setChunks((prev) =>
          prev.map((c, idx) => (idx === i ? { ...c, status: 'processing', progress: 20 } : c))
        );

        setCurrentStage(`Đang bóc băng & dịch thuật phân đoạn ${i + 1} / ${numChunks}...`);

        try {
          const isFirstChunk = i === 0;
          const isLastChunk = i === numChunks - 1;
          const overlapSec = 5;
          const sliceStartSec = isFirstChunk ? chunk.startTimeSeconds : Math.max(0, chunk.startTimeSeconds - overlapSec);
          const sliceEndSec = isLastChunk ? chunk.endTimeSeconds : Math.min(totalDuration, chunk.endTimeSeconds + overlapSec);

          const wavBase64 = audioBufferToWavBase64(
            audioBuffer,
            sliceStartSec,
            sliceEndSec - sliceStartSec
          );

          setChunks((prev) =>
            prev.map((c, idx) => (idx === i ? { ...c, progress: 50 } : c))
          );

          const res = await fetch('/api/transcribe-chunk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              audioBase64: wavBase64,
              mimeType: 'audio/wav',
              sourceLanguage: options.sourceLanguage,
              targetLanguage: options.targetLanguage,
              enableDiarization: options.enableDiarization,
              chunkOffsetSeconds: sliceStartSec,
              maxCharsPerLine: options.maxCharsPerLine,
            }),
          });

          if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.error || `Lỗi máy chủ: ${res.statusText}`);
          }

          const data = await res.json();

          if (data.detectedLanguage) {
            primaryLang = {
              language: data.detectedLanguage,
              isoCode: data.isoCode || 'en',
              confidence: data.confidence || 0.9,
            };
            setDetectedLanguage(primaryLang);
          }

          if (data.hasSpeech === false) {
            setNoSpeechDetected(true);
          }

          const chunkOffset = sliceStartSec;

          let processedCues: SubtitleCue[] = (data.subtitles || []).map(
            (cue: SubtitleCue, cueIdx: number) => {
              const relStartSec =
                typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds)
                  ? cue.startSeconds
                  : srtTimeToSeconds(cue.start);
              const relEndSec =
                typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds)
                  ? cue.endSeconds
                  : srtTimeToSeconds(cue.end);

              const absStartSec = relStartSec + chunkOffset;
              const absEndSec = relEndSec + chunkOffset;

              return {
                ...cue,
                id: Date.now() + i * 1000 + cueIdx,
                startSeconds: absStartSec,
                endSeconds: absEndSec,
                start: secondsToSrtTime(absStartSec),
                end: secondsToSrtTime(absEndSec),
              };
            }
          );

          processedCues = processedCues.filter((cue) => {
            const mid = (cue.startSeconds + cue.endSeconds) / 2;
            const meetsStart = isFirstChunk ? true : mid >= chunk.startTimeSeconds;
            const meetsEnd = isLastChunk ? true : mid < chunk.endTimeSeconds;
            return meetsStart && meetsEnd;
          });

          allCues = [...allCues, ...processedCues];

          setChunks((prev) =>
            prev.map((c, idx) =>
              idx === i
                ? {
                    ...c,
                    status: 'completed',
                    progress: 100,
                    subtitles: processedCues,
                    detectedLanguage: data.detectedLanguage,
                    isoCode: data.isoCode,
                  }
                : c
            )
          );

          const progressPercent = 20 + Math.round(((i + 1) / numChunks) * 80);
          setOverallProgress(progressPercent);
        } catch (err: unknown) {
          const errorMessage = err instanceof Error ? err.message : String(err);
          console.error(`Chunk ${i} error:`, errorMessage);

          setChunks((prev) =>
            prev.map((c, idx) => (idx === i ? { ...c, status: 'error', errorMessage } : c))
          );
        }
      }

      const cleanMasterCues = sanitizeAndValidateCues(allCues, options.maxCharsPerLine);
      const translateTime = (performance.now() - transcribeStartTime) / 1000;
      setAppLogs((prev) => ({ ...prev, translateTime }));

      setMasterSubtitles(cleanMasterCues);
      setOverallProgress(100);
      setCurrentStage('Đã hoàn thành bóc băng & dịch thuật!');
      setIsProcessing(false);

      if (cleanMasterCues.length > 0) {
        saveToHistory(cleanMasterCues, primaryLang, file, totalDuration, options.targetLanguage, objectUrl);
      }
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      console.error('Fatal error:', errorMessage);
      setCurrentStage(`Lỗi: ${errorMessage}`);
      setIsProcessing(false);
    }
  };

  // Retry chunk handler
  const handleRetryChunk = async (chunkIndex: number) => {
    if (!decodedAudioBuffer || !chunks[chunkIndex]) return;

    const chunk = chunks[chunkIndex];

    setChunks((prev) =>
      prev.map((c, idx) =>
        idx === chunkIndex ? { ...c, status: 'processing', progress: 30, errorMessage: undefined } : c
      )
    );

    try {
      const totalDuration = decodedAudioBuffer.duration;
      const isFirstChunk = chunkIndex === 0;
      const isLastChunk = chunkIndex === chunks.length - 1;
      const overlapSec = 5;
      const sliceStartSec = isFirstChunk ? chunk.startTimeSeconds : Math.max(0, chunk.startTimeSeconds - overlapSec);
      const sliceEndSec = isLastChunk ? chunk.endTimeSeconds : Math.min(totalDuration, chunk.endTimeSeconds + overlapSec);

      const wavBase64 = audioBufferToWavBase64(
        decodedAudioBuffer,
        sliceStartSec,
        sliceEndSec - sliceStartSec
      );

      const res = await fetch('/api/transcribe-chunk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: wavBase64,
          mimeType: 'audio/wav',
          sourceLanguage: transcribeOptions.sourceLanguage,
          targetLanguage: transcribeOptions.targetLanguage,
          enableDiarization: transcribeOptions.enableDiarization,
          chunkOffsetSeconds: sliceStartSec,
          maxCharsPerLine: transcribeOptions.maxCharsPerLine,
        }),
      });

      if (!res.ok) {
        throw new Error(`Mã lỗi máy chủ: ${res.statusText}`);
      }

      const data = await res.json();
      const chunkOffset = sliceStartSec;

      let processedCues: SubtitleCue[] = (data.subtitles || []).map(
        (cue: SubtitleCue, cueIdx: number) => {
          const relStartSec =
            typeof cue.startSeconds === 'number' && !isNaN(cue.startSeconds)
              ? cue.startSeconds
              : srtTimeToSeconds(cue.start);
          const relEndSec =
            typeof cue.endSeconds === 'number' && !isNaN(cue.endSeconds)
              ? cue.endSeconds
              : srtTimeToSeconds(cue.end);

          const absStartSec = relStartSec + chunkOffset;
          const absEndSec = relEndSec + chunkOffset;

          return {
            ...cue,
            id: Date.now() + chunkIndex * 1000 + cueIdx,
            startSeconds: absStartSec,
            endSeconds: absEndSec,
            start: secondsToSrtTime(absStartSec),
            end: secondsToSrtTime(absEndSec),
          };
        }
      );

      processedCues = processedCues.filter((cue) => {
        const mid = (cue.startSeconds + cue.endSeconds) / 2;
        const meetsStart = isFirstChunk ? true : mid >= chunk.startTimeSeconds;
        const meetsEnd = isLastChunk ? true : mid < chunk.endTimeSeconds;
        return meetsStart && meetsEnd;
      });

      setChunks((prev) =>
        prev.map((c, idx) =>
          idx === chunkIndex ? { ...c, status: 'completed', progress: 100, subtitles: processedCues } : c
        )
      );

      setChunks((currentChunks) => {
        let merged: SubtitleCue[] = [];
        currentChunks.forEach((chk) => {
          if (chk.status === 'completed') {
            merged = [...merged, ...chk.subtitles];
          }
        });
        const sanitizedMerged = sanitizeAndValidateCues(merged, transcribeOptions.maxCharsPerLine);
        setMasterSubtitles(sanitizedMerged);
        return currentChunks;
      });
    } catch (err: unknown) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      setChunks((prev) =>
        prev.map((c, idx) => (idx === chunkIndex ? { ...c, status: 'error', errorMessage } : c))
      );
    }
  };

  // Attach local video file
  const handleAttachVideoFile = (file: File) => {
    setSelectedFile(file);
    const objectUrl = URL.createObjectURL(file);
    setVideoUrl(objectUrl);

    const tempVideo = document.createElement('video');
    tempVideo.src = objectUrl;
    tempVideo.onloadedmetadata = () => {
      if (tempVideo.duration) {
        setVideoDuration(tempVideo.duration);
      }
    };
  };

  // Load history session
  const handleLoadHistoryItem = (item: SessionHistoryItem) => {
    setSelectedFile(new File([], item.fileName));
    setVideoDuration(item.durationSeconds || 0);
    setMasterSubtitles(item.subtitles);
    setDetectedLanguage({
      language: item.detectedLanguage,
      isoCode: item.isoCode,
      confidence: 1.0,
    });
    setTranscribeOptions((prev) => ({ ...prev, targetLanguage: item.targetLanguage }));
    setIsProcessing(false);
    setChunks([]);
    setOverallProgress(100);

    if (item.videoUrl) {
      setVideoUrl(item.videoUrl);
    } else {
      setVideoUrl(null);
    }
  };

  const handleDeleteHistoryItem = (id: string) => {
    const updated = historyItems.filter((item) => item.id !== id);
    setHistoryItems(updated);
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleClearAllHistory = () => {
    setHistoryItems([]);
    try {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  // Intro handlers
  const handleGetStarted = () => {
    try {
      localStorage.setItem(INTRO_SEEN_KEY, 'true');
      localStorage.setItem(INTRO_STARTUP_KEY, showIntroOnStartup ? 'true' : 'false');
    } catch {
      // ignore
    }
    setShowIntro(false);
  };

  const handleToggleShowIntroOnStartup = (show: boolean) => {
    setShowIntroOnStartup(show);
    try {
      localStorage.setItem(INTRO_STARTUP_KEY, show ? 'true' : 'false');
    } catch {
      // ignore
    }
  };

  const handleReplayIntro = () => {
    setShowIntro(true);
  };

  // Find active cue based on currentTime
  const activeCue =
    masterSubtitles.find((c) => currentTime >= c.startSeconds && currentTime <= c.endSeconds) || null;

  return (
    <div className="h-screen w-screen bg-[#050505] text-zinc-100 flex flex-col font-sans overflow-hidden select-none">
      {/* 0. Cinematic Intro Screen (First Visit / On-Demand Replay) */}
      {showIntro && (
        <IntroScreen
          onGetStarted={handleGetStarted}
          showOnStartup={showIntroOnStartup}
          onToggleShowOnStartup={handleToggleShowIntroOnStartup}
        />
      )}

      {/* 1. Cinematic Studio Header */}
      <Header
        onOpenHistory={() => setIsHistoryOpen(true)}
        historyCount={historyItems.length}
        detectedLang={detectedLanguage || undefined}
        fileName={selectedFile?.name}
        isRailOpen={isRailOpen}
        onToggleRail={() => setIsRailOpen(!isRailOpen)}
        isInspectorOpen={isInspectorOpen}
        onToggleInspector={() => setIsInspectorOpen(!isInspectorOpen)}
        isTimelineOpen={isTimelineOpen}
        onToggleTimeline={() => setIsTimelineOpen(!isTimelineOpen)}
        onOpenExport={() => setIsExportModalOpen(true)}
        hasFile={masterSubtitles.length > 0 || !!videoUrl}
        onReplayIntro={handleReplayIntro}
      />

      {/* 2. Main Studio Body Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Left Tool Rail */}
        {isRailOpen && (
          <LeftToolRail
            activeTool={activeTool}
            onSelectTool={(tool) => {
              setActiveTool(tool);
              if (tool === 'export') {
                setIsExportModalOpen(true);
              }
            }}
            hasFile={!!selectedFile}
            hasSubtitles={masterSubtitles.length > 0}
            hasDubbing={!!dubbedAudioUrl}
            isProcessing={isProcessing}
            isCollapsed={false}
            onToggleCollapse={() => {}}
            onReplayIntro={handleReplayIntro}
          />
        )}

        {/* Center Workspace Stage */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-[#050505]">
          {!selectedFile && !isProcessing && masterSubtitles.length === 0 ? (
            /* Blank Project Upload Stage */
            <div className="flex-1 overflow-y-auto p-4 lg:p-8 flex flex-col items-center justify-center custom-scrollbar">
              <div className="text-center space-y-2 mb-6 max-w-xl">
                <h2 className="text-2xl lg:text-3xl font-extrabold text-zinc-100 tracking-tight">
                  Video Translation & Voice Dubbing Studio
                </h2>
                <p className="text-xs lg:text-sm text-zinc-400">
                  Tải lên video hoặc âm thanh để tự động nhận diện ngôn ngữ, bóc băng thời gian thực chuẩn SRT và lồng tiếng AI đa nhân vật.
                </p>
              </div>

              <FileUpload onFileSelect={handleStartProcessing} isProcessing={isProcessing} />
            </div>
          ) : isProcessing || chunks.some((c) => c.status === 'processing' || c.status === 'error') ? (
            /* Active Processing Stage */
            <div className="flex-1 overflow-y-auto p-6 lg:p-12 flex flex-col items-center justify-center custom-scrollbar">
              <ProgressBar
                overallProgress={overallProgress}
                currentStage={currentStage}
                chunks={chunks}
                onRetryChunk={handleRetryChunk}
                noSpeechDetected={noSpeechDetected}
              />
            </div>
          ) : (
            /* Active Multi-Panel Studio (Video Player Center + Subtitle Table / Dubbing Studio) */
            <div className="flex-1 flex flex-col min-h-0 overflow-hidden p-3 lg:p-4 gap-3">
              {/* Stage Top Bar: Quick back and project stats */}
              <div className="flex items-center justify-between text-xs px-1">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    setVideoUrl(null);
                    setMasterSubtitles([]);
                    setChunks([]);
                    setIsProcessing(false);
                  }}
                  className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white border border-white/5 flex items-center gap-1.5 transition cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Dự Án Mới</span>
                </button>

                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/5">
                    <button
                      type="button"
                      onClick={() => setActiveTool('subtitle')}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                        activeTool !== 'voice'
                          ? 'bg-white text-black font-bold shadow'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Subtitles className="w-3.5 h-3.5" />
                      <span>Biên Tập Phụ Đề</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTool('voice')}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                        activeTool === 'voice'
                          ? 'bg-white text-black font-bold shadow'
                          : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                      <span>Lồng Tiếng AI</span>
                      {dubbedAudioUrl && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                    </button>
                  </div>

                  <button
                    type="button"
                    onClick={() => setIsExportModalOpen(true)}
                    className="px-4 py-1.5 rounded-full bg-white text-black hover:bg-zinc-200 font-extrabold text-xs transition shadow cursor-pointer"
                  >
                    Xuất File & Video
                  </button>
                </div>
              </div>

              {/* Center Split Grid: Video Player (Left/Top) & Active Tool Canvas (Right/Bottom) */}
              <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-3 min-h-0 overflow-hidden">
                {/* 1. Video Player Container */}
                <div className="lg:col-span-6 h-full flex flex-col min-h-0">
                  <VideoPlayer
                    videoUrl={videoUrl}
                    subtitles={masterSubtitles}
                    subtitleMode={subtitleMode}
                    onChangeSubtitleMode={(mode) => setSubtitleMode(mode)}
                    showSpeaker={showSpeaker}
                    onToggleSpeaker={() => setShowSpeaker(!showSpeaker)}
                    onTimeUpdate={(t) => setCurrentTime(t)}
                    seekTime={seekTime}
                    dubbedAudioUrl={dubbedAudioUrl}
                    subtitleStyle={subtitleStyle}
                    onChangeSubtitleStyle={(newStyle) => setSubtitleStyle(newStyle)}
                    onSelectVideoFile={handleAttachVideoFile}
                    fileName={selectedFile?.name}
                  />
                </div>

                {/* 2. Subtitle Editor OR Dubbing Studio Canvas */}
                <div className="lg:col-span-6 h-full flex flex-col min-h-0 overflow-y-auto custom-scrollbar">
                  {activeTool === 'voice' ? (
                    <DubbingStudio
                      subtitles={masterSubtitles}
                      videoDuration={videoDuration}
                      videoUrl={videoUrl}
                      fileName={selectedFile?.name}
                      onDubbingGenerated={(url) => setDubbedAudioUrl(url)}
                      currentDubbedAudioUrl={dubbedAudioUrl}
                      subtitleStyle={subtitleStyle}
                      onChangeSubtitleStyle={(newStyle) => setSubtitleStyle(newStyle)}
                      onSeekVideo={(sec) => setSeekTime(sec)}
                      appLogs={appLogs}
                      selectedPersonaId={selectedPersonaId}
                      onSelectPersonaId={(id) => setSelectedPersonaId(id)}
                      speechRate={speechRate}
                      onChangeSpeechRate={(rate) => setSpeechRate(rate)}
                      onUpdateSubtitles={(updated) => setMasterSubtitles(updated)}
                    />
                  ) : (
                    <SubtitleEditor
                      cues={masterSubtitles}
                      onChangeCues={(updated) => setMasterSubtitles(updated)}
                      subtitleMode={subtitleMode}
                      onChangeMode={(mode) => setSubtitleMode(mode)}
                      showSpeaker={showSpeaker}
                      onToggleSpeaker={() => setShowSpeaker(!showSpeaker)}
                      currentTime={currentTime}
                      onJumpToTime={(sec) => setSeekTime(sec)}
                      targetLanguage={transcribeOptions.targetLanguage}
                    />
                  )}
                </div>
              </div>
            </div>
          )}

          {/* 3. Bottom Multi-Track Timeline */}
          {isTimelineOpen && masterSubtitles.length > 0 && (
            <BottomTimeline
              currentTime={currentTime}
              duration={videoDuration || masterSubtitles[masterSubtitles.length - 1]?.endSeconds || 60}
              subtitles={masterSubtitles}
              activeCue={activeCue}
              onSeek={(sec) => setSeekTime(sec)}
              isPlaying={isPlaying}
              onTogglePlay={() => setIsPlaying(!isPlaying)}
              isCollapsed={isTimelineCollapsed}
              onToggleCollapse={() => setIsTimelineCollapsed(!isTimelineCollapsed)}
              onAddCue={() => {
                const last = masterSubtitles[masterSubtitles.length - 1];
                const startSec = last ? last.endSeconds + 0.2 : 0;
                const endSec = startSec + 3.0;
                const newCue: SubtitleCue = {
                  id: Date.now(),
                  start: secondsToSrtTime(startSec),
                  end: secondsToSrtTime(endSec),
                  startSeconds: startSec,
                  endSeconds: endSec,
                  speaker: 'Speaker 1',
                  text_original: 'New cue',
                  text_translated: 'Phụ đề mới',
                };
                setMasterSubtitles([...masterSubtitles, newCue]);
              }}
            />
          )}
        </div>

        {/* Right Inspector Panel */}
        {isInspectorOpen && (
          <RightInspector
            activeTool={activeTool}
            onSelectTool={(tool) => setActiveTool(tool)}
            subtitleStyle={subtitleStyle}
            onChangeSubtitleStyle={(st) => setSubtitleStyle(st)}
            subtitlesCount={masterSubtitles.length}
            transcribeOptions={transcribeOptions}
            onChangeTranscribeOptions={(opt) => setTranscribeOptions(opt)}
            targetLanguage={transcribeOptions.targetLanguage}
            onChangeTargetLanguage={(lang) =>
              setTranscribeOptions((prev) => ({ ...prev, targetLanguage: lang }))
            }
            detectedLanguage={detectedLanguage}
            cues={masterSubtitles}
            onChangeCues={(updated) => setMasterSubtitles(updated)}
            selectedPersonaId={selectedPersonaId}
            onSelectPersonaId={(id) => setSelectedPersonaId(id)}
            speechRate={speechRate}
            onChangeSpeechRate={(rate) => setSpeechRate(rate)}
            originalDucking={originalDucking}
            onChangeOriginalDucking={(ducking) => setOriginalDucking(ducking)}
            onTriggerDubbing={handleTriggerDubbing}
            isGeneratingDubbing={isGeneratingDubbing}
            dubbingProgress={dubbingProgress}
            dubbedAudioUrl={dubbedAudioUrl}
            onOpenExport={() => setIsExportModalOpen(true)}
            videoDuration={videoDuration}
            videoUrl={videoUrl}
            fileName={selectedFile?.name}
            onSelectVideoFile={handleAttachVideoFile}
          />
        )}
      </div>

      {/* Export Center Modal */}
      {isExportModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto custom-scrollbar">
            <button
              type="button"
              onClick={() => setIsExportModalOpen(false)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-white/10 text-white hover:bg-white/20 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
            <DownloadPanel
              cues={masterSubtitles}
              fileName={selectedFile?.name || 'Video_Project'}
              showSpeaker={showSpeaker}
              targetLanguage={transcribeOptions.targetLanguage}
              videoUrl={videoUrl}
              dubbedAudioUrl={dubbedAudioUrl}
              subtitleStyle={subtitleStyle}
            />
          </div>
        </div>
      )}

      {/* Session History Overlay Drawer */}
      <SessionHistory
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        historyItems={historyItems}
        onLoadHistoryItem={handleLoadHistoryItem}
        onDeleteHistoryItem={handleDeleteHistoryItem}
        onClearAllHistory={handleClearAllHistory}
      />
    </div>
  );
}
