import React, { useRef, useState, useEffect, useMemo, useCallback } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  FastForward,
  Rewind,
  ZoomIn,
  ZoomOut,
  ChevronDown,
  ChevronUp,
  Subtitles,
  Volume2,
  Film,
  Plus,
} from 'lucide-react';
import { SubtitleCue } from '../types';
import { secondsToSrtTime } from '../utils/srt';

interface BottomTimelineProps {
  currentTime: number;
  duration: number;
  subtitles: SubtitleCue[];
  activeCue: SubtitleCue | null;
  onSeek: (seconds: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onAddCue?: () => void;
}

export const BottomTimeline: React.FC<BottomTimelineProps> = ({
  currentTime,
  duration,
  subtitles,
  activeCue,
  onSeek,
  isPlaying,
  onTogglePlay,
  isCollapsed,
  onToggleCollapse,
  onAddCue,
}) => {
  const trackRef = useRef<HTMLDivElement>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1); // 1x to 4x
  const [isDraggingPlayhead, setIsDraggingPlayhead] = useState<boolean>(false);

  const safeDuration = Math.max(duration || 0, 1);

  // Time format helper
  const formatTimecode = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    const ms = Math.floor((sec % 1) * 100);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(ms).padStart(2, '0')}`;
  };

  // Timeline mouse seek handler
  const handleTimelineInteraction = useCallback(
    (clientX: number) => {
      if (!trackRef.current) return;
      const rect = trackRef.current.getBoundingClientRect();
      const clickX = clientX - rect.left;
      const percent = Math.max(0, Math.min(1, clickX / rect.width));
      const targetSec = percent * safeDuration;
      onSeek(targetSec);
    },
    [safeDuration, onSeek]
  );

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDraggingPlayhead(true);
    handleTimelineInteraction(e.clientX);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (isDraggingPlayhead) {
        handleTimelineInteraction(e.clientX);
      }
    };
    const handleMouseUp = () => {
      if (isDraggingPlayhead) {
        setIsDraggingPlayhead(false);
      }
    };

    if (isDraggingPlayhead) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDraggingPlayhead, handleTimelineInteraction]);

  // Generate visual time ruler ticks
  const rulerTicks = useMemo(() => {
    const ticks: { time: number; label: string; percent: number }[] = [];
    const intervalSec = safeDuration > 300 ? 30 : safeDuration > 60 ? 10 : 5;
    for (let t = 0; t <= safeDuration; t += intervalSec) {
      ticks.push({
        time: t,
        label: formatTimecode(t),
        percent: (t / safeDuration) * 100,
      });
    }
    return ticks;
  }, [safeDuration]);

  // Playhead percentage position
  const playheadPercent = Math.min(100, Math.max(0, (currentTime / safeDuration) * 100));

  return (
    <div className="bg-[#08080a] border-t border-white/5 flex flex-col select-none transition-all duration-200">
      {/* Timeline Controls Header */}
      <div className="px-4 py-2 flex items-center justify-between border-b border-white/5 bg-[#0a0a0d]/90 text-xs">
        {/* Playback Controls & Timecode */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1 border border-white/10">
            <button
              type="button"
              onClick={() => onSeek(Math.max(0, currentTime - 5))}
              className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition"
              title="Lùi lại 5 giây"
            >
              <Rewind className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={onTogglePlay}
              className="px-2.5 py-1 rounded bg-white text-black hover:bg-zinc-200 font-bold transition flex items-center gap-1 shadow-md cursor-pointer"
            >
              {isPlaying ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              <span className="text-[11px]">{isPlaying ? 'Pause' : 'Play'}</span>
            </button>

            <button
              type="button"
              onClick={() => onSeek(Math.min(safeDuration, currentTime + 5))}
              className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition"
              title="Tua tới 5 giây"
            >
              <FastForward className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="font-mono text-xs flex items-center gap-1 text-zinc-300">
            <span className="text-white font-bold">{formatTimecode(currentTime)}</span>
            <span className="text-zinc-600">/</span>
            <span className="text-zinc-400">{formatTimecode(safeDuration)}</span>
          </div>
        </div>

        {/* Zoom & Collapse Actions */}
        <div className="flex items-center gap-3">
          {onAddCue && (
            <button
              type="button"
              onClick={onAddCue}
              className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" /> Thêm Dòng Phụ Đề
            </button>
          )}

          <div className="hidden sm:flex items-center gap-2 text-zinc-400">
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.max(1, z - 0.5))}
              className="p-1 rounded hover:bg-white/5 hover:text-white"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[10px] font-mono">{zoomLevel}x</span>
            <button
              type="button"
              onClick={() => setZoomLevel((z) => Math.min(3, z + 0.5))}
              className="p-1 rounded hover:bg-white/5 hover:text-white"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>

          <button
            type="button"
            onClick={onToggleCollapse}
            className="p-1 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-white/5 transition"
            title={isCollapsed ? 'Mở rộng Timeline' : 'Thu gọn Timeline'}
          >
            {isCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Multi-Track Stage */}
      {!isCollapsed && (
        <div className="px-4 py-3 space-y-2 overflow-x-auto timeline-scrollbar bg-[#050505]">
          <div
            ref={trackRef}
            onMouseDown={handleMouseDown}
            style={{ width: `${zoomLevel * 100}%` }}
            className="relative min-w-full h-28 cursor-pointer select-none space-y-1.5"
          >
            {/* 1. Time Ruler */}
            <div className="h-5 relative border-b border-white/10 text-[10px] font-mono text-zinc-500">
              {rulerTicks.map((tick, i) => (
                <div
                  key={i}
                  style={{ left: `${tick.percent}%` }}
                  className="absolute top-0 transform -translate-x-1/2 flex flex-col items-center"
                >
                  <span className="text-[9px] opacity-75">{tick.label}</span>
                  <div className="w-[1px] h-1.5 bg-white/20 mt-0.5" />
                </div>
              ))}
            </div>

            {/* 2. Video Track */}
            <div className="h-6 relative rounded-lg bg-zinc-900/80 border border-white/5 flex items-center px-2 overflow-hidden">
              <Film className="w-3 h-3 text-cyan-400/80 mr-2 flex-shrink-0" />
              <div className="flex-1 h-full flex items-center gap-1 opacity-60">
                <div className="h-2 w-full bg-cyan-950/60 rounded border border-cyan-800/30" />
              </div>
              <span className="text-[9px] text-zinc-500 font-mono pl-2">VIDEO</span>
            </div>

            {/* 3. Audio Waveform Track */}
            <div className="h-6 relative rounded-lg bg-zinc-900/80 border border-white/5 flex items-center px-2 overflow-hidden">
              <Volume2 className="w-3 h-3 text-purple-400/80 mr-2 flex-shrink-0" />
              <div className="flex-1 h-3 flex items-center gap-0.5 opacity-50 overflow-hidden">
                {Array.from({ length: 80 }).map((_, idx) => (
                  <div
                    key={idx}
                    className="w-1 bg-purple-500/60 rounded-full"
                    style={{
                      height: `${15 + ((idx * 37) % 85)}%`,
                    }}
                  />
                ))}
              </div>
              <span className="text-[9px] text-zinc-500 font-mono pl-2">AUDIO</span>
            </div>

            {/* 4. Subtitle Track with Interactive Cue Blocks */}
            <div className="h-8 relative rounded-lg bg-zinc-900/80 border border-white/5 overflow-hidden">
              <div className="absolute left-2 top-2 z-0 flex items-center gap-1 opacity-40">
                <Subtitles className="w-3 h-3 text-emerald-400" />
                <span className="text-[9px] font-mono text-zinc-400">SUBTITLES ({subtitles.length})</span>
              </div>

              {/* Subtitle Cue Blocks */}
              {subtitles.map((cue) => {
                const startPercent = Math.max(0, (cue.startSeconds / safeDuration) * 100);
                const endPercent = Math.min(100, (cue.endSeconds / safeDuration) * 100);
                const widthPercent = Math.max(0.5, endPercent - startPercent);
                const isActive = activeCue?.id === cue.id;

                return (
                  <div
                    key={cue.id}
                    onClick={(e) => {
                      e.stopPropagation();
                      onSeek(cue.startSeconds);
                    }}
                    style={{
                      left: `${startPercent}%`,
                      width: `${widthPercent}%`,
                    }}
                    className={`absolute top-1 bottom-1 rounded-md px-1.5 text-[10px] flex items-center truncate cursor-pointer transition-all ${
                      isActive
                        ? 'bg-emerald-500 text-black font-extrabold shadow-lg shadow-emerald-500/30 z-20 border border-white'
                        : 'bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-200 border border-emerald-500/30 z-10'
                    }`}
                    title={`[#${cue.id}] ${cue.start} → ${cue.end}: ${cue.text_translated || cue.text_original}`}
                  >
                    <span className="truncate">{cue.text_translated || cue.text_original}</span>
                  </div>
                );
              })}
            </div>

            {/* 5. Playhead Vertical Line */}
            <div
              style={{ left: `${playheadPercent}%` }}
              className="absolute top-0 bottom-0 w-[2px] bg-white shadow-[0_0_10px_rgba(255,255,255,1)] z-30 pointer-events-none transform -translate-x-1/2"
            >
              <div className="w-3 h-3 bg-white rotate-45 transform -translate-x-[5px] -translate-y-1 shadow-md" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
