import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  Download,
  FileText,
  ShieldCheck,
  FileCode,
  Film,
  CheckCircle2,
  RefreshCw,
  Zap,
  Cpu,
  Check,
  Play,
} from 'lucide-react';
import { SubtitleCue, SubtitleStyleConfig, DEFAULT_SUBTITLE_STYLE } from '../types';
import { buildSrtContent, buildTxtContent, downloadFileWithBOM } from '../utils/srt';
import { exportDubbedVideo, directDownloadFile, ExportProgressStats, ExportResult } from '../utils/exportVideo';

interface DownloadPanelProps {
  cues: SubtitleCue[];
  fileName: string;
  showSpeaker: boolean;
  targetLanguage: string;
  videoUrl?: string | null;
  dubbedAudioUrl?: string | null;
  subtitleStyle?: SubtitleStyleConfig;
}

export const DownloadPanel: React.FC<DownloadPanelProps> = ({
  cues,
  fileName,
  showSpeaker,
  targetLanguage,
  videoUrl,
  dubbedAudioUrl,
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
}) => {
  const baseName = (fileName || 'Video_Project').replace(/\.[^/.]+$/, '');

  const [isExportingMp4, setIsExportingMp4] = useState<boolean>(false);
  const [performanceMode, setPerformanceMode] = useState<'prefer-software' | 'no-preference' | 'prefer-hardware'>('prefer-hardware');
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportStatusMsg, setExportStatusMsg] = useState<string>('');
  const [exportStats, setExportStats] = useState<ExportProgressStats | null>(null);
  const [exportResult, setExportResult] = useState<ExportResult | null>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [downloadedFormat, setDownloadedFormat] = useState<string | null>(null);

  const triggerDownloadFeedback = (formatKey: string) => {
    setDownloadedFormat(formatKey);
    setTimeout(() => {
      setDownloadedFormat(null);
    }, 2500);
  };

  const handleDownloadOriginalSrt = () => {
    const srtStr = buildSrtContent(cues, 'original', showSpeaker);
    downloadFileWithBOM(srtStr, `${baseName}_Original.srt`, 'application/x-subrip;charset=utf-8');
    triggerDownloadFeedback('original');
  };

  const handleDownloadTranslatedSrt = () => {
    const srtStr = buildSrtContent(cues, 'translated', showSpeaker);
    downloadFileWithBOM(srtStr, `${baseName}_${targetLanguage || 'Translated'}.srt`, 'application/x-subrip;charset=utf-8');
    triggerDownloadFeedback('translated');
  };

  const handleDownloadBilingualSrt = () => {
    const srtStr = buildSrtContent(cues, 'bilingual', showSpeaker);
    downloadFileWithBOM(srtStr, `${baseName}_Bilingual.srt`, 'application/x-subrip;charset=utf-8');
    triggerDownloadFeedback('bilingual');
  };

  const handleDownloadTxtTranscript = () => {
    const txtStr = buildTxtContent(cues, 'bilingual', showSpeaker);
    downloadFileWithBOM(txtStr, `${baseName}_Transcript.txt`, 'text/plain;charset=utf-8');
    triggerDownloadFeedback('txt');
  };

  const handleExportMp4Video = async () => {
    if (!videoUrl || isExportingMp4) return;
    setIsExportingMp4(true);
    setExportError(null);
    setExportResult(null);
    setExportStats(null);
    setExportProgress(3);
    setExportStatusMsg('Đang chuẩn bị môi trường xuất video...');

    try {
      const result = await exportDubbedVideo({
        videoUrl,
        dubbedAudioUrl,
        subtitles: cues,
        subtitleStyle,
        fileName: `${baseName}_Burned.mp4`,
        performanceMode,
        onProgress: (percent, msg) => {
          setExportProgress(percent);
          setExportStatusMsg(msg);
        },
        onStats: (stats) => {
          setExportStats(stats);
          setExportProgress(stats.percent);
          if (stats.message) {
            setExportStatusMsg(stats.message);
          }
        },
      });

      setExportResult(result);
      setExportProgress(100);
      setExportStatusMsg('Xuất video MP4 thành công!');
    } catch (err: any) {
      console.error('Export video error:', err);
      setExportError(err?.message || 'Có lỗi xảy ra trong quá trình xuất video.');
    } finally {
      setIsExportingMp4(false);
    }
  };

  const [isDownloadingMp4, setIsDownloadingMp4] = useState<boolean>(false);

  const handleDirectDownloadMp4 = async () => {
    if (!exportResult?.downloadUrl || isDownloadingMp4) return;
    try {
      setIsDownloadingMp4(true);
      await directDownloadFile(exportResult.downloadUrl, exportResult.fileName);
      triggerDownloadFeedback('mp4');
    } catch (e) {
      console.error(e);
    } finally {
      setIsDownloadingMp4(false);
    }
  };

  return (
    <div className="w-full bg-[#08080a] border border-white/5 rounded-3xl p-5 sm:p-6 space-y-6 shadow-2xl animate-rise select-none">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4">
        <div>
          <h3 className="font-extrabold text-zinc-100 text-base flex items-center gap-2">
            <Download className="w-5 h-5 text-cyan-400" /> Trung Tâm Xuất File & Tải Xuống
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Xuất trực tiếp phụ đề chuẩn Premiere / CapCut (UTF-8 BOM) và Video MP4 tăng tốc GPU trên trình duyệt.
          </p>
        </div>

        {/* Encoding Badge */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-semibold self-start sm:self-auto">
          <ShieldCheck className="w-4 h-4 text-emerald-400 flex-shrink-0" />
          <span>Chuẩn UTF-8 with BOM (Không lỗi dấu tiếng Việt)</span>
        </div>
      </div>

      {/* Video MP4 WebCodecs Fast Export Card */}
      {videoUrl && (
        <div className="p-5 rounded-2xl bg-[#0c0c10] border border-white/10 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Film className="w-5 h-5 text-cyan-400" />
                <h4 className="font-bold text-sm text-zinc-100">Xuất Video MP4 (Burn Phụ Đề & Lồng Tiếng)</h4>
                <span className="px-2 py-0.5 rounded-full bg-white/10 text-zinc-200 text-[10px] font-mono font-bold border border-white/10">
                  GPU WebCodecs Fast Export
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Ghép phụ đề đã căn chỉnh và luồng âm thanh lồng tiếng vào video trực tiếp bằng phần cứng thiết bị.
              </p>
            </div>

            {/* Performance Mode Selector */}
            <div className="flex items-center gap-1 bg-[#050505] p-1 rounded-full border border-white/10">
              <button
                type="button"
                onClick={() => setPerformanceMode('prefer-hardware')}
                disabled={isExportingMp4}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                  performanceMode === 'prefer-hardware'
                    ? 'bg-white text-black shadow-md'
                    : 'text-zinc-400 hover:text-zinc-200'
                } ${isExportingMp4 ? 'opacity-50 cursor-not-allowed' : ''}`}
                title="Tối đa tốc độ bằng cách sử dụng bộ mã hóa phần cứng GPU của trình duyệt"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" /> Tối Đa Tốc Độ (GPU)
              </button>

              <button
                type="button"
                onClick={() => setPerformanceMode('prefer-software')}
                disabled={isExportingMp4}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition flex items-center gap-1.5 cursor-pointer ${
                  performanceMode === 'prefer-software'
                    ? 'bg-white text-black shadow-md'
                    : 'text-zinc-400 hover:text-zinc-200'
                } ${isExportingMp4 ? 'opacity-50 cursor-not-allowed' : ''}`}
                title="Sử dụng mã hóa CPU tương thích cao trên mọi loại thiết bị"
              >
                <Cpu className="w-3.5 h-3.5 text-zinc-400" /> Tương Thích Cao (CPU)
              </button>
            </div>
          </div>

          {/* Export Action Button */}
          {!isExportingMp4 && !exportResult && (
            <button
              type="button"
              onClick={handleExportMp4Video}
              className="w-full py-3.5 px-6 rounded-full bg-white text-black hover:bg-zinc-200 font-extrabold text-sm flex items-center justify-center gap-2 shadow-[0_0_15px_rgba(255,255,255,0.15)] transition active:scale-98 cursor-pointer"
            >
              <Film className="w-4 h-4" />
              <span>Bắt Đầu Xuất Video MP4 Hoàn Thiện</span>
            </button>
          )}

          {/* Exporting Progress Indicator */}
          {isExportingMp4 && (
            <div className="space-y-3 p-4 rounded-xl bg-black/50 border border-white/5 animate-fade">
              <div className="flex items-center justify-between text-xs text-zinc-300">
                <span className="flex items-center gap-2 font-semibold">
                  <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin" />{' '}
                  {exportStatusMsg || 'Đang xuất video...'}
                </span>
                <span className="font-mono text-zinc-100 font-bold text-sm">
                  {Math.round(exportProgress)}%
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full h-2.5 rounded-full bg-zinc-800 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-150"
                  style={{ width: `${Math.max(4, exportProgress)}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
                <span>
                  {exportStats
                    ? `Khung hình: ${exportStats.currentFrame} / ${exportStats.totalFrames}`
                    : 'Đang chuẩn bị bộ đệm khung hình...'}
                </span>
                <span>{exportStats?.fps ? `${exportStats.fps.toFixed(1)} fps` : '...'}</span>
              </div>
            </div>
          )}

          {/* Export Success Banner */}
          {exportResult && (
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 space-y-3.5 shadow-inner"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                    <Check className="w-4 h-4 text-emerald-400 font-bold" />
                  </div>
                  <div>
                    <h5 className="font-extrabold text-xs text-emerald-300">Xuất Video MP4 Thành Công!</h5>
                    <p className="text-[11px] text-zinc-400">
                      Tệp MP4 đã hoàn thiện với đầy đủ âm thanh lồng tiếng & phụ đề.
                    </p>
                  </div>
                </div>

                <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold font-mono self-start sm:self-auto">
                  {exportResult.renderTime}s @ {exportResult.avgFps} FPS
                </span>
              </div>

              {/* Technical Specifications Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono bg-black/60 p-3.5 rounded-xl border border-white/5">
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">Tên tệp</span>
                  <span className="font-semibold text-emerald-100 truncate" title={exportResult.fileName}>{exportResult.fileName}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">Dung lượng</span>
                  <span className="font-semibold text-emerald-100">{(exportResult.sizeBytes / (1024 * 1024)).toFixed(2)} MB</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">Độ phân giải</span>
                  <span className="font-semibold text-emerald-100">{exportResult.resolution}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">Tăng tốc phần cứng</span>
                  <span className="font-semibold text-emerald-100">{exportResult.acceleration}</span>
                </div>
                <div className="flex flex-col gap-1">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">FPS Kết xuất</span>
                  <span className="font-semibold text-emerald-100">{exportResult.avgFps} FPS (Gốc: {exportResult.sourceFps || 30} FPS)</span>
                </div>
                <div className="flex flex-col gap-1 col-span-1 sm:col-span-3">
                  <span className="text-zinc-500 text-[10px] uppercase font-sans">Pipeline xử lý</span>
                  <span className="font-semibold text-cyan-300 truncate">{exportResult.pipeline || 'WebCodecs Decoder (Direct)'}</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => window.open(exportResult.downloadUrl, '_blank')}
                  className="px-4 py-2 rounded-full bg-white/5 hover:bg-white/10 text-zinc-200 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-white/10"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> Xem Thử Trong Tab Mới
                </button>

                <button
                  type="button"
                  onClick={handleDirectDownloadMp4}
                  disabled={isDownloadingMp4}
                  className="px-5 py-2 rounded-full bg-white text-black hover:bg-zinc-200 disabled:opacity-75 font-extrabold text-xs flex items-center gap-2 shadow-lg transition cursor-pointer active:scale-95"
                >
                  {isDownloadingMp4 ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Đang chuẩn bị tải...
                    </>
                  ) : downloadedFormat === 'mp4' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600 font-bold" /> Đã Tải Xuống
                    </>
                  ) : (
                    <>
                      <Download className="w-3.5 h-3.5" /> Tải Video Về Máy
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => setExportResult(null)}
                  className="p-2 rounded-full text-zinc-400 hover:text-white hover:bg-white/5 transition cursor-pointer ml-auto"
                  title="Xuất lại video"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}

          {exportError && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center justify-between gap-2">
              <span>{exportError}</span>
              <button
                type="button"
                onClick={handleExportMp4Video}
                className="px-3 py-1 rounded-full bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-semibold cursor-pointer"
              >
                Thử Lại
              </button>
            </div>
          )}
        </div>
      )}

      {/* Subtitle File Exports Grid */}
      <div className="space-y-3">
        <h4 className="text-xs font-extrabold uppercase tracking-wider text-zinc-400">
          Tải Xuống Tệp Phụ Đề Chuyên Nghiệp (.SRT / .TXT)
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* 1. Song Ngu */}
          <button
            type="button"
            onClick={handleDownloadBilingualSrt}
            className="p-4 rounded-2xl bg-[#0c0c10] hover:bg-[#121216] border border-white/5 hover:border-white/15 text-left transition space-y-2 group cursor-pointer active:scale-98"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-cyan-400 group-hover:text-white transition">
                <FileCode className="w-4 h-4" />
              </div>
              {downloadedFormat === 'bilingual' && (
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 animate-fade">
                  <Check className="w-3 h-3" /> Đã Tải
                </span>
              )}
            </div>
            <div>
              <span className="font-bold text-xs text-zinc-200 block">SRT Song Ngữ</span>
              <span className="text-[11px] text-zinc-500">Gốc + {targetLanguage || 'Bản dịch'}</span>
            </div>
          </button>

          {/* 2. Ban Dich */}
          <button
            type="button"
            onClick={handleDownloadTranslatedSrt}
            className="p-4 rounded-2xl bg-[#0c0c10] hover:bg-[#121216] border border-white/5 hover:border-white/15 text-left transition space-y-2 group cursor-pointer active:scale-98"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-emerald-400 group-hover:text-white transition">
                <FileText className="w-4 h-4" />
              </div>
              {downloadedFormat === 'translated' && (
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 animate-fade">
                  <Check className="w-3 h-3" /> Đã Tải
                </span>
              )}
            </div>
            <div>
              <span className="font-bold text-xs text-zinc-200 block">SRT Bản Dịch</span>
              <span className="text-[11px] text-zinc-500">Chỉ hiển thị {targetLanguage || 'Bản dịch'}</span>
            </div>
          </button>

          {/* 3. Tieng Goc */}
          <button
            type="button"
            onClick={handleDownloadOriginalSrt}
            className="p-4 rounded-2xl bg-[#0c0c10] hover:bg-[#121216] border border-white/5 hover:border-white/15 text-left transition space-y-2 group cursor-pointer active:scale-98"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400 group-hover:text-white transition">
                <FileText className="w-4 h-4" />
              </div>
              {downloadedFormat === 'original' && (
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 animate-fade">
                  <Check className="w-3 h-3" /> Đã Tải
                </span>
              )}
            </div>
            <div>
              <span className="font-bold text-xs text-zinc-200 block">SRT Tiếng Gốc</span>
              <span className="text-[11px] text-zinc-500">Bản transcript bóc băng gốc</span>
            </div>
          </button>

          {/* 4. TXT Transcript */}
          <button
            type="button"
            onClick={handleDownloadTxtTranscript}
            className="p-4 rounded-2xl bg-[#0c0c10] hover:bg-[#121216] border border-white/5 hover:border-white/15 text-left transition space-y-2 group cursor-pointer active:scale-98"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-amber-400 group-hover:text-white transition">
                <FileText className="w-4 h-4" />
              </div>
              {downloadedFormat === 'txt' && (
                <span className="text-[10px] text-emerald-400 font-bold flex items-center gap-1 animate-fade">
                  <Check className="w-3 h-3" /> Đã Tải
                </span>
              )}
            </div>
            <div>
              <span className="font-bold text-xs text-zinc-200 block">Văn Bản Thuần (.TXT)</span>
              <span className="text-[11px] text-zinc-500">Toàn bộ lời thoại kịch bản</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};
