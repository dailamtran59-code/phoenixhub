import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import {
  SubtitleCue,
  VOICE_PERSONAS,
  VoicePersona,
  VoicePersonaId,
  SubtitleStyleConfig,
  DEFAULT_SUBTITLE_STYLE,
  SubtitleFontFamily,
  SubtitleGlowEffect,
  SubtitleBgStyle,
  SubtitlePosition,
} from '../types';
import { computeSubtitleCssStyle, computeSubtitleBgClass, stripSpeakerPrefix } from '../utils/subtitleStyle';
import { LogsPanel } from './LogsPanel';
import { exportDubbedVideo, directDownloadFile, ExportProgressStats, ExportResult } from '../utils/exportVideo';
import { assembleDubbedAudioBuffer, audioBufferToWavBlob } from '../utils/audio';
import { DubbingSyncReport, analyzeDubbingSync, globalTtsCache } from '../utils/dubTimingEngine';
import { DubbingSyncReportModal } from './DubbingSyncReportModal';
import {
  Volume2,
  Play,
  Pause,
  Download,
  Sparkles,
  Check,
  RefreshCw,
  Clock,
  Layers,
  Wand2,
  FileAudio,
  Radio,
  Type,
  Palette,
  Sun,
  Square,
  Sliders,
  Eye,
  Film,
  AlertTriangle,
  Move,
  Zap,
  Cpu,
  BarChart3,
} from 'lucide-react';

interface DubbingStudioProps {
  subtitles: SubtitleCue[];
  videoDuration: number;
  videoUrl?: string | null;
  fileName?: string;
  onDubbingGenerated?: (audioUrl: string | null) => void;
  currentDubbedAudioUrl?: string | null;
  subtitleStyle?: SubtitleStyleConfig;
  onChangeSubtitleStyle?: (newStyle: SubtitleStyleConfig) => void;
  onSeekVideo?: (seconds: number) => void;
  appLogs?: { ocrTime: number; translateTime: number };
  selectedPersonaId?: VoicePersonaId;
  onSelectPersonaId?: (id: VoicePersonaId) => void;
  speechRate?: number;
  onChangeSpeechRate?: (rate: number) => void;
  onUpdateSubtitles?: (updated: SubtitleCue[]) => void;
}

export const DubbingStudio: React.FC<DubbingStudioProps> = ({
  subtitles: initialSubtitles,
  videoDuration,
  videoUrl,
  fileName,
  onDubbingGenerated,
  currentDubbedAudioUrl,
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
  onChangeSubtitleStyle,
  onSeekVideo,
  appLogs,
  selectedPersonaId: propPersonaId,
  onSelectPersonaId,
  speechRate: propSpeechRate,
  onChangeSpeechRate,
  onUpdateSubtitles,
}) => {
  const [subtitles, setSubtitles] = useState<SubtitleCue[]>(initialSubtitles);
  
  // Keep original subtitles in sync with props
  React.useEffect(() => {
    setSubtitles(initialSubtitles);
  }, [initialSubtitles]);

  const [logs, setLogs] = useState({
    ocrTime: 0,
    translateTime: 0,
    ttsTime: 0,
    audioDuration: 0,
    subtitleDuration: 0,
    renderFps: 0,
    eta: 0,
    gpuUsage: 'FFmpeg hw-accel'
  });

  // Sync app logs
  React.useEffect(() => {
    if (appLogs) {
      setLogs(prev => ({ ...prev, ocrTime: appLogs.ocrTime, translateTime: appLogs.translateTime }));
    }
  }, [appLogs]);

  const [selectedPersonaId, setSelectedPersonaId] = useState<VoicePersonaId>(propPersonaId || 'female_lively');
  
  React.useEffect(() => {
    if (propPersonaId) {
      setSelectedPersonaId(propPersonaId);
    }
  }, [propPersonaId]);

  const handlePersonaChange = (id: VoicePersonaId) => {
    setSelectedPersonaId(id);
    if (onSelectPersonaId) {
      onSelectPersonaId(id);
    }
  };

  const [selectedTtsModel, setSelectedTtsModel] = useState<string>('gemini-3.1-flash-tts-preview');
  const [useTranslated, setUseTranslated] = useState<boolean>(true);
  const [autoSync, setAutoSync] = useState<boolean>(true);
  const [allowFallbackEngine, setAllowFallbackEngine] = useState<boolean>(true);
  const [fallbackTriggered, setFallbackTriggered] = useState<boolean>(false);
  const [syncReport, setSyncReport] = useState<DubbingSyncReport | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Volume customization state
  const [masterDubbingVolume, setMasterDubbingVolume] = useState<number>(1.0); // 0.2 to 2.0 (20% - 200%)
  const [cuePreviewVolume, setCuePreviewVolume] = useState<number>(1.0);     // 0.0 to 1.5 (0% - 150%)
  const [perCueVolumes, setPerCueVolumes] = useState<Record<number, number>>({});

  // Speed customization state
  const [masterSpeakingSpeed, setMasterSpeakingSpeed] = useState<number>(propSpeechRate || 1.0); // 0.5 to 2.0 (50% - 200%)
  
  React.useEffect(() => {
    if (propSpeechRate !== undefined) {
      setMasterSpeakingSpeed(propSpeechRate);
    }
  }, [propSpeechRate]);

  const handleSpeedChange = (speed: number) => {
    setMasterSpeakingSpeed(speed);
    if (onChangeSpeechRate) {
      onChangeSpeechRate(speed);
    }
  };

  const [perCueSpeeds, setPerCueSpeeds] = useState<Record<number, number>>({});


  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [progressPercent, setProgressPercent] = useState<number>(0);
  const [currentStepMsg, setCurrentStepMsg] = useState<string>('');

  const [isExportingMp4, setIsExportingMp4] = useState<boolean>(false);
  const [performanceMode, setPerformanceMode] = useState<'prefer-software' | 'no-preference' | 'prefer-hardware'>('prefer-hardware');
  const [exportMsg, setExportMsg] = useState<string>('');
  const [exportResult, setExportResult] = useState<any>(null);
  const [exportError, setExportError] = useState<string | null>(null);
  const [exportEstimatedTime, setExportEstimatedTime] = useState<string | null>(null);
  const exportStartTimeRef = useRef<number | null>(null);
  const [autoClean, setAutoClean] = useState<boolean>(true);
  const [previewingPersonaId, setPreviewingPersonaId] = useState<string | null>(null);
  const [previewingCueId, setPreviewingCueId] = useState<number | null>(null);

  const [dubbedAudioUrl, setDubbedAudioUrl] = useState<string | null>(currentDubbedAudioUrl || null);
  const [isPlayingFull, setIsPlayingFull] = useState<boolean>(false);
  const [quotaExhaustedNotice, setQuotaExhaustedNotice] = useState<string | null>(null);
  const [isRemixing, setIsRemixing] = useState<boolean>(false);

  const activeAudioRef = useRef<HTMLAudioElement | null>(null);
  const cachedTtsResultsRef = useRef<{ cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[] | null>(null);

  const selectedPersona = VOICE_PERSONAS.find((p) => p.id === selectedPersonaId) || VOICE_PERSONAS[0];

  // Auto-remix when volume or speed settings change, assuming TTS results are cached
  React.useEffect(() => {
    if (!dubbedAudioUrl || !cachedTtsResultsRef.current || isGenerating) return;

    const timer = setTimeout(() => {
      handleRemixAudio(cachedTtsResultsRef.current!);
    }, 800);

    return () => clearTimeout(timer);
  }, [perCueVolumes, masterDubbingVolume, perCueSpeeds, masterSpeakingSpeed]);

  // Shared audio assembly function guaranteeing strict timestamp synchronization with the original video
  const assembleDubbedAudio = async (
    ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[],
    validCues: SubtitleCue[]
  ): Promise<AudioBuffer> => {
    return await assembleDubbedAudioBuffer({
      ttsResults,
      validCues,
      videoDuration,
      masterVolume: masterDubbingVolume,
      masterSpeakingSpeed,
      perCueVolumes,
      perCueSpeeds,
    });
  };

  const handleRemixAudio = async (cachedResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[]) => {
    if (!subtitles || subtitles.length === 0) return;
    setIsRemixing(true);
    
    try {
      const validCues = subtitles.filter((c) => (useTranslated ? c.text_translated : c.text_original)?.trim());
      const masterAudioBuffer = await assembleDubbedAudio(cachedResults, validCues);

      const wavBlob = audioBufferToWavBlob(masterAudioBuffer);
      const finalUrl = URL.createObjectURL(wavBlob);

      setDubbedAudioUrl(finalUrl);
      if (onDubbingGenerated) {
        onDubbingGenerated(finalUrl);
      }
    } catch (err) {
      console.error('Remixing failed:', err);
    } finally {
      setIsRemixing(false);
    }
  };

  // Safely stop all active playing audio preview streams to prevent stacking/overlap bugs
  const stopAllAudio = () => {
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.pause();
        activeAudioRef.current.onended = null;
        activeAudioRef.current.onerror = null;
        activeAudioRef.current.currentTime = 0;
      } catch {
        // ignore
      }
      activeAudioRef.current = null;
    }
    setPreviewingPersonaId(null);
    setPreviewingCueId(null);
    setIsPlayingFull(false);
  };

  // Clean up audio on component unmount
  React.useEffect(() => {
    return () => {
      stopAllAudio();
    };
  }, []);

  const updateStyle = (key: keyof SubtitleStyleConfig, value: any) => {
    if (onChangeSubtitleStyle) {
      onChangeSubtitleStyle({
        ...subtitleStyle,
        [key]: value,
      });
    }
  };

  const [exportStats, setExportStats] = useState<ExportProgressStats | null>(null);
  const [isDownloadingMp4, setIsDownloadingMp4] = useState<boolean>(false);
  const [downloadSuccessFeedback, setDownloadSuccessFeedback] = useState<boolean>(false);

  // Export video download handler
  const handleDownloadMp4 = async () => {
    if (!exportResult?.downloadUrl || isDownloadingMp4) return;
    try {
      setIsDownloadingMp4(true);
      setExportMsg('Đang kích hoạt tải trực tiếp...');
      await directDownloadFile(exportResult.downloadUrl, exportResult.fileName || 'video.mp4');
      setDownloadSuccessFeedback(true);
      setExportMsg('Tải file thành công!');
      setTimeout(() => setDownloadSuccessFeedback(false), 3000);
    } catch (e) {
      console.error(e);
      setExportMsg('Lỗi khi tải file. Vui lòng thử lại.');
    } finally {
      setIsDownloadingMp4(false);
    }
  };

  const handleExportMp4 = async () => {
    if (!videoUrl) {
      alert('Vui lòng gắn file Video từ máy tính ở khung xem trước để xuất file MP4!');
      return;
    }
    setIsExportingMp4(true);
    setExportError(null);
    setExportResult(null);
    setExportStats(null);
    setExportMsg('');
    setProgressPercent(0);
    setExportEstimatedTime(null);
    exportStartTimeRef.current = Date.now();
    try {
      const res = await exportDubbedVideo({
        videoUrl,
        dubbedAudioUrl,
        subtitles,
        subtitleStyle,
        fileName,
        performanceMode,
        onProgress: (p, msg) => {
          setExportMsg(msg);
          setProgressPercent(p);
        },
        onStats: (stats) => {
          setExportStats(stats);
          if (stats.etaSeconds !== null) {
            const m = Math.floor(stats.etaSeconds / 60);
            const s = stats.etaSeconds % 60;
            setExportEstimatedTime(m > 0 ? `Còn ~${m}p ${s}s (${stats.fps} FPS)` : `Còn ~${s}s (${stats.fps} FPS)`);
          } else {
            setExportEstimatedTime(null);
          }
        },
      });
      setExportResult(res);
      setLogs(prev => ({
        ...prev,
        renderTime: res.renderTime,
        outputSize: res.sizeBytes,
        renderFps: res.avgFps,
      }));
    } catch (err: any) {
      setExportError(err?.message || 'Có lỗi khi xuất Video MP4');
    } finally {
      setIsExportingMp4(false);
    }
  };

  // Play sample voice for a persona
  const handlePlayPersonaSample = async (persona: VoicePersona, e: React.MouseEvent) => {
    e.stopPropagation();
    if (previewingPersonaId === persona.id) {
      stopAllAudio();
      return;
    }

    stopAllAudio();

    try {
      setPreviewingPersonaId(persona.id);
      const res = await fetch('/api/tts/single', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: persona.sampleText,
          voiceName: persona.voiceName,
          stylePrompt: persona.stylePrompt,
        }),
      });

      const data = await res.json();
      if (data.audioBase64) {
        const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
        audio.volume = Math.max(0, Math.min(1.0, cuePreviewVolume));
        activeAudioRef.current = audio;
        audio.onended = () => {
          setPreviewingPersonaId(null);
          activeAudioRef.current = null;
        };
        audio.onerror = () => {
          setPreviewingPersonaId(null);
          activeAudioRef.current = null;
        };
        await audio.play();
      } else {
        setPreviewingPersonaId(null);
      }
    } catch {
      setPreviewingPersonaId(null);
    }
  };

  // Preview TTS for a specific subtitle cue line with custom volume
  const handlePlayCueSample = async (cue: SubtitleCue) => {
    if (previewingCueId === cue.id) {
      stopAllAudio();
      return;
    }

    stopAllAudio();

    const rawText = (useTranslated ? (cue.text_translated || cue.text_original) : (cue.text_original || cue.text_translated)) || '';
    const textToRead = stripSpeakerPrefix(rawText).trim();
    if (!textToRead) return;

    try {
      setPreviewingCueId(cue.id);
      const res = await fetch('/api/tts/single', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: textToRead,
          voiceName: selectedPersona.voiceName,
          stylePrompt: selectedPersona.stylePrompt,
          model: selectedTtsModel,
          allowFallback: allowFallbackEngine,
        }),
      });

      const data = await res.json();
      if (data.isQuotaFallback) {
        setFallbackTriggered(true);
      }
      if (data.audioBase64) {
        const audio = new Audio(`data:audio/wav;base64,${data.audioBase64}`);
        const customCueScale = perCueVolumes[cue.id] ?? cue.customVolume ?? 1.0;
        audio.volume = Math.max(0, Math.min(1.0, cuePreviewVolume * customCueScale));
        
        const customCueSpeed = perCueSpeeds[cue.id] ?? masterSpeakingSpeed;
        audio.defaultPlaybackRate = customCueSpeed;
        audio.playbackRate = customCueSpeed;
        audio.addEventListener('canplay', () => {
          audio.playbackRate = customCueSpeed;
        });

        activeAudioRef.current = audio;
        audio.onended = () => {
          setPreviewingCueId(null);
          activeAudioRef.current = null;
        };
        audio.onerror = () => {
          setPreviewingCueId(null);
          activeAudioRef.current = null;
        };
        await audio.play();
      } else {
        setPreviewingCueId(null);
      }
    } catch {
      setPreviewingCueId(null);
    }
  };

  // Generate complete dubbed audio track for full video
  const handleGenerateFullDubbing = async () => {
    if (!subtitles || subtitles.length === 0) return;

    stopAllAudio();
    setIsGenerating(true);
    setFallbackTriggered(false);
    setProgressPercent(0);
    setCurrentStepMsg('Khởi tạo quy trình lồng tiếng AI...');
    const startTime = performance.now();

    try {
      const getCueText = (c: SubtitleCue) => {
        const raw = (useTranslated ? (c.text_translated || c.text_original) : (c.text_original || c.text_translated)) || '';
        return stripSpeakerPrefix(raw).trim();
      };

      const validCues = subtitles.filter((c) => getCueText(c).length > 0);
      if (validCues.length === 0) {
        setCurrentStepMsg('Không có nội dung phụ đề để lồng tiếng.');
        setIsGenerating(false);
        return;
      }

      const totalCount = validCues.length;
      const ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[] = [];

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxClass({ sampleRate: 44100 });
      if (audioCtx.state === 'suspended') {
        try {
          await audioCtx.resume();
        } catch {
          // ignore
        }
      }

      // Process with rolling concurrency pool (CONCURRENCY = 5)
      const CONCURRENCY = 5;
      let nextIndex = 0;
      let completedCount = 0;

      async function fetchTtsForCue(cue: SubtitleCue, text: string) {
        const cueSpeed = perCueSpeeds[cue.id] ?? masterSpeakingSpeed;
        const cached = globalTtsCache.get(text, selectedPersona.voiceName, selectedTtsModel, cueSpeed);
        if (cached) {
          return {
            cueId: cue.id,
            startSeconds: cue.startSeconds,
            endSeconds: cue.endSeconds,
            audioBuffer: cached.buffer,
          };
        }

        for (let attempt = 1; attempt <= 4; attempt++) {
          try {
            const res = await fetch('/api/tts/single', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                text: text,
                voiceName: selectedPersona.voiceName,
                stylePrompt: selectedPersona.stylePrompt,
                model: selectedTtsModel,
                allowFallback: allowFallbackEngine,
              }),
            });

            const data = await res.json();
            if (data.isQuotaFallback || data.engine === 'fallback-gt') {
              setFallbackTriggered(true);
            }
            if (res.ok && data.audioBase64) {
              const binary = atob(data.audioBase64);
              const bytes = new Uint8Array(binary.length);
              for (let b = 0; b < binary.length; b++) {
                bytes[b] = binary.charCodeAt(b);
              }
              const audioBuffer = await audioCtx.decodeAudioData(bytes.buffer.slice(0));

              // Cache for fast re-use
              globalTtsCache.set(
                text,
                selectedPersona.voiceName,
                selectedTtsModel,
                cueSpeed,
                audioBuffer,
                data.engine || 'gemini-3.1'
              );

              return {
                cueId: cue.id,
                startSeconds: cue.startSeconds,
                endSeconds: cue.endSeconds,
                audioBuffer,
              };
            }
            if (res.status === 429 && attempt < 4) {
              await new Promise((resolve) => setTimeout(resolve, 1500 * attempt));
              continue;
            }
          } catch {
            if (attempt < 4) {
              await new Promise((resolve) => setTimeout(resolve, 1000 * attempt));
              continue;
            }
          }
        }
        return null;
      }

      async function worker() {
        while (nextIndex < validCues.length) {
          const myIndex = nextIndex++;
          const cue = validCues[myIndex];
          const text = getCueText(cue);
          if (text) {
            const result = await fetchTtsForCue(cue, text);
            if (result) {
              ttsResults.push(result);
            }
          }
          completedCount++;
          setCurrentStepMsg(`Đang lồng tiếng câu ${completedCount} / ${totalCount}...`);
          setProgressPercent(Math.round((completedCount / totalCount) * 85));
        }
      }

      const poolSize = Math.min(CONCURRENCY, validCues.length);
      await Promise.all(Array.from({ length: poolSize }, () => worker()));

      if (ttsResults.length === 0) {
        setCurrentStepMsg('Không nhận được dữ liệu âm thanh từ server. Vui lòng thử lại.');
        setIsGenerating(false);
        return;
      }

      setCurrentStepMsg('Đang ghép ngắt nhịp, cân bằng âm lượng và đồng bộ timeline theo Video...');
      setProgressPercent(90);

      const masterAudioBuffer = await assembleDubbedAudio(ttsResults, validCues);

      // Generate Auto Sync Diagnostic Report
      const report = analyzeDubbingSync({
        cues: validCues,
        ttsResults,
        masterAudioDuration: masterAudioBuffer.duration,
        masterSpeakingSpeed,
        perCueSpeeds,
        perCueVolumes,
      });
      setSyncReport(report);

      const wavBlob = audioBufferToWavBlob(masterAudioBuffer);
      const finalUrl = URL.createObjectURL(wavBlob);

      cachedTtsResultsRef.current = ttsResults;

      setDubbedAudioUrl(finalUrl);
      if (onDubbingGenerated) {
        onDubbingGenerated(finalUrl);
      }

      setProgressPercent(100);
      setCurrentStepMsg('Lồng tiếng thành công! File đã sẵn sàng.');
      
      const ttsTime = (performance.now() - startTime) / 1000;
      const subtitleDuration = subtitles.reduce((acc, curr) => acc + (curr.endSeconds - curr.startSeconds), 0);
      
      setLogs(prev => ({
        ...prev,
        ttsTime,
        audioDuration: masterAudioBuffer.duration,
        subtitleDuration
      }));
    } catch (err) {
      console.error('Full dubbing failed:', err);
      setCurrentStepMsg('Có lỗi xảy ra khi lồng tiếng. Vui lòng thử lại.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Helper to convert AudioBuffer to WAV Blob
  const audioBufferToWavBlob = (buffer: AudioBuffer): Blob => {
    const numChannels = buffer.numberOfChannels;
    const sampleRate = buffer.sampleRate;
    const format = 1; // PCM
    const bitDepth = 16;

    let result: Float32Array;
    if (numChannels === 2) {
      const left = buffer.getChannelData(0);
      const right = buffer.getChannelData(1);
      result = new Float32Array(left.length + right.length);
      for (let i = 0; i < left.length; i++) {
        result[i * 2] = left[i];
        result[i * 2 + 1] = right[i];
      }
    } else {
      result = buffer.getChannelData(0);
    }

    const dataLength = result.length * (bitDepth / 8);
    const headerLength = 44;
    const wav = new Uint8Array(headerLength + dataLength);
    const view = new DataView(wav.buffer);

    // RIFF identifier
    view.setUint32(0, 0x52494646, false); // "RIFF"
    view.setUint32(4, 36 + dataLength, true);
    view.setUint32(8, 0x57415645, false); // "WAVE"
    // fmt subchunk
    view.setUint32(12, 0x666d7420, false); // "fmt "
    view.setUint32(16, 16, true); // Subchunk1Size
    view.setUint16(20, format, true); // AudioFormat
    view.setUint16(22, numChannels, true);
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * numChannels * (bitDepth / 8), true);
    view.setUint16(32, numChannels * (bitDepth / 8), true);
    view.setUint16(34, bitDepth, true);
    // data subchunk
    view.setUint32(36, 0x64617461, false); // "data"
    view.setUint32(40, dataLength, true);

    // Write samples
    let offset = 44;
    for (let i = 0; i < result.length; i++) {
      let s = Math.max(-1, Math.min(1, result[i]));
      s = s < 0 ? s * 0x8000 : s * 0x7fff;
      view.setInt16(offset, s, true);
      offset += 2;
    }

    return new Blob([wav], { type: 'audio/wav' });
  };

  const handleTogglePlayFull = () => {
    if (!dubbedAudioUrl) return;
    if (isPlayingFull) {
      stopAllAudio();
    } else {
      stopAllAudio();
      const audio = new Audio(dubbedAudioUrl);
      audio.volume = Math.max(0, Math.min(1.0, masterDubbingVolume));
      activeAudioRef.current = audio;
      audio.onended = () => {
        setIsPlayingFull(false);
        activeAudioRef.current = null;
      };
      audio.onerror = () => {
        setIsPlayingFull(false);
        activeAudioRef.current = null;
      };
      audio.play().catch(() => setIsPlayingFull(false));
      setIsPlayingFull(true);
    }
  };

  return (
    <div className="bg-[#08080a] border border-white/5 rounded-3xl p-5 md:p-6 shadow-2xl space-y-6 text-zinc-100 select-none animate-fade">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/5">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-400 animate-pulse" />
            <h2 className="text-base font-extrabold text-zinc-100">AI Studio Lồng Tiếng (TTS Dubbing)</h2>
            <span className="bg-white/5 text-zinc-300 text-[10px] font-semibold px-2.5 py-0.5 rounded-full border border-white/10">
              Gemini Audio Engine & Direct Sync
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Chọn nhân vật lồng tiếng ưa thích, tự động khớp nhịp ngắt nghỉ chuẩn xác theo từng câu thoại video.
          </p>
        </div>

        {dubbedAudioUrl && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTogglePlayFull}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white text-black hover:bg-zinc-200 rounded-full text-xs font-bold transition shadow cursor-pointer active:scale-98"
            >
              {isPlayingFull ? <Pause className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {isPlayingFull ? 'Dừng phát' : 'Nghe thử bản Lồng Tiếng'}
            </button>
            <a
              href={dubbedAudioUrl}
              download="Video_AI_Dubbing.wav"
              className="flex items-center gap-1.5 px-3.5 py-2 bg-white/5 hover:bg-white/10 text-emerald-300 border border-emerald-500/20 rounded-full text-xs font-semibold transition"
            >
              <Download className="w-3.5 h-3.5" />
              Tải File Audio (.wav)
            </a>
          </div>
        )}
      </div>

      {/* Quota Exceeded Notification Banner */}
      {quotaExhaustedNotice && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 flex items-start gap-3 shadow-lg">
          <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-1 text-xs">
            <h4 className="font-bold text-amber-200">Thông báo Token Quota AI Hôm Nay</h4>
            <p className="leading-relaxed">{quotaExhaustedNotice}</p>
          </div>
        </div>
      )}

      {/* Select Voice Personas */}
      <div>
        <label className="text-xs font-semibold text-zinc-300 mb-3 flex items-center gap-1.5">
          <Wand2 className="w-4 h-4 text-cyan-400" />
          Chọn Nhân Vật Lồng Tiếng (Voice Persona):
        </label>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {VOICE_PERSONAS.map((persona) => {
            const isSelected = selectedPersonaId === persona.id;
            const isPreviewing = previewingPersonaId === persona.id;

            return (
              <div
                key={persona.id}
                onClick={() => setSelectedPersonaId(persona.id)}
                className={`relative p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#121218] border-white/30 ring-1 ring-white/20 shadow-xl shadow-black/60'
                    : 'bg-[#0d0d10] border-white/5 hover:border-white/15 hover:bg-[#121216]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-zinc-100 flex items-center gap-1.5">
                      {persona.gender === 'female' ? '👧' : '👨'} {persona.name}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-white/5 text-zinc-300 border border-white/10">
                      {persona.badge}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-relaxed mb-3">{persona.description}</p>
                </div>

                <div className="flex items-center justify-between pt-2.5 border-t border-white/5 mt-auto">
                  <button
                    type="button"
                    onClick={(e) => handlePlayPersonaSample(persona, e)}
                    className={`flex items-center gap-1 text-[11px] px-3 py-1.5 rounded-full transition font-semibold cursor-pointer ${
                      isPreviewing
                        ? 'bg-emerald-400 text-black font-bold'
                        : 'bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white'
                    }`}
                  >
                    {isPreviewing ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin" /> Đang phát...
                      </>
                    ) : (
                      <>
                        <Volume2 className="w-3 h-3 text-cyan-400" /> Nghe thử giọng
                      </>
                    )}
                  </button>

                  {isSelected && (
                    <span className="flex items-center gap-1 text-[11px] text-white font-bold">
                      <Check className="w-3.5 h-3.5 text-emerald-400" /> Đã chọn
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dubbing Options & Controls */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4 sm:p-5 bg-[#0c0c10] border border-white/5 rounded-2xl">
        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Nguồn văn bản lồng tiếng:</label>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setUseTranslated(true)}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition cursor-pointer ${
                useTranslated
                  ? 'bg-white text-black border-white shadow-sm'
                  : 'bg-white/5 text-zinc-400 border-white/5 hover:text-zinc-200 hover:bg-white/10'
              }`}
            >
              Tiếng Việt / Bản dịch
            </button>
            <button
              type="button"
              onClick={() => setUseTranslated(false)}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition cursor-pointer ${
                !useTranslated
                  ? 'bg-white text-black border-white shadow-sm'
                  : 'bg-white/5 text-zinc-400 border-white/5 hover:text-zinc-200 hover:bg-white/10'
              }`}
            >
              Văn bản gốc
            </button>
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Mô hình AI Lồng Tiếng (TTS Model):</label>
          <div className="flex items-center gap-2">
            <select
              value={selectedTtsModel}
              onChange={(e) => setSelectedTtsModel(e.target.value)}
              className="w-full bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2.5 focus:border-white/30 focus:outline-none cursor-pointer font-medium"
            >
              <option value="gemini-3.1-flash-tts-preview">Gemini 3.1 Flash TTS (Diễn Cảm Tự Nhiên)</option>
              <option value="fallback-gt">Google Speech Engine (Tốc Độ Nhanh & Ổn Định)</option>
            </select>
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Đồng bộ nhịp ngắt nghỉ:</label>
          <label className="flex items-center gap-2 py-2 px-3 bg-[#121216] border border-white/10 rounded-xl cursor-pointer hover:bg-white/5">
            <input
              type="checkbox"
              checked={autoSync}
              onChange={(e) => setAutoSync(e.target.checked)}
              className="w-4 h-4 text-white rounded accent-white"
            />
            <span className="text-xs text-zinc-300 font-medium">
              Tự động co giãn tốc độ & ghép khoảng lặng chuẩn nhịp theo SRT Video
            </span>
          </label>
        </div>

        <div>
          <label className="text-xs font-semibold text-zinc-300 block mb-1.5">Engine dự phòng khi quá tải:</label>
          <label className="flex items-center gap-2 py-2 px-3 bg-[#121216] border border-white/10 rounded-xl cursor-pointer hover:bg-white/5">
            <input
              type="checkbox"
              checked={allowFallbackEngine}
              onChange={(e) => setAllowFallbackEngine(e.target.checked)}
              className="w-4 h-4 text-white rounded accent-white"
            />
            <span className="text-xs text-zinc-300 font-medium">
              Cho phép tự động dùng Google Speech TTS khi Gemini TTS bị giới hạn Quota 429
            </span>
          </label>
        </div>

        {fallbackTriggered && (
          <div className="sm:col-span-2 lg:col-span-3 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center gap-2.5 text-amber-300 text-xs">
            <span className="text-sm">⚠️</span>
            <span>Đã kích hoạt giọng đọc dự phòng (Google Speech TTS) cho một số câu thoại do Gemini TTS đạt giới hạn hạn mức yêu cầu.</span>
          </div>
        )}

        {/* Master Volume & Speed Controls */}
        <div className="sm:col-span-2 lg:col-span-3 pt-3 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="space-y-1.5 bg-white/5 p-3.5 rounded-xl border border-white/5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-amber-400" /> Âm Lượng Lồng Tiếng AI:
              </span>
              <span className="font-bold text-amber-400 font-mono">{Math.round(masterDubbingVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min={0.2}
              max={2.0}
              step={0.05}
              value={masterDubbingVolume}
              onChange={(e) => setMasterDubbingVolume(parseFloat(e.target.value))}
              className="w-full accent-amber-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-zinc-500">
              <span>20% (Nhỏ)</span>
              <span>100% (Chuẩn)</span>
              <span>200% (Khuếch đại)</span>
            </div>
          </div>

          <div className="space-y-1.5 bg-white/5 p-3.5 rounded-xl border border-white/5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> Âm Lượng Nghe Thử Đoạn:
              </span>
              <span className="font-bold text-cyan-400 font-mono">{Math.round(cuePreviewVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min={0.0}
              max={1.5}
              step={0.05}
              value={cuePreviewVolume}
              onChange={(e) => setCuePreviewVolume(parseFloat(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
            />
            <div className="flex justify-between text-[10px] text-zinc-500">
              <span>0% (Tắt tiếng)</span>
              <span>100% (Chuẩn)</span>
              <span>150% (Tối đa)</span>
            </div>
          </div>

          <div className="space-y-2 bg-white/5 p-3.5 rounded-xl border border-white/5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-400" /> Tốc Độ Đọc Mặc Định:
              </span>
              <span className="font-bold text-emerald-400 font-mono">{masterSpeakingSpeed.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min={0.5}
              max={2.0}
              step={0.05}
              value={masterSpeakingSpeed}
              onChange={(e) => handleSpeedChange(parseFloat(e.target.value))}
              className="w-full accent-emerald-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
            />
            <div className="flex items-center justify-between gap-1 pt-1">
              {[0.75, 1.0, 1.25, 1.5].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => handleSpeedChange(preset)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold transition cursor-pointer ${
                    Math.abs(masterSpeakingSpeed - preset) < 0.04
                      ? 'bg-emerald-500 text-black shadow font-bold'
                      : 'bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  {preset.toFixed(2)}x
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Subtitle Customization Panel */}
      <div className="p-5 bg-[#09090c] border border-white/5 rounded-3xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">
              Tùy Chỉnh Phụ Đề Hiển Thị (Font, Màu Sắc, Viền & Ánh Sáng)
            </h3>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">Real-time sync to player</span>
        </div>

        {/* Live Subtitle Style Preview Box */}
        <div className="relative w-full h-24 rounded-2xl bg-[#050507] border border-white/10 flex items-center justify-center p-4 overflow-hidden">
          <div className="absolute top-2 left-2 flex items-center gap-1.5 text-[10px] text-zinc-400 font-semibold bg-white/5 px-2 py-0.5 rounded-full border border-white/5">
            <Eye className="w-3 h-3 text-cyan-400" /> Demo Trực Quan
          </div>

          <div
            style={computeSubtitleCssStyle(subtitleStyle)}
            className={`max-w-md text-center font-semibold leading-snug rounded-xl px-4 py-2 transition-all ${computeSubtitleBgClass(
              subtitleStyle.bgStyle
            )}`}
          >
            Lồng Tiếng AI Studio - Trải Nghiệm Chất Lượng Cao
          </div>
        </div>

        {/* Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs pt-1">
          {/* 1. Phông chữ (Font Family) */}
          <div className="space-y-1.5">
            <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5 text-cyan-400" /> Phông Chữ (Font Family):
            </label>
            <select
              value={subtitleStyle.fontFamily}
              onChange={(e) => updateStyle('fontFamily', e.target.value as SubtitleFontFamily)}
              className="w-full bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2.5 focus:border-white/30 focus:outline-none cursor-pointer"
            >
              <option value="sans">Modern Sans-Serif (Mặc định)</option>
              <option value="serif">Playfair Serif (Sang trọng / Cổ điển)</option>
              <option value="impact">Impact Shorts / TikTok (Nổi bật YouTube)</option>
              <option value="montserrat">Montserrat (Năng động / Trẻ trung)</option>
              <option value="space">Space Grotesk (Hiện đại / Công nghệ)</option>
              <option value="mono">Monospace Code (Mã máy tính)</option>
            </select>
          </div>

          {/* 2. Cỡ chữ (Font Size) */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span className="flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Cỡ Chữ:
              </span>
              <span className="text-zinc-100 font-mono font-bold">{subtitleStyle.fontSize}px</span>
            </div>
            <input
              type="range"
              min={14}
              max={44}
              value={subtitleStyle.fontSize}
              onChange={(e) => updateStyle('fontSize', Number(e.target.value))}
              className="w-full accent-white cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
            />
          </div>

          {/* 3. Màu chữ (Text Color) */}
          <div className="space-y-1.5">
            <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
              <Palette className="w-3.5 h-3.5 text-cyan-400" /> Màu Chữ:
            </label>
            <div className="flex items-center gap-2">
              {['#FFFFFF', '#FACC15', '#06B6D4', '#10B981', '#EC4899', '#F59E0B'].map((colorHex) => (
                <button
                  key={colorHex}
                  type="button"
                  onClick={() => updateStyle('textColor', colorHex)}
                  style={{ backgroundColor: colorHex }}
                  className={`w-6 h-6 rounded-full border-2 transition transform hover:scale-110 cursor-pointer ${
                    subtitleStyle.textColor === colorHex ? 'border-white scale-110 ring-2 ring-white/50' : 'border-zinc-800'
                  }`}
                  title={colorHex}
                />
              ))}
              <input
                type="color"
                value={subtitleStyle.textColor}
                onChange={(e) => updateStyle('textColor', e.target.value)}
                className="w-7 h-7 rounded bg-transparent cursor-pointer border-none"
                title="Chọn màu tùy ý"
              />
            </div>
          </div>

          {/* 4. Viền chữ (Text Outline / Stroke) */}
          <div className="space-y-1.5">
            <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
              <Square className="w-3.5 h-3.5 text-cyan-400" /> Viền Chữ (Outline):
            </label>
            <div className="flex items-center gap-2">
              <select
                value={subtitleStyle.strokeColor}
                onChange={(e) => updateStyle('strokeColor', e.target.value)}
                className="flex-1 bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2 focus:border-white/30 focus:outline-none cursor-pointer"
              >
                <option value="#000000">Viền Đen</option>
                <option value="#ffffff">Viền Trắng</option>
                <option value="#ef4444">Viền Đỏ</option>
                <option value="#3b82f6">Viền Xanh</option>
                <option value="none">Không Viền</option>
              </select>

              <select
                value={subtitleStyle.strokeWidth}
                onChange={(e) => updateStyle('strokeWidth', Number(e.target.value))}
                className="w-20 bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2 focus:border-white/30 focus:outline-none cursor-pointer"
              >
                <option value={0}>0px</option>
                <option value={1}>1px</option>
                <option value={2}>2px</option>
                <option value={3}>3px</option>
                <option value={4}>4px</option>
              </select>
            </div>
          </div>

          {/* 5. Độ sáng bóng (Glow Effect) */}
          <div className="space-y-1.5">
            <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
              <Sun className="w-3.5 h-3.5 text-cyan-400" /> Hiệu Ứng Ánh Sáng / Bóng Đổ:
            </label>
            <select
              value={subtitleStyle.glowEffect}
              onChange={(e) => updateStyle('glowEffect', e.target.value as SubtitleGlowEffect)}
              className="w-full bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2.5 focus:border-white/30 focus:outline-none cursor-pointer"
            >
              <option value="soft">Ánh Tự Nhiên (Soft Shadow)</option>
              <option value="neon">Đèn Neon Cyan Sắc Nét</option>
              <option value="gold">Ánh Kim Vàng (Gold)</option>
              <option value="intense">Bóng Đổ Đậm 3D (Intense)</option>
              <option value="none">Không Bóng (Flat)</option>
            </select>
          </div>

          {/* 6. Khung nền & Vị trí */}
          <div className="space-y-1.5">
            <label className="text-zinc-300 font-semibold flex items-center gap-1.5">
              <Square className="w-3.5 h-3.5 text-cyan-400" /> Khung Nền & Vị Trí:
            </label>
            <div className="flex items-center gap-2">
              <select
                value={subtitleStyle.bgStyle}
                onChange={(e) => updateStyle('bgStyle', e.target.value as SubtitleBgStyle)}
                className="flex-1 bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2 focus:border-white/30 focus:outline-none cursor-pointer"
              >
                <option value="black-translucent">Nền Đen Mờ 80%</option>
                <option value="black-solid">Nền Đen Đậm</option>
                <option value="glass">Kính Mờ (Glass)</option>
                <option value="blur">Làm Mờ Nền (Blur)</option>
                <option value="none">Không Nền</option>
              </select>

              <select
                value={subtitleStyle.position}
                onChange={(e) => {
                  const pos = e.target.value as SubtitlePosition;
                  const newY = pos === 'top' ? 12 : pos === 'middle' ? 50 : 82;
                  if (onChangeSubtitleStyle) {
                    onChangeSubtitleStyle({
                      ...subtitleStyle,
                      position: pos,
                      positionY: newY,
                    });
                  }
                }}
                className="w-24 bg-[#121216] border border-white/10 text-zinc-200 text-xs rounded-xl p-2 focus:border-white/30 focus:outline-none cursor-pointer"
              >
                <option value="bottom">Ở Dưới</option>
                <option value="middle">Ở Giữa</option>
                <option value="top">Ở Trên</option>
              </select>
            </div>
          </div>

          {/* 6.1 Cường độ làm mờ nền phụ đề (chỉ hiện khi chọn style "blur") */}
          {subtitleStyle.bgStyle === 'blur' && (
            <div className="space-y-1.5">
              <div className="flex justify-between text-zinc-300 font-semibold">
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" /> Cường Độ Làm Mờ (Blur):
                </span>
                <span className="text-cyan-400 font-bold">{(subtitleStyle.blurIntensity !== undefined ? subtitleStyle.blurIntensity : 14)}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={30}
                value={subtitleStyle.blurIntensity !== undefined ? subtitleStyle.blurIntensity : 14}
                onChange={(e) => updateStyle('blurIntensity', Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
              />
            </div>
          )}

          {/* 7. Vị trí di chuyển chiều cao (PositionY Slider) */}
          <div className="space-y-1.5 md:col-span-2 lg:col-span-3 pt-2 border-t border-white/5">
            <div className="flex justify-between text-zinc-300 font-semibold">
              <span className="flex items-center gap-1.5">
                <Move className="w-3.5 h-3.5 text-cyan-400" /> Tùy Chỉnh Cao Độ Phụ Đề (Khung hình Video):
              </span>
              <span className="text-zinc-100 font-mono font-bold">{subtitleStyle.positionY ?? 82}% chiều cao</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-[10px] text-zinc-500">Trên cùng (5%)</span>
              <input
                type="range"
                min={5}
                max={92}
                value={subtitleStyle.positionY ?? 82}
                onChange={(e) => updateStyle('positionY', Number(e.target.value))}
                className="flex-1 accent-white cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
              />
              <span className="text-[10px] text-zinc-500">Dưới cùng (92%)</span>
            </div>
            <p className="text-[10px] text-zinc-500">
              Mẹo: Bạn có thể kéo thả trực tiếp khung chữ phụ đề trên màn hình Xem trước để căn chỉnh tọa độ chính xác.
            </p>
          </div>
        </div>
      </div>

      {/* Main Action Button */}
      <div className="space-y-3">
        <button
          type="button"
          onClick={handleGenerateFullDubbing}
          disabled={isGenerating || subtitles.length === 0}
          className={`w-full py-4 px-6 rounded-full font-extrabold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer ${
            isGenerating || subtitles.length === 0
              ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed border border-white/5'
              : 'bg-white text-black hover:bg-zinc-200 shadow-xl active:scale-98'
          }`}
        >
          {isGenerating ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-black" />
              {currentStepMsg}
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              Tạo File Lồng Tiếng AI Toàn Bộ Video ({subtitles.length} câu phụ đề)
            </>
          )}
        </button>

        {isGenerating && (
          <div className="space-y-1.5">
            <div className="w-full h-2 bg-black rounded-full overflow-hidden border border-white/10">
              <div
                className="h-full bg-white transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="flex justify-between text-[11px] text-zinc-400 font-mono">
              <span>{currentStepMsg}</span>
              <span className="font-bold text-white">{progressPercent}%</span>
            </div>
          </div>
        )}

        {/* Dubbing Sync Report Card */}
        {syncReport && (
          <div className="p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  Báo Cáo Đồng Bộ Lồng Tiếng AI (Auto Sync Report)
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                    {syncReport.syncHealthScore}% Chuẩn
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">
                  {syncReport.perfectCues} khớp chuẩn • {syncReport.naturalPausesCues} có ngắt nghỉ • {syncReport.overlappingCues} mix song song • {syncReport.trimmedCues} fade-out
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsReportModalOpen(true)}
              className="px-4 py-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer self-end sm:self-auto"
            >
              <BarChart3 className="w-3.5 h-3.5" /> Xem Chi Tiết Báo Cáo
            </button>
          </div>
        )}

        {/* MP4 Export Section */}
        <div className="p-5 rounded-3xl bg-[#09090c] border border-white/5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Film className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-zinc-100 uppercase tracking-wider">Xuất Video MP4 Hoàn Chỉnh</h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Tải Video MP4 đã ghép giọng Lồng Tiếng AI & Phụ đề chuẩn nhịp khung hình.
                </p>

                <div className="mt-3 flex flex-col gap-2">
                  <span className="text-xs font-semibold text-zinc-300">Chế độ hiệu năng phần cứng:</span>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <label className="flex items-center gap-2 text-[11px] text-zinc-300 cursor-pointer">
                      <input type="radio" name="perfMode" checked={performanceMode === 'prefer-software'} onChange={() => setPerformanceMode('prefer-software')} className="accent-emerald-400" />
                      Tiết Kiệm Máy (CPU)
                    </label>
                    <label className="flex items-center gap-2 text-[11px] text-zinc-300 cursor-pointer">
                      <input type="radio" name="perfMode" checked={performanceMode === 'no-preference'} onChange={() => setPerformanceMode('no-preference')} className="accent-emerald-400" />
                      Cân Bằng (Mặc định)
                    </label>
                    <label className="flex items-center gap-2 text-[11px] text-zinc-300 cursor-pointer">
                      <input type="radio" name="perfMode" checked={performanceMode === 'prefer-hardware'} onChange={() => setPerformanceMode('prefer-hardware')} className="accent-emerald-400" />
                      Tối Đa Tốc Độ (GPU)
                    </label>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="autoClean"
                    checked={autoClean}
                    onChange={(e) => setAutoClean(e.target.checked)}
                    className="w-4 h-4 rounded border-white/20 bg-zinc-800 text-emerald-400 accent-emerald-400"
                  />
                  <label htmlFor="autoClean" className="text-[11px] text-zinc-400 select-none cursor-pointer">
                    Auto Clean Temporary Files (Tự giải phóng bộ nhớ đệm sau khi tải)
                  </label>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleExportMp4}
              disabled={isExportingMp4 || !videoUrl || isRemixing}
              className={`px-5 py-3 rounded-full font-extrabold text-xs flex items-center gap-2 transition whitespace-nowrap cursor-pointer ${
                isExportingMp4 || !videoUrl || isRemixing
                  ? 'bg-zinc-800 text-zinc-500 border border-white/5 cursor-not-allowed'
                  : 'bg-emerald-400 hover:bg-emerald-300 text-black shadow-lg shadow-emerald-950/30 active:scale-95'
              }`}
            >
              {isExportingMp4 ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-black" />
                  Đang xuất MP4...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  Tải File Video MP4
                </>
              )}
            </button>
          </div>

          {/* Export Progress */}
          {isExportingMp4 && (
            <div className="mt-4 p-4 rounded-2xl bg-[#050507] border border-white/10 space-y-2.5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-emerald-400 flex items-center gap-2">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
                  {exportMsg || 'Đang xuất Video MP4...'}
                </span>
                {exportStats && (
                  <span className="font-mono text-zinc-300 font-bold">
                    {exportStats.currentFrame} / {exportStats.totalFrames} frames ({exportStats.fps} FPS)
                  </span>
                )}
              </div>

              <div className="w-full bg-zinc-900 rounded-full h-2 overflow-hidden border border-white/5">
                <div 
                  className="bg-emerald-400 h-2 rounded-full relative transition-all duration-200 ease-out" 
                  style={{ width: progressPercent > 0 ? `${progressPercent}%` : '5%' }}
                />
              </div>

              <div className="flex justify-between items-center text-[11px] text-zinc-400 font-mono">
                <span>{exportStats?.codec ? `Codec: ${exportStats.codec} (${exportStats.acceleration})` : 'WebCodecs Hardware GPU'}</span>
                {exportEstimatedTime && (
                  <span className="text-emerald-400 font-semibold">{exportEstimatedTime}</span>
                )}
              </div>
            </div>
          )}

          {/* Export Result Success Card */}
          {exportResult && !isExportingMp4 && (
             <motion.div
               initial={{ opacity: 0, scale: 0.97, y: 8 }}
               animate={{ opacity: 1, scale: 1, y: 0 }}
               transition={{ duration: 0.35, ease: 'easeOut' }}
               className="mt-4 p-5 border border-emerald-500/30 rounded-2xl bg-emerald-950/20 shadow-inner"
             >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                   <div className="flex items-center gap-2.5">
                     <div className="w-7 h-7 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center flex-shrink-0">
                       <Check className="w-4 h-4 text-emerald-400 font-bold" />
                     </div>
                     <div>
                       <h4 className="font-extrabold text-emerald-300 text-sm">Xuất Video MP4 Hoàn Tất!</h4>
                       <p className="text-[11px] text-zinc-400">Video đã nhúng phụ đề & lồng tiếng hoàn chỉnh trực tiếp trên máy.</p>
                     </div>
                   </div>
                   <div className="flex items-center gap-2">
                     <span className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-xs font-bold font-mono">
                       {exportResult.renderTime}s @ {exportResult.avgFps} FPS
                     </span>
                   </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono mb-4 bg-black/60 p-3.5 rounded-xl border border-white/5">
                   <div className="flex flex-col gap-1">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">Tên tệp</span>
                      <span className="font-semibold text-emerald-100 truncate" title={exportResult.fileName}>{exportResult.fileName}</span>
                   </div>
                   <div className="flex flex-col gap-1">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">Dung lượng</span>
                      <span className="font-semibold text-emerald-100">{(exportResult.sizeBytes / (1024*1024)).toFixed(2)} MB</span>
                   </div>
                   <div className="flex flex-col gap-1">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">Độ phân giải</span>
                      <span className="font-semibold text-emerald-100">{exportResult.resolution}</span>
                   </div>
                   <div className="flex flex-col gap-1">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">Tăng tốc phần cứng</span>
                      <span className="font-semibold text-emerald-100">{exportResult.acceleration}</span>
                   </div>
                   <div className="flex flex-col gap-1">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">FPS Kết xuất</span>
                      <span className="font-semibold text-emerald-100">{exportResult.avgFps} FPS (Gốc: {exportResult.sourceFps || 30} FPS)</span>
                   </div>
                   <div className="flex flex-col gap-1 col-span-1 sm:col-span-3">
                      <span className="text-zinc-500 text-[10px] uppercase font-sans">Pipeline xử lý</span>
                      <span className="font-semibold text-cyan-300 truncate">{exportResult.pipeline || 'WebCodecs Decoder (Direct)'}</span>
                   </div>
                </div>
                
                <div className="flex flex-wrap items-center gap-2">
                   <button 
                     type="button"
                     onClick={() => window.open(exportResult.downloadUrl, '_blank')}
                     className="px-4 py-2 bg-white/5 hover:bg-white/10 text-zinc-200 rounded-full text-xs font-bold transition flex items-center gap-1.5 cursor-pointer border border-white/10"
                   >
                      <Play className="w-3.5 h-3.5 fill-current" /> Xem Thử Trong Tab Mới
                   </button>
                   <button 
                     type="button"
                     onClick={handleDownloadMp4}
                     disabled={isDownloadingMp4}
                     className="px-5 py-2 bg-white text-black hover:bg-zinc-200 disabled:opacity-75 rounded-full text-xs font-extrabold transition flex items-center gap-2 shadow-lg cursor-pointer active:scale-95"
                   >
                      {isDownloadingMp4 ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Đang chuẩn bị tải...
                        </>
                      ) : downloadSuccessFeedback ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-600 font-bold" /> Đã Kích Hoạt Tải Xuống!
                        </>
                      ) : (
                        <>
                          <Download className="w-3.5 h-3.5" /> Tải Trực Tiếp MP4
                        </>
                      )}
                   </button>
                </div>
             </motion.div>
          )}

          {/* Export Result Error Card */}
          {exportError && !isExportingMp4 && (
             <div className="mt-4 p-4 border border-red-500/30 rounded-2xl bg-red-950/20 shadow-inner">
                <div className="flex items-center gap-2 mb-2">
                   <div className="w-6 h-6 rounded-full bg-red-500/20 flex items-center justify-center">
                     <span className="text-red-400 text-sm">✕</span>
                   </div>
                   <h4 className="font-bold text-red-300 text-sm">Export Failed</h4>
                </div>
                <p className="text-xs text-red-200/80 font-mono">
                   {exportError}
                </p>
             </div>
          )}

          {isRemixing && (
            <div className="p-3 rounded-xl bg-indigo-950/30 border border-indigo-500/30 text-xs text-indigo-300 flex items-center gap-2 shadow-inner">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-400 flex-shrink-0" />
              <span className="font-medium">Đang tự động cập nhật lại bản mix âm thanh...</span>
            </div>
          )}

        </div>
      </div>

      {/* Cue Preview Table */}
      <div className="space-y-3 pt-3 border-t border-white/5">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            Danh Sách Câu Thoại • Nghe Thử & Tùy Chỉnh Âm Lượng Đoạn
          </h3>
          <span className="text-[11px] text-zinc-500 font-mono">{subtitles.length} câu phụ đề</span>
        </div>

        <div className="max-h-72 overflow-y-auto space-y-2.5 pr-1 text-xs">
          {subtitles.map((cue, idx) => {
            const isPlayingThisCue = previewingCueId === cue.id;
            const textToDisplay = useTranslated ? cue.text_translated : cue.text_original;
            const cueVolMult = perCueVolumes[cue.id] ?? cue.customVolume ?? 1.0;

            return (
              <div
                key={cue.id}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isPlayingThisCue
                    ? 'bg-[#121218] border-white/30 ring-1 ring-white/20 shadow-lg'
                    : 'bg-[#0d0d10] border-white/5 hover:border-white/10'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-mono text-zinc-300 bg-white/5 px-2.5 py-0.5 rounded-full border border-white/5 font-bold">
                      #{idx + 1} ({cue.start} → {cue.end})
                    </span>
                    {cue.speaker && (
                      <span className="text-[10px] text-amber-300 bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/20 font-medium">
                        🗣️ {cue.speaker}
                      </span>
                    )}
                  </div>

                  {/* Actions for this cue segment */}
                  <div className="flex items-center gap-2">
                    {/* 1. Play TTS sample button */}
                    <button
                      type="button"
                      onClick={() => handlePlayCueSample(cue)}
                      className={`px-3 py-1 rounded-full text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                        isPlayingThisCue
                          ? 'bg-amber-400 text-black shadow-md'
                          : 'bg-white/5 hover:bg-white/15 text-zinc-300 hover:text-white'
                      }`}
                    >
                      {isPlayingThisCue ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Dừng nghe
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3.5 h-3.5 text-cyan-400" /> Nghe thử đoạn này
                        </>
                      )}
                    </button>

                    {/* 2. Jump Video Player to Cue Start Time */}
                    {videoUrl && onSeekVideo && (
                      <button
                        type="button"
                        onClick={() => onSeekVideo(cue.startSeconds)}
                        className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white border border-white/5 rounded-full text-[11px] font-medium transition flex items-center gap-1 cursor-pointer"
                        title="Phát video từ thời điểm câu thoại này"
                      >
                        <Play className="w-3 h-3 text-emerald-400 fill-current" /> Phát Video
                      </button>
                    )}
                  </div>
                </div>

                {/* Subtitle text */}
                <p className="text-zinc-200 text-xs leading-relaxed font-medium mb-2 pl-0.5">{textToDisplay}</p>

                {/* Per-cue volume and speed sliders */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2.5 border-t border-white/5 text-[11px]">
                  {/* Volume Slider */}
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-400 font-medium flex items-center gap-1 flex-shrink-0 min-w-[110px]">
                      <Volume2 className="w-3.5 h-3.5 text-amber-400" /> Âm lượng:
                    </span>
                    <input
                      type="range"
                      min={0.2}
                      max={1.8}
                      step={0.05}
                      value={cueVolMult}
                      onChange={(e) => {
                        const newVol = parseFloat(e.target.value);
                        setPerCueVolumes((prev) => ({
                          ...prev,
                          [cue.id]: newVol,
                        }));
                      }}
                      className="flex-1 accent-amber-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
                    />
                    <span className="text-amber-400 font-mono font-bold min-w-[32px] text-right">
                      {Math.round(cueVolMult * 100)}%
                    </span>
                  </div>

                  {/* Speed Slider */}
                  <div className="flex items-center gap-2">
                    <span className="text-zinc-400 font-medium flex items-center gap-1 flex-shrink-0 min-w-[110px]">
                      <Clock className="w-3.5 h-3.5 text-emerald-400" /> Tốc độ đọc:
                    </span>
                    <input
                      type="range"
                      min={0.5}
                      max={2.0}
                      step={0.05}
                      value={perCueSpeeds[cue.id] ?? masterSpeakingSpeed}
                      onChange={(e) => {
                        const newSpeed = parseFloat(e.target.value);
                        setPerCueSpeeds((prev) => ({
                          ...prev,
                          [cue.id]: newSpeed,
                        }));
                      }}
                      className="flex-1 accent-emerald-400 cursor-pointer h-1.5 bg-zinc-800 rounded-lg"
                    />
                    <span className="text-emerald-400 font-mono font-bold min-w-[32px] text-right">
                      {(perCueSpeeds[cue.id] ?? masterSpeakingSpeed).toFixed(2)}x
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
        <LogsPanel logs={logs} />
      </div>

      <DubbingSyncReportModal
        report={syncReport}
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
      />
    </div>
  );
};
