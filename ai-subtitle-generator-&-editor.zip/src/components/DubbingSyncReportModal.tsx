import React, { useState } from 'react';
import {
  X,
  CheckCircle2,
  AlertTriangle,
  Layers,
  Sparkles,
  Search,
  Zap,
} from 'lucide-react';
import { DubbingSyncReport } from '../utils/dubTimingEngine';

interface DubbingSyncReportModalProps {
  report: DubbingSyncReport | null;
  isOpen: boolean;
  onClose: () => void;
}

export const DubbingSyncReportModal: React.FC<DubbingSyncReportModalProps> = ({
  report,
  isOpen,
  onClose,
}) => {
  const [filter, setFilter] = useState<'ALL' | 'PERFECT' | 'NATURAL_PAUSE' | 'FADE_OUT_TRIMMED' | 'OVERLAPPED_MIXED'>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen || !report) return null;

  const filteredDiagnostics = report.diagnostics.filter((d) => {
    if (filter !== 'ALL' && d.status !== filter) return false;
    if (searchQuery.trim()) {
      return d.text.toLowerCase().includes(searchQuery.toLowerCase()) || String(d.cueId).includes(searchQuery);
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-[#0f0f13] border border-white/10 w-full max-w-4xl max-h-[85vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-white/10 flex items-center justify-between bg-[#14141a]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Báo Cáo Đồng Bộ Lồng Tiếng AI
                <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  {report.syncHealthScore}% Độ chuẩn xác
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Phân tích khớp nhịp thời gian giữa câu thoại phụ đề gốc và âm thanh lồng tiếng AI
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Metric Cards */}
        <div className="p-4 sm:p-5 grid grid-cols-2 sm:grid-cols-4 gap-3 bg-[#0d0d11] border-b border-white/5">
          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="text-[11px] text-zinc-400 mb-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Hoàn hảo
            </div>
            <div className="text-lg font-bold text-white font-mono">{report.perfectCues}</div>
            <div className="text-[10px] text-emerald-400/80">Khớp chuẩn mốc thời gian</div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="text-[11px] text-zinc-400 mb-1 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-cyan-400" /> Ngắt nghỉ tự nhiên
            </div>
            <div className="text-lg font-bold text-white font-mono">{report.naturalPausesCues}</div>
            <div className="text-[10px] text-cyan-400/80">Có khoảng lặng đệm</div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="text-[11px] text-zinc-400 mb-1 flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-purple-400" /> Mix đa nhân vật
            </div>
            <div className="text-lg font-bold text-white font-mono">{report.overlappingCues}</div>
            <div className="text-[10px] text-purple-400/80">Nói cùng lúc không cắt</div>
          </div>

          <div className="p-3 bg-white/5 rounded-xl border border-white/5">
            <div className="text-[11px] text-zinc-400 mb-1 flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" /> Fade-out êm dịu
            </div>
            <div className="text-lg font-bold text-white font-mono">{report.trimmedCues}</div>
            <div className="text-[10px] text-amber-400/80">Cắt êm tránh chạm câu sau</div>
          </div>
        </div>

        {/* Filters & Search */}
        <div className="p-4 border-b border-white/5 flex flex-wrap items-center justify-between gap-3 bg-[#111116]">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {(
              [
                ['ALL', 'Tất cả', report.totalCues],
                ['PERFECT', 'Chuẩn', report.perfectCues],
                ['NATURAL_PAUSE', 'Ngắt nghỉ', report.naturalPausesCues],
                ['OVERLAPPED_MIXED', 'Trùng đa giọng', report.overlappingCues],
                ['FADE_OUT_TRIMMED', 'Fade-out', report.trimmedCues],
              ] as const
            ).map(([key, label, count]) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
                  filter === key
                    ? 'bg-white text-black font-bold shadow'
                    : 'bg-white/5 text-zinc-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {label}
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${filter === key ? 'bg-black/20 text-black font-mono' : 'bg-white/10 text-zinc-300 font-mono'}`}>
                  {count}
                </span>
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm theo ID hoặc nội dung..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#16161d] border border-white/10 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder:text-zinc-500 focus:outline-none focus:border-white/30 font-medium"
            />
          </div>
        </div>

        {/* Diagnostics Table */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {filteredDiagnostics.length === 0 ? (
            <div className="text-center py-12 text-xs text-zinc-500">
              Không tìm thấy câu thoại nào khớp với bộ lọc hiện tại.
            </div>
          ) : (
            filteredDiagnostics.map((d) => {
              const startFormatted = `${Math.floor(d.startSeconds / 60)}:${(d.startSeconds % 60).toFixed(1).padStart(4, '0')}`;
              const endFormatted = `${Math.floor(d.endSeconds / 60)}:${(d.endSeconds % 60).toFixed(1).padStart(4, '0')}`;

              let badge = (
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Chuẩn xác
                </span>
              );

              if (d.status === 'NATURAL_PAUSE') {
                badge = (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    Nghỉ {d.silenceGapSec?.toFixed(2)}s
                  </span>
                );
              } else if (d.status === 'OVERLAPPED_MIXED') {
                badge = (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                    Mix song song
                  </span>
                );
              } else if (d.status === 'FADE_OUT_TRIMMED') {
                badge = (
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    Fade {d.fadeMs}ms
                  </span>
                );
              }

              return (
                <div
                  key={d.cueId}
                  className="p-3 bg-[#131318] border border-white/5 rounded-xl hover:border-white/10 transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-xs font-mono text-zinc-300 font-bold">
                      #{d.cueId}
                    </span>
                    <div>
                      <div className="text-xs text-white font-medium line-clamp-2 max-w-lg">
                        {d.text}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-zinc-400 font-mono">
                        <span>{startFormatted} ➔ {endFormatted}</span>
                        <span>•</span>
                        <span>Khung: {d.allocatedSlotSec.toFixed(2)}s</span>
                        <span>•</span>
                        <span>Audio: {d.actualDurationSec.toFixed(2)}s</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {badge}
                    <span className="text-[10px] text-zinc-500 font-mono px-2 py-0.5 bg-white/5 rounded">
                      {d.speedMultiplier.toFixed(2)}x
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-white/10 flex items-center justify-between bg-[#14141a] text-xs text-zinc-400">
          <div>
            Tổng thời lượng phụ đề: <span className="text-white font-mono font-bold">{report.totalOriginalSubtitleDuration.toFixed(1)}s</span> | Master Audio: <span className="text-white font-mono font-bold">{report.totalMasterAudioDuration.toFixed(1)}s</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-white text-black font-bold text-xs rounded-xl hover:bg-zinc-200 transition cursor-pointer"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
