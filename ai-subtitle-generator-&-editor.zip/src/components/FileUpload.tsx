import React, { useState, useRef } from 'react';
import {
  Upload,
  FileVideo,
  Users,
  Languages,
  Clock,
  Sparkles,
  AlertCircle,
  FileCheck,
  Search,
  CheckCircle2,
  Volume2,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { TARGET_LANGUAGES, TranscribeOptions, DetailedLanguageInfo } from '../types';
import { decodeFileAudioBuffer, decodeFileSampleBuffer, audioBufferToWavBase64 } from '../utils/audio';

interface FileUploadProps {
  onFileSelect: (file: File, videoDuration: number, options: TranscribeOptions) => void;
  isProcessing: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect, isProcessing }) => {
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoDuration, setVideoDuration] = useState<number>(0);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);

  const [isDetectingLang, setIsDetectingLang] = useState<boolean>(false);
  const [detectedInfo, setDetectedInfo] = useState<DetailedLanguageInfo | null>(null);
  const [detectError, setDetectError] = useState<string | null>(null);

  const [options, setOptions] = useState<TranscribeOptions>({
    sourceLanguage: 'auto',
    targetLanguage: 'Vietnamese',
    enableDiarization: true,
    chunkDurationMinutes: 3,
    maxCharsPerLine: 42,
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateAndHandleFile = (file: File) => {
    setFileError(null);
    setDetectedInfo(null);
    setDetectError(null);
    const maxSizeBytes = 500 * 1024 * 1024; // 500MB

    if (file.size > maxSizeBytes) {
      setFileError('Kích thước file vượt quá giới hạn 500MB. Vui lòng tải lên video nhẹ hơn.');
      return;
    }

    const isVideoOrAudio =
      file.type.startsWith('video/') ||
      file.type.startsWith('audio/') ||
      file.name.endsWith('.mp4') ||
      file.name.endsWith('.mkv') ||
      file.name.endsWith('.mov') ||
      file.name.endsWith('.avi') ||
      file.name.endsWith('.webm') ||
      file.name.endsWith('.mp3') ||
      file.name.endsWith('.wav');

    if (!isVideoOrAudio) {
      setFileError('Định dạng tệp không được hỗ trợ. Vui lòng tải file MP4, WebM, MOV hoặc Audio.');
      return;
    }

    setSelectedFile(file);

    const url = URL.createObjectURL(file);
    setVideoPreviewUrl(url);

    const tempVideo = document.createElement('video');
    tempVideo.preload = 'metadata';
    tempVideo.src = url;
    tempVideo.onloadedmetadata = () => {
      setVideoDuration(tempVideo.duration || 0);
    };
    tempVideo.onerror = () => {
      setVideoDuration(0);
    };
  };

  const handleQuickDetectLanguage = async () => {
    if (!selectedFile) return;
    setIsDetectingLang(true);
    setDetectError(null);

    try {
      const audioBuffer = await decodeFileSampleBuffer(selectedFile);
      const wavBase64 = audioBufferToWavBase64(audioBuffer, 0, Math.min(15, audioBuffer.duration || 15));

      const res = await fetch('/api/detect-language', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: wavBase64,
          mimeType: 'audio/wav',
        }),
      });

      if (!res.ok) {
        throw new Error(`Mã lỗi máy chủ: ${res.status}`);
      }

      const data: DetailedLanguageInfo = await res.json();
      setDetectedInfo(data);

      if (data.detectedLanguage) {
        setOptions((prev) => ({
          ...prev,
          sourceLanguage: data.detectedLanguage,
        }));
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      setDetectError(`Nhận diện ngôn ngữ thất bại: ${msg}`);
    } finally {
      setIsDetectingLang(false);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndHandleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      validateAndHandleFile(e.target.files[0]);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds: number) => {
    if (!seconds) return 'Đang tính...';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const hrs = Math.floor(mins / 60);
    if (hrs > 0) {
      return `${hrs}h ${mins % 60}m ${secs}s`;
    }
    return `${mins}m ${secs}s`;
  };

  const handleSubmit = () => {
    if (selectedFile) {
      onFileSelect(selectedFile, videoDuration, options);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 animate-rise">
      {/* Upload Drag & Drop Area */}
      <div
        id="drag-drop-upload-zone"
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => !selectedFile && fileInputRef.current?.click()}
        className={`relative border-2 border-dashed rounded-3xl p-8 lg:p-12 text-center transition-all duration-200 cursor-pointer ${
          dragActive
            ? 'border-white bg-white/10 scale-[1.01]'
            : selectedFile
            ? 'border-white/20 bg-[#0d0d10]'
            : 'border-white/10 hover:border-white/20 bg-[#0a0a0c] hover:bg-[#0f0f12]'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="video/mp4,video/webm,video/quicktime,video/x-msvideo,audio/*,.mp4,.mkv,.mov,.webm,.mp3,.wav"
          onChange={handleFileChange}
          className="hidden"
          disabled={isProcessing}
        />

        {!selectedFile ? (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-100 shadow-xl">
              <Upload className="w-7 h-7" />
            </div>
            <div>
              <h3 className="text-lg lg:text-xl font-extrabold text-zinc-100 tracking-tight">
                Kéo thả file Video vào đây hoặc Click để chọn
              </h3>
              <p className="text-xs lg:text-sm text-zinc-400 mt-1 max-w-md mx-auto">
                Hỗ trợ định dạng MP4, WebM, MOV lên tới <strong className="text-zinc-200 font-semibold">500MB</strong> và thời lượng video lên tới <strong className="text-zinc-200 font-semibold">2 giờ</strong>
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-2 text-xs text-zinc-400 pt-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
                <Search className="w-3.5 h-3.5 text-cyan-400" /> Tự động phát hiện tiếng gốc (AI)
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
                <FileVideo className="w-3.5 h-3.5 text-emerald-400" /> Giải mã Audio 16kHz Web Audio
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/5">
                <Clock className="w-3.5 h-3.5 text-amber-400" /> Cắt đoạn phân mảnh chống tràn RAM
              </span>
            </div>
          </div>
        ) : (
          <div className="space-y-4 text-left">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                {videoPreviewUrl && selectedFile.type.startsWith('video/') ? (
                  <video
                    src={videoPreviewUrl}
                    className="w-24 h-16 object-cover rounded-xl border border-white/10 shadow-md bg-black"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-200">
                    <FileVideo className="w-8 h-8" />
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-zinc-100 max-w-xs sm:max-w-md truncate">
                      {selectedFile.name}
                    </h4>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                      <FileCheck className="w-3 h-3" /> Sẵn Sàng
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-zinc-400 mt-1 font-mono">
                    <span>Dung lượng: {formatFileSize(selectedFile.size)}</span>
                    <span>•</span>
                    <span>Thời lượng: {formatDuration(videoDuration)}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  id="btn-quick-detect-lang"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleQuickDetectLanguage();
                  }}
                  disabled={isDetectingLang || isProcessing}
                  className="px-3.5 py-2 text-xs font-semibold text-cyan-300 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 rounded-full transition-all cursor-pointer flex items-center gap-1.5"
                >
                  <Search className={`w-3.5 h-3.5 ${isDetectingLang ? 'animate-spin' : ''}`} />
                  {isDetectingLang ? 'Đang phân tích audio...' : '⚡ Nhận diện tiếng gốc ngay'}
                </button>

                <button
                  id="btn-change-file"
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedFile(null);
                    setVideoPreviewUrl(null);
                    setVideoDuration(0);
                    setDetectedInfo(null);
                  }}
                  className="px-3 py-2 text-xs text-zinc-400 hover:text-white bg-white/5 hover:bg-white/10 rounded-full border border-white/5 transition-colors cursor-pointer"
                >
                  Đổi Video Khác
                </button>
              </div>
            </div>

            {/* Language Detection Analysis Banner */}
            {detectedInfo && (
              <div className="p-4 rounded-2xl bg-[#101015] border border-white/10 text-xs space-y-3 animate-fade">
                <div className="flex items-center justify-between text-zinc-200 font-bold border-b border-white/5 pb-2">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Kết quả phân tích âm thanh ban đầu</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 text-[10px] font-mono font-bold">
                    Khớp: {Math.round(detectedInfo.confidence * 100)}%
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                  <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                    <span className="text-zinc-500 block text-[10px]">Ngôn ngữ nói</span>
                    <strong className="text-white font-semibold">{detectedInfo.detectedLanguage} ({detectedInfo.isoCode})</strong>
                  </div>
                  {detectedInfo.dialect && (
                    <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                      <span className="text-zinc-500 block text-[10px]">Giọng điệu / Vùng miền</span>
                      <strong className="text-zinc-200">{detectedInfo.dialect}</strong>
                    </div>
                  )}
                  {detectedInfo.speechSpeed && (
                    <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                      <span className="text-zinc-500 block text-[10px]">Tốc độ nhịp nói</span>
                      <strong className="text-amber-400">{detectedInfo.speechSpeed}</strong>
                    </div>
                  )}
                  {detectedInfo.audioQuality && (
                    <div className="bg-white/5 p-2.5 rounded-xl border border-white/5">
                      <span className="text-zinc-500 block text-[10px]">Chất lượng thu âm</span>
                      <strong className="text-cyan-400">{detectedInfo.audioQuality}</strong>
                    </div>
                  )}
                </div>

                {detectedInfo.sampleTranscription && (
                  <div className="bg-black/50 p-3 rounded-xl border border-white/5 text-[11px] text-zinc-300 italic">
                    <span className="text-zinc-400 not-italic font-semibold">Mẫu câu trích đoạn: </span>
                    "{detectedInfo.sampleTranscription}"
                  </div>
                )}
              </div>
            )}

            {detectError && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{detectError}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {fileError && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-start gap-3 text-red-400 text-xs">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <span>{fileError}</span>
        </div>
      )}

      {/* Transcription & Translation Settings */}
      <div className="bg-[#09090c] border border-white/5 rounded-3xl p-6 lg:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-white/5 pb-4">
          <div>
            <h3 className="text-sm font-extrabold text-zinc-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" /> Cấu hình Nhận diện Ngôn ngữ & Dịch thuật
            </h3>
            <p className="text-xs text-zinc-500 mt-0.5">Tự động nhận diện ngữ cảnh, lọc ồn và định dạng SRT</p>
          </div>
          <span className="text-[10px] px-2.5 py-1 rounded-full bg-white/5 border border-white/10 text-zinc-400 font-mono">
            Gemini 3.6 Flash
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Source Language */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> Tiếng nói trong Video (Source Language)
            </label>
            <select
              id="select-source-language"
              value={options.sourceLanguage}
              onChange={(e) => setOptions({ ...options, sourceLanguage: e.target.value })}
              disabled={isProcessing}
              className="w-full bg-[#121216] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-zinc-100 focus:outline-none focus:border-white/30 cursor-pointer"
            >
              <option value="auto">✨ Tự động nhận diện (Auto-Detect AI)</option>
              <option value="English">English (Tiếng Anh)</option>
              <option value="Vietnamese">Vietnamese (Tiếng Việt)</option>
              <option value="Japanese">Japanese (Tiếng Nhật)</option>
              <option value="Chinese">Chinese (Tiếng Trung)</option>
              <option value="Korean">Korean (Tiếng Hàn)</option>
              <option value="French">French (Tiếng Pháp)</option>
              <option value="Spanish">Spanish (Tiếng Tây Ban Nha)</option>
              <option value="German">German (Tiếng Đức)</option>
              <option value="Russian">Russian (Tiếng Nga)</option>
              <option value="Thai">Thai (Tiếng Thái)</option>
            </select>
            <p className="text-[11px] text-zinc-500">
              Chọn trước ngôn ngữ giúp AI bóc băng siêu tốc và chính xác 99%.
            </p>
          </div>

          {/* Target Language */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Languages className="w-3.5 h-3.5 text-cyan-400" /> Ngôn ngữ phụ đề & lồng tiếng đích
            </label>
            <select
              id="select-target-language"
              value={options.targetLanguage}
              onChange={(e) => setOptions({ ...options, targetLanguage: e.target.value })}
              disabled={isProcessing}
              className="w-full bg-[#121216] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-zinc-100 focus:outline-none focus:border-white/30 cursor-pointer"
            >
              {TARGET_LANGUAGES.map((lang) => (
                <option key={lang.code} value={lang.name}>
                  {lang.nativeName} ({lang.name})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-zinc-500">
              Dịch thuật ngữ cảnh song song, không cắt cụt từ.
            </p>
          </div>

          {/* Speaker Diarization */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-purple-400" /> Phân tách người nói (Speaker Diarization)
            </label>
            <div className="flex items-center justify-between bg-[#121216] border border-white/10 rounded-xl p-3">
              <div className="text-xs">
                <span className="text-zinc-200 font-semibold block">Gán nhãn Speaker 1, Speaker 2</span>
                <span className="text-[11px] text-zinc-500">Hỗ trợ lồng tiếng nhiều nhân vật</span>
              </div>
              <button
                id="toggle-diarization"
                type="button"
                onClick={() => setOptions({ ...options, enableDiarization: !options.enableDiarization })}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors cursor-pointer ${
                  options.enableDiarization ? 'bg-white' : 'bg-zinc-800'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full transition-transform ${
                    options.enableDiarization ? 'translate-x-6 bg-black' : 'translate-x-1 bg-zinc-400'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Chunk Segment Duration */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-amber-400" /> Phân đoạn âm thanh (Chunk Length)
            </label>
            <select
              id="select-chunk-duration"
              value={options.chunkDurationMinutes}
              onChange={(e) => setOptions({ ...options, chunkDurationMinutes: Number(e.target.value) })}
              disabled={isProcessing}
              className="w-full bg-[#121216] border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-zinc-100 focus:outline-none focus:border-white/30 cursor-pointer"
            >
              <option value={2}>2 Phút / đoạn (Siêu chính xác cho hội thoại nhanh)</option>
              <option value={3}>3 Phút / đoạn (Khuyên dùng chuẩn)</option>
              <option value={5}>5 Phút / đoạn (Video bài giảng / thuyết trình)</option>
            </select>
            <p className="text-[11px] text-zinc-500">
              Chia nhỏ đoạn giúp xử lý song song và tránh rớt mạng.
            </p>
          </div>
        </div>

        {/* Start Process Button: White Pill CTA */}
        <div className="pt-2">
          <button
            id="btn-start-transcription"
            type="button"
            disabled={!selectedFile || isProcessing}
            onClick={handleSubmit}
            className={`w-full py-4 px-8 rounded-full font-extrabold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer ${
              selectedFile && !isProcessing
                ? 'bg-white text-[#050505] hover:bg-zinc-200 shadow-[0_0_20px_rgba(255,255,255,0.2)] active:scale-98'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed border border-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Bắt Đầu Bóc Băng, Dịch Thuật & Lồng Tiếng AI</span>
          </button>
        </div>
      </div>
    </div>
  );
};
