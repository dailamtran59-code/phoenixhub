import React, { useState } from 'react';
import {
  History,
  Languages,
  Film,
  Sparkles,
  Layout,
  Sliders,
  Clock,
  Download,
  ShieldCheck,
  Play,
  Settings,
  HelpCircle,
  X,
} from 'lucide-react';

interface HeaderProps {
  onOpenHistory: () => void;
  historyCount: number;
  detectedLang?: { language: string; isoCode: string; confidence: number };
  fileName?: string;
  isRailOpen: boolean;
  onToggleRail: () => void;
  isInspectorOpen: boolean;
  onToggleInspector: () => void;
  isTimelineOpen: boolean;
  onToggleTimeline: () => void;
  onOpenExport: () => void;
  hasFile: boolean;
  onReplayIntro?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenHistory,
  historyCount,
  detectedLang,
  fileName,
  isRailOpen,
  onToggleRail,
  isInspectorOpen,
  onToggleInspector,
  isTimelineOpen,
  onToggleTimeline,
  onOpenExport,
  hasFile,
  onReplayIntro,
}) => {
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  return (
    <header className="sticky top-0 z-40 bg-[#050505]/90 backdrop-blur-md border-b border-white/5 px-4 lg:px-6 py-2.5 flex items-center justify-between gap-4 select-none">
      {/* Brand Identity & File Info */}
      <div className="flex items-center gap-3">
        {/* Abstract Angular Geometric Bolt Mark */}
        <div className="flex-shrink-0 w-7 h-9 flex items-center justify-center">
          <svg viewBox="0 0 31.5 48.5" className="w-6 h-8 drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]">
            <defs>
              <linearGradient id="brandGrad" x1="8" y1="0" x2="34.1" y2="28.9" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#d4d4d8" />
                <stop offset="0.28" stopColor="#e4e4e7" />
                <stop offset="0.55" stopColor="#71717a" />
                <stop offset="0.80" stopColor="#a1a1aa" />
                <stop offset="1" stopColor="#ffffff" />
              </linearGradient>
            </defs>
            <path
              d="M21.5 0 L21.5 19.5 L31.5 19.5 L31.5 29 L10 48.5 L10 28.5 L0.5 28.5 L0.5 18.5 Z"
              fill="url(#brandGrad)"
            />
            <rect x="0.5" y="18.5" width="9" height="10" fill="#fafafa" />
            <rect x="22" y="19.5" width="9.5" height="9.5" fill="#fafafa" />
          </svg>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-extrabold text-sm text-zinc-100 tracking-tight flex items-center gap-1.5">
              AI STUDIO <span className="text-zinc-600 font-normal">|</span>
              <span className="text-zinc-400 font-medium text-xs hidden sm:inline">Dubbing & Translation Pro</span>
            </h1>
            <span className="px-2 py-0.2 text-[9px] font-bold uppercase tracking-wider rounded-full bg-white/10 text-zinc-300 border border-white/10 hidden md:flex items-center gap-1">
              <Sparkles className="w-2.5 h-2.5 text-cyan-400" /> Gemini 3.6 Flash
            </span>
          </div>

          {fileName && (
            <p className="text-[11px] text-zinc-400 font-mono truncate max-w-[200px] sm:max-w-[320px]">
              {fileName}
            </p>
          )}
        </div>
      </div>

      {/* Middle: Detected Language / Status Chip */}
      <div className="hidden lg:flex items-center gap-2">
        {detectedLang ? (
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-zinc-300">
            <Languages className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              Audio:{' '}
              <strong className="text-zinc-100 font-semibold">
                {detectedLang.language} ({detectedLang.isoCode})
              </strong>
            </span>
            <span className="text-emerald-400 font-mono text-[10px] font-bold bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
              {Math.round(detectedLang.confidence * 100)}%
            </span>
          </div>
        ) : (
          <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs text-zinc-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="text-[11px]">WebCodecs Hardware Engine • UTF-8 BOM</span>
          </div>
        )}
      </div>

      {/* Right: Layout Controls, History, and White Pill Export CTA */}
      <div className="flex items-center gap-2">
        {/* Layout Toggle Buttons */}
        <div className="hidden sm:flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/5 text-zinc-400">
          <button
            type="button"
            onClick={onToggleRail}
            className={`p-1.5 rounded-lg text-xs transition cursor-pointer ${
              isRailOpen ? 'bg-white/10 text-white' : 'hover:text-zinc-200'
            }`}
            title="Bật/Tắt Thanh Công Cụ Trái"
          >
            <Layout className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleInspector}
            className={`p-1.5 rounded-lg text-xs transition cursor-pointer ${
              isInspectorOpen ? 'bg-white/10 text-white' : 'hover:text-zinc-200'
            }`}
            title="Bật/Tắt Inspector Phải"
          >
            <Sliders className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={onToggleTimeline}
            className={`p-1.5 rounded-lg text-xs transition cursor-pointer ${
              isTimelineOpen ? 'bg-white/10 text-white' : 'hover:text-zinc-200'
            }`}
            title="Bật/Tắt Timeline Dưới"
          >
            <Clock className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* History Drawer Trigger */}
        <button
          type="button"
          onClick={onOpenHistory}
          className="relative p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white transition cursor-pointer"
          title="Lịch Sử Phiên Làm Việc"
        >
          <History className="w-4 h-4 text-zinc-300" />
          {historyCount > 0 && (
            <span className="absolute -top-1 -right-1 px-1.5 py-0.2 text-[9px] font-bold rounded-full bg-white text-black min-w-[16px] text-center shadow-md">
              {historyCount}
            </span>
          )}
        </button>

        {/* Intro Replay Button */}
        {onReplayIntro && (
          <button
            type="button"
            onClick={onReplayIntro}
            className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-400 hover:text-white transition cursor-pointer hidden md:flex items-center gap-1.5 text-xs font-semibold"
            title="Xem Lại Giới Thiệu (Cinematic Intro)"
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden xl:inline">Intro</span>
          </button>
        )}

        {/* White Pill Export CTA */}
        {hasFile && (
          <button
            type="button"
            onClick={onOpenExport}
            className="px-4 py-2 rounded-full bg-white text-[#050505] hover:bg-zinc-200 font-extrabold text-xs transition-all duration-150 flex items-center gap-1.5 shadow-[0_0_15px_rgba(255,255,255,0.15)] active:scale-95 cursor-pointer"
          >
            <Film className="w-3.5 h-3.5" />
            <span>Xuất MP4</span>
          </button>
        )}
      </div>
    </header>
  );
};
