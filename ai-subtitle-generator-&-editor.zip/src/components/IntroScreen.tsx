import React, { useState, useEffect, useRef } from 'react';
import { Sparkles, ArrowRight, Video, Languages, Mic, Film, Check } from 'lucide-react';

interface IntroScreenProps {
  onGetStarted: () => void;
  showOnStartup: boolean;
  onToggleShowOnStartup: (show: boolean) => void;
}

export const IntroScreen: React.FC<IntroScreenProps> = ({
  onGetStarted,
  showOnStartup,
  onToggleShowOnStartup,
}) => {
  const [animStage, setAnimStage] = useState<number>(0);
  const [isExiting, setIsExiting] = useState<boolean>(false);
  const [isHovered, setIsHovered] = useState<boolean>(false);

  // Parallax Refs
  const bgRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const targetRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const currentRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const rafIdRef = useRef<number | null>(null);

  useEffect(() => {
    // Check for reduced motion preference or coarse pointer (mobile/tablet)
    const isReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const isTouchDevice = window.matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;

    if (isReducedMotion) {
      setAnimStage(4);
      return;
    }

    // Sequence timeline
    // 0ms: bg fade in (stage 0)
    // 300ms: logo reveal (stage 1)
    // 500ms: title reveal (stage 2)
    // 700ms: tagline reveal (stage 3)
    // 900ms: get started CTA reveal (stage 4)
    const t1 = setTimeout(() => setAnimStage(1), 300);
    const t2 = setTimeout(() => setAnimStage(2), 550);
    const t3 = setTimeout(() => setAnimStage(3), 750);
    const t4 = setTimeout(() => setAnimStage(4), 950);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        handleTriggerStart();
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    // Mouse Parallax Setup (Desktop non-reduced motion)
    let cleanupParallax = () => {};

    if (!isTouchDevice && !isReducedMotion) {
      const handleMouseMove = (e: MouseEvent) => {
        const centerX = window.innerWidth / 2;
        const centerY = window.innerHeight / 2;
        // Normalized offset [-1, 1]
        const normX = (e.clientX - centerX) / centerX;
        const normY = (e.clientY - centerY) / centerY;
        targetRef.current = { x: normX, y: normY };
      };

      const handleMouseLeave = () => {
        targetRef.current = { x: 0, y: 0 };
      };

      const animateParallax = () => {
        // Smooth lerp easing factor (0.05 for cinematic deceleration)
        const ease = 0.05;
        const dx = targetRef.current.x - currentRef.current.x;
        const dy = targetRef.current.y - currentRef.current.y;

        currentRef.current.x += dx * ease;
        currentRef.current.y += dy * ease;

        const currX = currentRef.current.x;
        const currY = currentRef.current.y;

        // 1. Grid background shift: opposite direction, max ~16px
        if (bgRef.current) {
          const bgX = -currX * 16;
          const bgY = -currY * 16;
          bgRef.current.style.transform = `translate3d(${bgX.toFixed(2)}px, ${bgY.toFixed(2)}px, 0px)`;
        }

        // 2. Ambient glow spotlight shift: opposite direction, max ~22px
        if (glowRef.current) {
          const glowX = -currX * 22;
          const glowY = -currY * 22;
          glowRef.current.style.transform = `translate3d(calc(-50% + ${glowX.toFixed(2)}px), calc(-50% + ${glowY.toFixed(2)}px), 0px)`;
        }

        // 3. Foreground content shift: subtle alignment, max ~2.5px
        if (contentRef.current) {
          const contentX = currX * 2.5;
          const contentY = currY * 2.5;
          contentRef.current.style.transform = `translate3d(${contentX.toFixed(2)}px, ${contentY.toFixed(2)}px, 0px)`;
        }

        rafIdRef.current = requestAnimationFrame(animateParallax);
      };

      window.addEventListener('mousemove', handleMouseMove, { passive: true });
      document.addEventListener('mouseleave', handleMouseLeave);
      rafIdRef.current = requestAnimationFrame(animateParallax);

      cleanupParallax = () => {
        window.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseleave', handleMouseLeave);
        if (rafIdRef.current) {
          cancelAnimationFrame(rafIdRef.current);
        }
      };
    }

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      window.removeEventListener('keydown', handleKeyDown);
      cleanupParallax();
    };
  }, []);

  const handleTriggerStart = () => {
    if (isExiting) return;
    setIsExiting(true);
    // Smooth transition duration: 650ms
    setTimeout(() => {
      onGetStarted();
    }, 650);
  };

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050505] select-none overflow-hidden transition-all duration-700 ease-out ${
        isExiting ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'
      }`}
      style={{
        background: 'radial-gradient(ellipse 70% 60% at 50% 45%, #0e0e14 0%, #050507 70%, #020203 100%)',
      }}
    >
      {/* Subtle Cinematic Grid & Vignette Texture with Parallax */}
      <div 
        ref={bgRef}
        className="absolute -inset-10 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
          backgroundSize: '48px 48px',
          willChange: 'transform',
        }}
      />

      {/* Ambient Spotlight / Horizon Glow with Parallax */}
      <div 
        ref={glowRef}
        className="absolute top-1/2 left-1/2 w-[600px] h-[400px] bg-white/[0.025] blur-[120px] rounded-full pointer-events-none" 
        style={{
          transform: 'translate3d(-50%, -50%, 0px)',
          willChange: 'transform',
        }}
      />

      {/* Main Center Content Box */}
      <div 
        ref={contentRef}
        className="relative z-10 flex flex-col items-center text-center px-6 max-w-2xl mx-auto"
        style={{ willChange: 'transform' }}
      >
        {/* 1. Cinematic Logo Mark (300ms reveal) */}
        <div
          className={`transition-all duration-700 ease-out ${
            animStage >= 1
              ? 'opacity-100 scale-100 translate-y-0'
              : 'opacity-0 scale-90 translate-y-3'
          }`}
        >
          <div className="relative w-20 h-20 sm:w-24 sm:h-24 mb-6 flex items-center justify-center">
            {/* Ambient Back Glow */}
            <div className="absolute inset-0 bg-white/10 blur-2xl rounded-full transform scale-110" />
            
            {/* Geometric Outer Shield */}
            <div className="relative w-full h-full rounded-3xl bg-[#0d0d12] border border-white/15 p-4 flex items-center justify-center shadow-[0_0_40px_rgba(0,0,0,0.8)] backdrop-blur-xl">
              <svg
                viewBox="0 0 31.5 48.5"
                className="w-10 h-14 sm:w-12 sm:h-16 drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]"
              >
                <defs>
                  <linearGradient id="introBrandGrad" x1="8" y1="0" x2="34.1" y2="28.9" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#ffffff" />
                    <stop offset="35%" stopColor="#e4e4e7" />
                    <stop offset="70%" stopColor="#71717a" />
                    <stop offset="100%" stopColor="#27272a" />
                  </linearGradient>
                </defs>
                <path
                  d="M21.5 0 L21.5 19.5 L31.5 19.5 L31.5 29 L10 48.5 L10 28.5 L0.5 28.5 L0.5 18.5 Z"
                  fill="url(#introBrandGrad)"
                  className="transition-transform duration-500"
                />
                <rect x="0.5" y="18.5" width="9" height="10" fill="#ffffff" />
                <rect x="22" y="19.5" width="9.5" height="9.5" fill="#ffffff" />
              </svg>
            </div>
          </div>
        </div>

        {/* 2. App Name & Title (500ms reveal) */}
        <div
          className={`space-y-3 transition-all duration-700 ease-out ${
            animStage >= 2
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4'
          }`}
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-zinc-300 text-xs font-mono tracking-widest uppercase">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            AI DUBBING & TRANSLATION STUDIO
          </div>

          <h1 className="text-3xl sm:text-5xl font-black tracking-tight text-white font-sans">
            SUBGEN <span className="text-transparent bg-clip-text bg-gradient-to-r from-zinc-200 via-zinc-400 to-zinc-600">STUDIO</span>
          </h1>
        </div>

        {/* 3. Tagline & Capabilities (700ms reveal) */}
        <div
          className={`mt-4 space-y-4 transition-all duration-700 ease-out ${
            animStage >= 3
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-4'
          }`}
        >
          <p className="text-base sm:text-lg text-zinc-300 font-medium tracking-wide">
            &ldquo;Translate. Dub. Create.&rdquo;
          </p>

          <p className="text-xs sm:text-sm text-zinc-500 max-w-lg mx-auto font-normal leading-relaxed">
            Hệ thống lồng tiếng AI đa ngôn ngữ chuyên nghiệp. Nhận diện giọng nói, dịch thuật ngữ cảnh tự nhiên và xuất Video MP4 chuẩn nhịp khung hình.
          </p>

          {/* Quick Capability Feature Chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.03] border border-white/5 text-[11px] text-zinc-400">
              <Languages className="w-3 h-3 text-cyan-400" /> 12+ Ngôn ngữ
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.03] border border-white/5 text-[11px] text-zinc-400">
              <Mic className="w-3 h-3 text-emerald-400" /> Neural Voice Personas
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/[0.03] border border-white/5 text-[11px] text-zinc-400">
              <Film className="w-3 h-3 text-amber-400" /> WebCodecs MP4 Export
            </span>
          </div>
        </div>

        {/* 4. Primary CTA: GET STARTED Button (900ms reveal) */}
        <div
          className={`mt-8 sm:mt-10 flex flex-col items-center gap-4 transition-all duration-700 ease-out ${
            animStage >= 4
              ? 'opacity-100 scale-100 translate-y-0'
              : 'opacity-0 scale-95 translate-y-4'
          }`}
        >
          <button
            type="button"
            onClick={handleTriggerStart}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className={`group relative inline-flex items-center justify-center gap-3 px-8 sm:px-10 py-4 rounded-full bg-white text-black font-extrabold text-sm sm:text-base tracking-wide transition-all duration-200 cursor-pointer overflow-hidden shadow-[0_0_30px_rgba(255,255,255,0.25)] hover:shadow-[0_0_50px_rgba(255,255,255,0.4)] active:scale-[0.97]`}
          >
            {/* Subtle Light Sweep Effect */}
            <div
              className={`absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-700 ${
                isHovered ? 'translate-x-full' : ''
              }`}
            />

            <span>BẮT ĐẦU TRẢI NGHIỆM</span>
            <ArrowRight className="w-4 h-4 transition-transform duration-200 group-hover:translate-x-1" />
          </button>

          {/* Quick Keyboard hint & Startup Preference */}
          <div className="flex flex-col sm:flex-row items-center gap-3 text-[11px] text-zinc-500 pt-2">
            <span className="hidden sm:inline-flex items-center gap-1 font-mono text-[10px] text-zinc-600">
              Nhấn <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/10 text-zinc-400">Enter</kbd> hoặc <kbd className="px-1.5 py-0.5 rounded bg-white/10 border border-white/10 text-zinc-400">Space</kbd> để vào nhanh
            </span>

            <span className="hidden sm:inline text-zinc-700">•</span>

            <label className="inline-flex items-center gap-1.5 cursor-pointer text-zinc-400 hover:text-zinc-300 transition">
              <input
                type="checkbox"
                checked={showOnStartup}
                onChange={(e) => onToggleShowOnStartup(e.target.checked)}
                className="w-3.5 h-3.5 rounded border-white/20 bg-zinc-900 text-white accent-white cursor-pointer"
              />
              <span>Hiển thị màn hình này khi khởi động</span>
            </label>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="absolute bottom-4 sm:bottom-6 text-center text-[11px] text-zinc-600 font-mono">
        SUBGEN STUDIO PRO • POWERED BY GEMINI AUDIO & WEBCODECS
      </div>
    </div>
  );
};

