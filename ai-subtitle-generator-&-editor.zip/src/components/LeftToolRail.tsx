import React from 'react';
import {
  UploadCloud,
  FileAudio,
  Languages,
  Mic2,
  Subtitles,
  Palette,
  Film,
  ChevronLeft,
  ChevronRight,
  Sparkles,
} from 'lucide-react';
import { ActiveStudioTool } from '../types';

interface LeftToolRailProps {
  activeTool: ActiveStudioTool;
  onSelectTool: (tool: ActiveStudioTool) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  hasFile: boolean;
  hasSubtitles: boolean;
  hasDubbing: boolean;
  isProcessing: boolean;
  onReplayIntro?: () => void;
}

interface ToolDef {
  id: ActiveStudioTool;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  accentClass: string;
}

export const LeftToolRail: React.FC<LeftToolRailProps> = ({
  activeTool,
  onSelectTool,
  isCollapsed,
  onToggleCollapse,
  hasFile,
  hasSubtitles,
  hasDubbing,
  isProcessing,
  onReplayIntro,
}) => {
  const tools: ToolDef[] = [
    {
      id: 'import',
      label: 'Import',
      sublabel: 'Tải Video / Audio',
      icon: UploadCloud,
      badge: hasFile ? 'Ready' : undefined,
      accentClass: 'text-cyan-400',
    },
    {
      id: 'ocr',
      label: 'Speech OCR',
      sublabel: 'Bóc băng & Diarization',
      icon: FileAudio,
      badge: isProcessing ? 'AI' : undefined,
      accentClass: 'text-blue-400',
    },
    {
      id: 'translate',
      label: 'Translate',
      sublabel: 'Dịch thuật ngữ cảnh',
      icon: Languages,
      accentClass: 'text-indigo-400',
    },
    {
      id: 'voice',
      label: 'Voice Dub',
      sublabel: 'Lồng tiếng AI TTS',
      icon: Mic2,
      badge: hasDubbing ? 'Dub' : undefined,
      accentClass: 'text-purple-400',
    },
    {
      id: 'subtitle',
      label: 'Subtitles',
      sublabel: 'Biên tập dòng SRT',
      icon: Subtitles,
      badge: hasSubtitles ? 'SRT' : undefined,
      accentClass: 'text-emerald-400',
    },
    {
      id: 'style',
      label: 'Visual Style',
      sublabel: 'Font, Stroke, Mask',
      icon: Palette,
      accentClass: 'text-amber-400',
    },
    {
      id: 'export',
      label: 'Export MP4',
      sublabel: 'WebCodecs GPU',
      icon: Film,
      badge: 'GPU',
      accentClass: 'text-rose-400',
    },
  ];

  return (
    <aside
      className={`relative z-20 flex flex-col bg-[#08080a] border-r border-white/5 transition-all duration-300 select-none ${
        isCollapsed ? 'w-16' : 'w-56'
      }`}
    >
      {/* Studio Tools Header */}
      <div className="flex items-center justify-between px-3 py-3 border-b border-white/5">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold tracking-widest uppercase text-zinc-400">
              Studio Tools
            </span>
          </div>
        )}
        <button
          type="button"
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-white/5 transition ml-auto"
          title={isCollapsed ? 'Mở rộng thanh công cụ' : 'Thu gọn thanh công cụ'}
        >
          {isCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <ChevronLeft className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* Tools List */}
      <nav className="flex-1 py-2 px-2 space-y-1 overflow-y-auto custom-scrollbar">
        {tools.map((tool) => {
          const Icon = tool.icon;
          const isActive = activeTool === tool.id;

          return (
            <button
              key={tool.id}
              type="button"
              onClick={() => onSelectTool(tool.id)}
              className={`w-full group relative flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-all duration-150 cursor-pointer ${
                isActive
                  ? 'bg-white/10 text-white shadow-lg border border-white/15'
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5 border border-transparent'
              }`}
            >
              {/* Active Indicator Strip */}
              {isActive && (
                <div className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
              )}

              <div
                className={`p-1.5 rounded-lg transition-transform group-hover:scale-105 ${
                  isActive ? 'bg-white/15 ' + tool.accentClass : 'text-zinc-400 group-hover:text-zinc-200'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>

              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-semibold truncate ${isActive ? 'text-white' : 'text-zinc-300'}`}>
                      {tool.label}
                    </span>
                    {tool.badge && (
                      <span className="px-1.5 py-0.2 text-[9px] font-bold rounded-full bg-white/10 text-zinc-300 border border-white/10">
                        {tool.badge}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] text-zinc-500 block truncate">
                    {tool.sublabel}
                  </span>
                </div>
              )}

              {/* Collapsed Tooltip */}
              {isCollapsed && (
                <div className="hidden group-hover:block absolute left-full ml-2 px-2.5 py-1 bg-zinc-900 text-white text-xs font-semibold rounded-lg shadow-xl border border-white/10 whitespace-nowrap z-50 pointer-events-none">
                  {tool.label}
                </div>
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom Status / Engine Info */}
      {!isCollapsed ? (
        <div className="p-3 border-t border-white/5 text-[11px] text-zinc-500 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-zinc-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-cyan-400" /> Gemini Flash
            </span>
            <span className="text-[10px] font-mono text-emerald-400">Online</span>
          </div>

          {onReplayIntro && (
            <button
              type="button"
              onClick={onReplayIntro}
              className="w-full py-1.5 px-2 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white text-[11px] font-semibold transition flex items-center justify-center gap-1.5 border border-white/5 cursor-pointer"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" /> Xem Intro Studio
            </button>
          )}

          <p className="text-[10px] text-zinc-600 truncate">
            WebCodecs • UTF-8 BOM
          </p>
        </div>
      ) : onReplayIntro ? (
        <div className="p-2 border-t border-white/5 flex justify-center">
          <button
            type="button"
            onClick={onReplayIntro}
            className="p-2 rounded-lg text-zinc-500 hover:text-zinc-200 hover:bg-white/5 transition cursor-pointer"
            title="Xem Intro Studio"
          >
            <Sparkles className="w-4 h-4 text-cyan-400" />
          </button>
        </div>
      ) : null}
    </aside>
  );
};
