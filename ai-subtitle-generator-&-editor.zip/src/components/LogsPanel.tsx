import React, { useEffect, useState } from 'react';
import { Activity, Clock, Cpu, HardDrive, Settings, Zap, Database, Video, Server, ShieldCheck } from 'lucide-react';

interface RuntimeInfo {
  runtime: string;
  isCloud: boolean;
  os: string;
  arch: string;
  ffmpegPath: string;
  ffmpegVersion: string;
  activeEncoder: string;
  hardwareAcceleration: string;
  cpuModel: string;
  cpuCores: number;
  memory: string;
}

export const LogsPanel: React.FC<{
  logs: any;
}> = ({ logs }) => {
  const [runtimeInfo, setRuntimeInfo] = useState<RuntimeInfo | null>(null);

  useEffect(() => {
    fetch('/api/runtime-info')
      .then((res) => res.json())
      .then((data) => {
        if (!data.error) setRuntimeInfo(data);
      })
      .catch(() => {});
  }, []);

  return (
    <div className="mt-6 border border-zinc-200 dark:border-zinc-800 rounded-2xl overflow-hidden bg-white dark:bg-zinc-900 shadow-xl">
      <div className="px-4 py-3 border-b border-zinc-200 dark:border-zinc-800 bg-zinc-50 dark:bg-zinc-900/50 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-500" />
          <h3 className="font-semibold text-sm">System Logs & Metrics</h3>
        </div>

        {runtimeInfo && (
          <div className="flex items-center gap-2 text-xs font-mono">
            <span
              className={`px-2.5 py-1 rounded-full border flex items-center gap-1.5 font-medium ${
                runtimeInfo.isCloud
                  ? 'bg-amber-500/10 text-amber-500 border-amber-500/20'
                  : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
              }`}
            >
              <Server className="w-3 h-3" />
              Runtime: {runtimeInfo.runtime}
            </span>
            <span className="hidden sm:inline px-2 py-1 rounded bg-zinc-800 text-zinc-300 text-[11px]">
              {runtimeInfo.os} ({runtimeInfo.arch})
            </span>
          </div>
        )}
      </div>

      <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3.5 text-xs font-mono">
        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Clock className="w-3.5 h-3.5 text-emerald-400"/> OCR Time</span>
          <span className="font-semibold text-emerald-600 dark:text-emerald-400 text-sm">{logs.ocrTime ? logs.ocrTime.toFixed(2) + 's' : '-'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Zap className="w-3.5 h-3.5 text-blue-400"/> Translate Time</span>
          <span className="font-semibold text-blue-600 dark:text-blue-400 text-sm">{logs.translateTime ? logs.translateTime.toFixed(2) + 's' : '-'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Zap className="w-3.5 h-3.5 text-purple-400"/> TTS Time</span>
          <span className="font-semibold text-purple-600 dark:text-purple-400 text-sm">{logs.ttsTime ? logs.ttsTime.toFixed(2) + 's' : '-'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Video className="w-3.5 h-3.5 text-pink-400"/> Render Time</span>
          <span className="font-semibold text-pink-600 dark:text-pink-400 text-sm">{logs.renderTime ? logs.renderTime.toFixed(2) + 's' : '-'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Settings className="w-3.5 h-3.5 text-indigo-400"/> Active Encoder</span>
          <span className="font-semibold text-indigo-400">{runtimeInfo?.activeEncoder || 'Auto / libx264'}</span>
          <span className="text-[10px] text-zinc-400">{runtimeInfo?.hardwareAcceleration || 'Software multi-thread'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Cpu className="w-3.5 h-3.5 text-amber-400"/> CPU / Threads</span>
          <span className="font-semibold text-zinc-300 truncate" title={runtimeInfo?.cpuModel}>{runtimeInfo?.cpuModel || 'CPU Auto'}</span>
          <span className="text-[10px] text-zinc-400">{runtimeInfo?.cpuCores ? `${runtimeInfo.cpuCores} Cores Available` : 'Multi-threaded'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><HardDrive className="w-3.5 h-3.5 text-cyan-400"/> FFmpeg Version</span>
          <span className="font-semibold text-zinc-300 truncate" title={runtimeInfo?.ffmpegVersion}>{runtimeInfo?.ffmpegVersion || 'FFmpeg 4.4+'}</span>
          <span className="text-[10px] text-zinc-400 truncate" title={runtimeInfo?.ffmpegPath}>{runtimeInfo?.ffmpegPath || 'PATH'}</span>
        </div>

        <div className="flex flex-col gap-1 p-3 rounded-xl bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800">
          <span className="text-zinc-500 flex items-center gap-1"><Database className="w-3.5 h-3.5 text-emerald-400"/> Output Size</span>
          <span className="font-semibold text-emerald-600 dark:text-emerald-400 text-sm">
            {logs.outputSize ? (logs.outputSize / (1024 * 1024)).toFixed(2) + ' MB' : '-'}
          </span>
          <span className="text-[10px] text-zinc-400">{runtimeInfo?.memory || 'RAM Normal'}</span>
        </div>
      </div>
    </div>
  );
};
