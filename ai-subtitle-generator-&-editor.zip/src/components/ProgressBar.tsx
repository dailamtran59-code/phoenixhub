import React from 'react';
import { Loader2, CheckCircle2, AlertTriangle, RotateCcw, Clock, VolumeX } from 'lucide-react';
import { ProcessingChunk } from '../types';
import { secondsToSrtTime } from '../utils/srt';

interface ProgressBarProps {
  overallProgress: number;
  currentStage: string;
  chunks: ProcessingChunk[];
  onRetryChunk: (chunkIndex: number) => void;
  noSpeechDetected?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({
  overallProgress,
  currentStage,
  chunks,
  onRetryChunk,
  noSpeechDetected,
}) => {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6 bg-[#08080a] border border-white/5 rounded-3xl p-6 lg:p-8 shadow-2xl animate-rise select-none">
      {/* Overall Progress Header */}
      <div className="space-y-3">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-2">
            <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />
            <span className="font-bold text-zinc-100">{currentStage}</span>
          </div>
          <span className="font-mono font-extrabold text-white text-base">{Math.round(overallProgress)}%</span>
        </div>

        {/* Outer Progress Bar */}
        <div className="w-full h-2.5 bg-[#050505] rounded-full overflow-hidden p-0.5 border border-white/5">
          <div
            className="h-full bg-white rounded-full transition-all duration-300 shadow-[0_0_10px_rgba(255,255,255,0.4)]"
            style={{ width: `${Math.min(100, Math.max(0, overallProgress))}%` }}
          />
        </div>
      </div>

      {noSpeechDetected && (
        <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-start gap-3">
          <VolumeX className="w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <strong className="block font-bold">Không phát hiện giọng nói rõ ràng</strong>
            <p className="mt-0.5 text-zinc-400 leading-relaxed">
              Gemini đã phân tích đoạn này nhưng không nhận thấy giọng nói của người hoặc có quá nhiều tiếng ồn.
            </p>
          </div>
        </div>
      )}

      {/* Chunk Breakdown Matrix */}
      {chunks.length > 0 && (
        <div className="space-y-3 border-t border-white/5 pt-5">
          <h4 className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-cyan-400" /> Hàng Đợi Xử Lý Phân Đoạn ({chunks.length} Chunks)
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {chunks.map((chunk) => {
              const startFormatted = secondsToSrtTime(chunk.startTimeSeconds).split(',')[0];
              const endFormatted = secondsToSrtTime(chunk.endTimeSeconds).split(',')[0];

              return (
                <div
                  key={chunk.id}
                  className={`p-3.5 rounded-2xl border transition-all text-xs space-y-2 ${
                    chunk.status === 'completed'
                      ? 'bg-[#0b0b0e] border-emerald-500/30'
                      : chunk.status === 'processing'
                      ? 'bg-[#101015] border-white/30 shadow-md shadow-white/5'
                      : chunk.status === 'error'
                      ? 'bg-red-950/20 border-red-500/40'
                      : 'bg-[#050505] border-white/5 text-zinc-500'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-zinc-200 font-mono text-[11px]">
                      Đoạn {chunk.chunkIndex + 1}: {startFormatted} → {endFormatted}
                    </span>

                    {/* Status Badge */}
                    {chunk.status === 'completed' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <CheckCircle2 className="w-3 h-3" /> Xong ({chunk.subtitles.length} câu)
                      </span>
                    )}

                    {chunk.status === 'processing' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-semibold bg-white/10 text-zinc-200 border border-white/20">
                        <Loader2 className="w-3 h-3 animate-spin" /> Đang bóc băng
                      </span>
                    )}

                    {chunk.status === 'error' && (
                      <button
                        id={`btn-retry-chunk-${chunk.chunkIndex}`}
                        type="button"
                        onClick={() => onRetryChunk(chunk.chunkIndex)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-red-500/20 text-red-300 hover:bg-red-500/30 border border-red-500/30 text-[10px] font-semibold transition cursor-pointer"
                      >
                        <RotateCcw className="w-3 h-3" /> Thử lại
                      </button>
                    )}

                    {chunk.status === 'pending' && (
                      <span className="text-[10px] text-zinc-600 font-mono">Chờ lượt...</span>
                    )}
                  </div>

                  {chunk.status === 'processing' && (
                    <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                      <div className="h-full bg-white animate-pulse" style={{ width: '60%' }} />
                    </div>
                  )}

                  {chunk.errorMessage && (
                    <p className="text-[10px] text-red-400 truncate">{chunk.errorMessage}</p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
