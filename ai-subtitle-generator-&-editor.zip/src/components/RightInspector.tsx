import React from 'react';
import {
  ActiveStudioTool,
  SubtitleStyleConfig,
  SubtitleFontFamily,
  SubtitleGlowEffect,
  SubtitleBgStyle,
  SubtitlePosition,
  TranscribeOptions,
  TARGET_LANGUAGES,
  VOICE_PERSONAS,
  VoicePersonaId,
  SubtitleCue,
  DEFAULT_SUBTITLE_STYLE,
} from '../types';
import {
  Sliders,
  Palette,
  Mic2,
  Languages,
  FileAudio,
  Film,
  Sparkles,
  Download,
  Clock,
  Volume2,
  RefreshCw,
  Zap,
  Cpu,
  Type,
  Layers,
  Move,
  Eye,
  ShieldCheck,
  CheckCircle2,
  Play,
  RotateCcw,
} from 'lucide-react';

interface RightInspectorProps {
  activeTool?: ActiveStudioTool;
  subtitleStyle?: SubtitleStyleConfig;
  onChangeSubtitleStyle?: (style: SubtitleStyleConfig) => void;
  transcribeOptions?: TranscribeOptions;
  onChangeTranscribeOptions?: (options: TranscribeOptions) => void;
  selectedPersonaId?: VoicePersonaId;
  onSelectPersonaId?: (id: VoicePersonaId) => void;
  speechRate?: number;
  onChangeSpeechRate?: (rate: number) => void;
  originalDucking?: number;
  onChangeOriginalDucking?: (ducking: number) => void;
  detectedLanguage?: { language: string; isoCode: string; confidence: number } | null;
  cues?: SubtitleCue[];
  onChangeCues?: (cues: SubtitleCue[]) => void;
  onTriggerDubbing?: () => void;
  isGeneratingDubbing?: boolean;
  dubbingProgress?: number;
  dubbedAudioUrl?: string | null;
  onExportMp4?: () => void;
  isExportingMp4?: boolean;
  fileName?: string;
  videoDuration?: number;
  videoUrl?: string | null;
  onSelectVideoFile?: (file: File) => void;
  performanceMode?: 'prefer-hardware' | 'prefer-software';
  onChangePerformanceMode?: (mode: 'prefer-hardware' | 'prefer-software') => void;
  subtitlesCount?: number;
  targetLanguage?: string;
  onChangeTargetLanguage?: (lang: string) => void;
  onSelectTool?: (tool: ActiveStudioTool) => void;
  onOpenExport?: () => void;
}

export const RightInspector: React.FC<RightInspectorProps> = ({
  activeTool = 'style',
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
  onChangeSubtitleStyle = (_style: SubtitleStyleConfig) => {},
  transcribeOptions = {
    sourceLanguage: 'auto',
    targetLanguage: 'Vietnamese',
    enableDiarization: true,
    chunkDurationMinutes: 3,
    maxCharsPerLine: 42,
  },
  onChangeTranscribeOptions = (_options: TranscribeOptions) => {},
  selectedPersonaId = 'female_lively',
  onSelectPersonaId = (_id: VoicePersonaId) => {},
  speechRate = 1.0,
  onChangeSpeechRate = (_rate: number) => {},
  originalDucking = 0.15,
  onChangeOriginalDucking = (_ducking: number) => {},
  detectedLanguage = null,
  cues = [],
  onChangeCues = (_cues: SubtitleCue[]) => {},
  onTriggerDubbing = () => {},
  isGeneratingDubbing = false,
  dubbingProgress = 0,
  dubbedAudioUrl = null,
  onExportMp4 = () => {},
  isExportingMp4 = false,
  fileName = '',
  videoDuration = 0,
  videoUrl = null,
  onSelectVideoFile,
  performanceMode = 'prefer-hardware',
  onChangePerformanceMode = (_mode: 'prefer-hardware' | 'prefer-software') => {},
  targetLanguage,
  onChangeTargetLanguage = (_lang: string) => {},
}) => {
  const fontFamilies: { id: SubtitleFontFamily; name: string; sample: string }[] = [
    { id: 'sans', name: 'Manrope Clean', sample: 'Aa' },
    { id: 'montserrat', name: 'Montserrat Pro', sample: 'Aa' },
    { id: 'space', name: 'Space Modern', sample: 'Aa' },
    { id: 'serif', name: 'Editorial Serif', sample: 'Aa' },
    { id: 'impact', name: 'Impact Bold', sample: 'AA' },
    { id: 'mono', name: 'Mono Code', sample: 'Aa' },
  ];

  const colorPresets = [
    '#FFFFFF',
    '#FACC15',
    '#06B6D4',
    '#10B981',
    '#EC4899',
    '#F97316',
    '#A855F7',
    '#E2E8F0',
  ];

  const strokePresets: { label: string; color: string; width: number }[] = [
    { label: 'None', color: 'none', width: 0 },
    { label: 'Black 2px', color: '#000000', width: 2 },
    { label: 'Black 4px', color: '#000000', width: 4 },
    { label: 'White 2px', color: '#ffffff', width: 2 },
    { label: 'Cyan 2px', color: '#06b6d4', width: 2 },
  ];

  const bgStyles: { id: SubtitleBgStyle; label: string; desc: string }[] = [
    { id: 'black-translucent', label: 'Hộp Đen Mờ', desc: 'Nền tối trong suốt' },
    { id: 'blur', label: 'OCR Blur Mask', desc: 'Làm mờ chữ gốc của video' },
    { id: 'black-solid', label: 'Khung Đen Đậm', desc: 'Che hoàn toàn nền' },
    { id: 'none', label: 'Không Nền', desc: 'Chỉ hiển thị viền chữ' },
  ];

  return (
    <div className="h-full flex flex-col bg-[#0a0a0d] border-l border-white/5 overflow-y-auto custom-scrollbar select-none">
      {/* Inspector Header */}
      <div className="px-4 py-3.5 border-b border-white/5 flex items-center justify-between sticky top-0 bg-[#0a0a0d]/95 backdrop-blur z-10">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-zinc-400" />
          <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-200">
            {activeTool === 'style' && 'Tùy Chỉnh Kiểu Chữ Phụ Đề'}
            {activeTool === 'voice' && 'Bộ Điều Khiển Lồng Tiếng AI'}
            {activeTool === 'translate' && 'Cấu Hình Ngôn Ngữ & Dịch'}
            {activeTool === 'ocr' && 'Thông Tin Speech-To-Text'}
            {activeTool === 'subtitle' && 'Xử Lý Nhanh Mốc Thời Gian'}
            {activeTool === 'export' && 'Cấu Hình Xuất Video MP4'}
            {activeTool === 'import' && 'Chi Tiết File Phương Tiện'}
          </h3>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-zinc-400 font-mono">
          Inspector
        </span>
      </div>

      <div className="p-4 space-y-6 flex-1">
        {/* =========================================================================
            TOOL 1: VISUAL STYLE
           ========================================================================= */}
        {activeTool === 'style' && (
          <div className="space-y-5 animate-fade">
            {/* Font Family Selection */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Type className="w-3.5 h-3.5 text-amber-400" /> Phông Chữ (Typography)
              </label>
              <div className="grid grid-cols-2 gap-2">
                {fontFamilies.map((font) => (
                  <button
                    key={font.id}
                    type="button"
                    onClick={() => onChangeSubtitleStyle({ ...subtitleStyle, fontFamily: font.id })}
                    className={`p-2.5 rounded-xl text-left border transition-all cursor-pointer ${
                      subtitleStyle.fontFamily === font.id
                        ? 'bg-white/15 border-white/30 text-white shadow-md'
                        : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold">{font.name}</span>
                      <span className="text-sm font-serif opacity-70">{font.sample}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Font Size Slider */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-zinc-300">Cỡ Chữ (Font Size)</span>
                <span className="font-mono text-amber-400 font-bold">{subtitleStyle.fontSize}px</span>
              </div>
              <input
                type="range"
                min="14"
                max="52"
                step="1"
                value={subtitleStyle.fontSize}
                onChange={(e) => onChangeSubtitleStyle({ ...subtitleStyle, fontSize: Number(e.target.value) })}
                className="w-full accent-amber-400 bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Text Color */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-cyan-400" /> Màu Sắc Chữ (Text Color)
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                {colorPresets.map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => onChangeSubtitleStyle({ ...subtitleStyle, textColor: color })}
                    style={{ backgroundColor: color }}
                    className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer ${
                      subtitleStyle.textColor.toLowerCase() === color.toLowerCase()
                        ? 'border-white scale-110 shadow-lg'
                        : 'border-transparent hover:scale-105'
                    }`}
                  />
                ))}
                <input
                  type="color"
                  value={subtitleStyle.textColor}
                  onChange={(e) => onChangeSubtitleStyle({ ...subtitleStyle, textColor: e.target.value })}
                  className="w-7 h-7 rounded-full bg-transparent border-0 cursor-pointer p-0"
                  title="Màu tùy chỉnh"
                />
              </div>
            </div>

            {/* Stroke / Outline */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300">Viền Chữ (Outline / Stroke)</label>
              <div className="grid grid-cols-2 gap-2">
                {strokePresets.map((sp) => (
                  <button
                    key={sp.label}
                    type="button"
                    onClick={() => onChangeSubtitleStyle({ ...subtitleStyle, strokeColor: sp.color, strokeWidth: sp.width })}
                    className={`p-2 rounded-xl text-xs font-semibold border text-center transition cursor-pointer ${
                      subtitleStyle.strokeColor === sp.color && subtitleStyle.strokeWidth === sp.width
                        ? 'bg-white/15 border-white/30 text-white'
                        : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {sp.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Background Style & OCR Blur */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-purple-400" /> Khung Nền & Che Chữ Cũ
              </label>
              <div className="grid grid-cols-2 gap-2">
                {bgStyles.map((bg) => (
                  <button
                    key={bg.id}
                    type="button"
                    onClick={() => onChangeSubtitleStyle({ ...subtitleStyle, bgStyle: bg.id })}
                    className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                      subtitleStyle.bgStyle === bg.id
                        ? 'bg-white/15 border-white/30 text-white shadow-md'
                        : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200 hover:bg-white/10'
                    }`}
                  >
                    <div className="text-xs font-bold">{bg.label}</div>
                    <div className="text-[10px] text-zinc-500">{bg.desc}</div>
                  </button>
                ))}
              </div>

              {subtitleStyle.bgStyle === 'blur' && (
                <div className="mt-3 p-3 rounded-xl bg-purple-950/20 border border-purple-500/30 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-purple-300 font-semibold">Độ mờ vùng che OCR</span>
                    <span className="font-mono text-purple-200">{subtitleStyle.blurIntensity || 14}px</span>
                  </div>
                  <input
                    type="range"
                    min="4"
                    max="30"
                    step="1"
                    value={subtitleStyle.blurIntensity || 14}
                    onChange={(e) => onChangeSubtitleStyle({ ...subtitleStyle, blurIntensity: Number(e.target.value) })}
                    className="w-full accent-purple-400 bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
                  />
                  <p className="text-[10px] text-purple-400/80">
                    Tự động làm mờ và xóa phụ đề cũ gắn liền trên video gốc.
                  </p>
                </div>
              )}
            </div>

            {/* Position Controls */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Move className="w-3.5 h-3.5 text-emerald-400" /> Vị Trí Phụ Đề (Position)
              </label>
              <div className="flex items-center gap-2">
                {(['bottom', 'middle', 'top'] as SubtitlePosition[]).map((pos) => (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => {
                      const yVal = pos === 'bottom' ? 84 : pos === 'middle' ? 50 : 16;
                      onChangeSubtitleStyle({ ...subtitleStyle, position: pos, positionY: yVal });
                    }}
                    className={`flex-1 py-1.5 rounded-lg text-xs font-semibold uppercase border transition cursor-pointer ${
                      subtitleStyle.position === pos
                        ? 'bg-white/15 border-white/30 text-white'
                        : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {pos}
                  </button>
                ))}
              </div>

              <div className="pt-2 space-y-1">
                <div className="flex justify-between text-[11px] text-zinc-400">
                  <span>Khoảng cách từ trên (Y)</span>
                  <span className="font-mono">{subtitleStyle.positionY}%</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="95"
                  step="1"
                  value={subtitleStyle.positionY}
                  onChange={(e) => onChangeSubtitleStyle({ ...subtitleStyle, positionY: Number(e.target.value) })}
                  className="w-full accent-emerald-400 bg-white/10 h-1 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 2: VOICE DUBBING
           ========================================================================= */}
        {activeTool === 'voice' && (
          <div className="space-y-5 animate-fade">
            {/* Voice Persona Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Mic2 className="w-3.5 h-3.5 text-purple-400" /> Giọng Đọc Lồng Tiếng AI (TTS)
              </label>
              <div className="space-y-2">
                {VOICE_PERSONAS.map((persona) => {
                  const isSelected = selectedPersonaId === persona.id;
                  return (
                    <button
                      key={persona.id}
                      type="button"
                      onClick={() => onSelectPersonaId(persona.id)}
                      className={`w-full p-3 rounded-xl text-left border transition cursor-pointer ${
                        isSelected
                          ? 'bg-purple-950/40 border-purple-500/40 text-white shadow-lg'
                          : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold text-zinc-200">{persona.name}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-semibold border border-purple-500/30">
                          {persona.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 line-clamp-2">{persona.description}</p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Speech Rate */}
            <div className="space-y-2 bg-white/5 p-3 rounded-2xl border border-white/5">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-zinc-300">Tốc Độ Đọc (Speech Rate)</span>
                <span className="font-mono text-purple-400 font-bold">{speechRate.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.05"
                value={speechRate}
                onChange={(e) => onChangeSpeechRate(Number(e.target.value))}
                className="w-full accent-purple-400 bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <div className="flex items-center justify-between gap-1 pt-1">
                {[0.75, 1.0, 1.25, 1.5].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => onChangeSpeechRate(preset)}
                    className={`px-2.5 py-0.5 rounded-md text-[10px] font-mono font-semibold transition cursor-pointer ${
                      Math.abs(speechRate - preset) < 0.04
                        ? 'bg-purple-500 text-white shadow'
                        : 'bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-zinc-200'
                    }`}
                  >
                    {preset.toFixed(2)}x
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Ducking Mixer */}
            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-zinc-300 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-zinc-400" /> Nhạc Nền Video Gốc (Ducking)
                </span>
                <span className="font-mono text-zinc-400">{Math.round(originalDucking * 100)}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={originalDucking}
                onChange={(e) => onChangeOriginalDucking(Number(e.target.value))}
                className="w-full accent-zinc-300 bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Trigger Dubbing Generation Button */}
            <div className="pt-2">
              <button
                type="button"
                disabled={isGeneratingDubbing || cues.length === 0}
                onClick={onTriggerDubbing}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs shadow-xl shadow-purple-950/50 flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isGeneratingDubbing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-white" />
                    Đang tổng hợp giọng nói ({dubbingProgress}%)
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-purple-200" />
                    Tạo Lồng Tiếng AI Toàn Bộ ({cues.length} câu)
                  </>
                )}
              </button>

              {dubbedAudioUrl && !isGeneratingDubbing && (
                <div className="mt-3 p-3 rounded-xl bg-emerald-950/20 border border-emerald-500/30 flex items-center gap-2 text-xs text-emerald-400">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>Đã có luồng âm thanh lồng tiếng sẵn sàng phát thử & xuất MP4!</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 3: TRANSLATE
           ========================================================================= */}
        {activeTool === 'translate' && (
          <div className="space-y-5 animate-fade">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Languages className="w-3.5 h-3.5 text-indigo-400" /> Ngôn Ngữ Đích (Target Language)
              </label>
              <select
                value={targetLanguage || transcribeOptions?.targetLanguage || 'Vietnamese'}
                onChange={(e) => {
                  const val = e.target.value;
                  onChangeTranscribeOptions({ ...transcribeOptions, targetLanguage: val });
                  if (onChangeTargetLanguage) onChangeTargetLanguage(val);
                }}
                className="w-full px-3 py-2.5 bg-white/5 border border-white/10 rounded-xl text-xs text-zinc-200 focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {TARGET_LANGUAGES.map((lang) => (
                  <option key={lang.code} value={lang.name} className="bg-zinc-900 text-zinc-200">
                    {lang.name} ({lang.nativeName})
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="font-semibold text-zinc-300">Giới Hạn Ký Tự / Dòng</span>
                <span className="font-mono text-indigo-400 font-bold">{transcribeOptions.maxCharsPerLine} ký tự</span>
              </div>
              <input
                type="range"
                min="28"
                max="60"
                step="2"
                value={transcribeOptions.maxCharsPerLine}
                onChange={(e) => onChangeTranscribeOptions({ ...transcribeOptions, maxCharsPerLine: Number(e.target.value) })}
                className="w-full accent-indigo-400 bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
              <p className="text-[10px] text-zinc-500">
                Tự động ngắt dòng thông minh theo ngữ pháp và không cắt đôi từ.
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-white/5 border border-white/5 space-y-2 text-xs text-zinc-400">
              <div className="flex items-center gap-2 text-zinc-200 font-bold">
                <ShieldCheck className="w-4 h-4 text-emerald-400" /> Kiểm Duyệt 2 Lớp Gemini
              </div>
              <p className="text-[11px] leading-relaxed">
                Hệ thống dịch thuật áp dụng prompt chuyên sâu, giữ nguyên thuật ngữ kỹ thuật, tên riêng nhân vật và văn phong tự nhiên.
              </p>
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 4: OCR / STT
           ========================================================================= */}
        {activeTool === 'ocr' && (
          <div className="space-y-5 animate-fade">
            <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-3">
              <div className="text-xs font-bold text-zinc-200 flex items-center gap-2">
                <FileAudio className="w-4 h-4 text-blue-400" /> Kết Quả Nhận Diện Giọng Nói
              </div>
              {detectedLanguage ? (
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-zinc-400">Ngôn ngữ gốc:</span>
                    <span className="font-bold text-zinc-200">{detectedLanguage.language} ({detectedLanguage.isoCode})</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-zinc-400">Độ tin cậy:</span>
                    <span className="font-mono text-emerald-400 font-bold">{Math.round(detectedLanguage.confidence * 100)}%</span>
                  </div>
                  <div className="flex justify-between py-1">
                    <span className="text-zinc-400">Số câu trích xuất:</span>
                    <span className="font-bold text-zinc-200">{cues.length} câu</span>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-zinc-500">Chưa có thông tin nhận dạng ngôn ngữ audio.</p>
              )}
            </div>

            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300">Phân Tách Người Nói (Diarization)</label>
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between text-xs">
                <span>Tự động gán nhãn Speaker 1, 2...</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[10px] font-bold">
                  Bật
                </span>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 5: SUBTITLE QUICK TOOLS
           ========================================================================= */}
        {activeTool === 'subtitle' && (
          <div className="space-y-5 animate-fade">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-400" /> Dịch Chuyển Toàn Bộ Mốc Giờ (Offset)
              </label>
              <p className="text-[11px] text-zinc-400">
                Nếu video bị lệch tiếng hoặc phụ đề xuất hiện sớm/muộn hơn, điều chỉnh nhanh:
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const shifted = cues.map(c => ({
                      ...c,
                      startSeconds: Math.max(0, c.startSeconds - 0.5),
                      endSeconds: Math.max(0.5, c.endSeconds - 0.5),
                    }));
                    onChangeCues(shifted);
                  }}
                  className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-zinc-200 transition cursor-pointer"
                >
                  -0.5 Giây
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const shifted = cues.map(c => ({
                      ...c,
                      startSeconds: c.startSeconds + 0.5,
                      endSeconds: c.endSeconds + 0.5,
                    }));
                    onChangeCues(shifted);
                  }}
                  className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-bold text-zinc-200 transition cursor-pointer"
                >
                  +0.5 Giây
                </button>
              </div>
            </div>

            <div className="space-y-2 pt-2">
              <label className="text-xs font-semibold text-zinc-300">Tối Ưu Hóa Nhịp Điệu (Smooth Pacing)</label>
              <button
                type="button"
                onClick={() => {
                  const smoothed = cues.map((c, i) => {
                    const next = cues[i + 1];
                    if (next && next.startSeconds - c.endSeconds < 0.3 && next.startSeconds > c.endSeconds) {
                      return { ...c, endSeconds: next.startSeconds };
                    }
                    return c;
                  });
                  onChangeCues(smoothed);
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-emerald-950/30 hover:bg-emerald-900/40 border border-emerald-500/30 text-emerald-300 font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" /> Tự Động Lấp Khoảng Hở Nhỏ
              </button>
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 6: EXPORT CENTER
           ========================================================================= */}
        {activeTool === 'export' && (
          <div className="space-y-5 animate-fade">
            <div className="space-y-2">
              <label className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
                <Film className="w-3.5 h-3.5 text-rose-400" /> Chế Độ Mã Hóa MP4
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => onChangePerformanceMode('prefer-hardware')}
                  className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                    performanceMode === 'prefer-hardware'
                      ? 'bg-rose-950/40 border-rose-500/50 text-white shadow-md'
                      : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold text-xs text-rose-300">
                    <Zap className="w-3.5 h-3.5 text-amber-400" /> Tăng Tốc GPU
                  </div>
                  <div className="text-[10px] text-zinc-500">Tối đa tốc độ WebCodecs</div>
                </button>

                <button
                  type="button"
                  onClick={() => onChangePerformanceMode('prefer-software')}
                  className={`p-2.5 rounded-xl text-left border transition cursor-pointer ${
                    performanceMode === 'prefer-software'
                      ? 'bg-white/15 border-white/30 text-white'
                      : 'bg-white/5 border-white/5 text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-bold text-xs text-zinc-300">
                    <Cpu className="w-3.5 h-3.5 text-zinc-400" /> Tiết Kiệm (CPU)
                  </div>
                  <div className="text-[10px] text-zinc-500">Mã hóa tương thích cao</div>
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                disabled={isExportingMp4 || !videoUrl}
                onClick={onExportMp4}
                className="w-full py-3.5 px-4 rounded-xl bg-white hover:bg-zinc-100 text-[#050505] font-extrabold text-xs shadow-2xl flex items-center justify-center gap-2 transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isExportingMp4 ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin text-black" />
                    Đang xuất video MP4...
                  </>
                ) : (
                  <>
                    <Film className="w-4 h-4 text-black" />
                    Bắt Đầu Xuất Video MP4 Hoàn Chỉnh
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* =========================================================================
            TOOL 7: IMPORT MEDIA
           ========================================================================= */}
        {activeTool === 'import' && (
          <div className="space-y-5 animate-fade">
            <div className="p-4 rounded-xl bg-white/5 border border-white/5 space-y-3">
              <span className="text-xs font-bold text-zinc-200 block">Thông Tin Tệp Nguồn</span>
              <div className="space-y-1.5 text-xs text-zinc-400">
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span>Tên file:</span>
                  <span className="font-semibold text-zinc-200 truncate max-w-[140px]">
                    {fileName || 'Chưa chọn'}
                  </span>
                </div>
                <div className="flex justify-between py-1 border-b border-white/5">
                  <span>Thời lượng:</span>
                  <span className="font-mono text-zinc-200 font-semibold">
                    {videoDuration ? `${Math.floor(videoDuration / 60)}m ${Math.floor(videoDuration % 60)}s` : '0s'}
                  </span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Trạng thái:</span>
                  <span className="text-emerald-400 font-semibold">Đã tải vào Studio</span>
                </div>
              </div>
            </div>

            {onSelectVideoFile && (
              <label className="block w-full py-2.5 px-4 rounded-xl bg-white/10 hover:bg-white/15 border border-white/10 text-center text-xs font-bold text-zinc-200 transition cursor-pointer">
                <span>Thay Đổi Tệp Video Nguồn</span>
                <input
                  type="file"
                  accept="video/*,audio/*"
                  onChange={(e) => {
                    if (e.target.files && e.target.files[0]) {
                      onSelectVideoFile(e.target.files[0]);
                    }
                  }}
                  className="hidden"
                />
              </label>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
