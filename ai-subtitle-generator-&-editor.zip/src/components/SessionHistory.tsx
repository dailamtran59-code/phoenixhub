import React from 'react';
import { X, History, Trash2, FileVideo, Download, Play, Clock, Sparkles } from 'lucide-react';
import { SessionHistoryItem } from '../types';
import { buildSrtContent, downloadFileWithBOM } from '../utils/srt';

interface SessionHistoryProps {
  isOpen: boolean;
  onClose: () => void;
  historyItems: SessionHistoryItem[];
  onLoadHistoryItem: (item: SessionHistoryItem) => void;
  onDeleteHistoryItem: (id: string) => void;
  onClearAllHistory: () => void;
}

export const SessionHistory: React.FC<SessionHistoryProps> = ({
  isOpen,
  onClose,
  historyItems,
  onLoadHistoryItem,
  onDeleteHistoryItem,
  onClearAllHistory,
}) => {
  if (!isOpen) return null;

  const handleDownloadItemSrt = (item: SessionHistoryItem) => {
    const srtStr = buildSrtContent(item.subtitles, 'bilingual', true);
    const baseName = item.fileName.replace(/\.[^/.]+$/, '');
    downloadFileWithBOM(srtStr, `${baseName}_Bilingual.srt`, 'application/x-subrip;charset=utf-8');
  };

  const formatDate = (isoString: string) => {
    try {
      return new Date(isoString).toLocaleString();
    } catch {
      return isoString;
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex justify-end transition-opacity select-none">
      <div className="w-full max-w-md bg-[#09090c] border-l border-white/10 h-full flex flex-col shadow-2xl animate-fade">
        {/* Drawer Header */}
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            <h3 className="font-extrabold text-zinc-100 text-sm tracking-tight">Lịch Sử Phiên Làm Việc</h3>
          </div>
          <button
            id="btn-close-session-history"
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* History List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {historyItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 text-xs py-16 text-center space-y-2">
              <History className="w-12 h-12 opacity-20" />
              <p className="font-bold text-zinc-400">Chưa có phiên làm việc nào</p>
              <p className="text-[11px] text-zinc-500 max-w-xs">
                Các video và phụ đề sau khi bóc băng sẽ được lưu trữ tự động trên bộ nhớ trình duyệt của bạn.
              </p>
            </div>
          ) : (
            historyItems.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-2xl bg-[#0e0e12] border border-white/5 hover:border-white/15 transition-all text-xs space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-300 shrink-0">
                      <FileVideo className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-zinc-100 line-clamp-1 max-w-[200px]">
                        {item.fileName}
                      </h4>
                      <p className="text-[10px] text-zinc-500 font-mono">{formatDate(item.createdAt)}</p>
                    </div>
                  </div>

                  <button
                    id={`btn-delete-history-${item.id}`}
                    type="button"
                    onClick={() => onDeleteHistoryItem(item.id)}
                    className="p-1 text-zinc-500 hover:text-red-400 transition-colors cursor-pointer"
                    title="Xóa khỏi lịch sử"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2 text-[10px] text-zinc-400 bg-black/40 p-2.5 rounded-xl border border-white/5 font-mono">
                  <span>Tiếng gốc: <strong className="text-cyan-300">{item.detectedLanguage}</strong></span>
                  <span>•</span>
                  <span>Dòng phụ đề: <strong className="text-white">{item.subtitles.length}</strong></span>
                  <span>•</span>
                  <span>Đích: <strong className="text-emerald-300">{item.targetLanguage}</strong></span>
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      onLoadHistoryItem(item);
                      onClose();
                    }}
                    className="flex-1 py-2 px-3 rounded-full bg-white text-black hover:bg-zinc-200 font-extrabold text-xs flex items-center justify-center gap-1.5 shadow transition cursor-pointer"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Mở Dự Án</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDownloadItemSrt(item)}
                    className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-300 hover:text-white transition cursor-pointer"
                    title="Tải nhanh file .SRT"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer Actions */}
        {historyItems.length > 0 && (
          <div className="p-4 border-t border-white/5 flex items-center justify-between">
            <span className="text-[11px] text-zinc-500 font-mono">Tổng: {historyItems.length} dự án</span>
            <button
              type="button"
              onClick={onClearAllHistory}
              className="text-xs text-rose-400 hover:text-rose-300 font-semibold transition cursor-pointer"
            >
              Xóa Toàn Bộ Lịch Sử
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
