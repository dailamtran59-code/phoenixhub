import React, { useState } from 'react';
import {
  Search,
  Plus,
  Trash2,
  Play,
  Clock,
  User,
  Sliders,
  Check,
  RotateCcw,
  Sparkles,
  ChevronRight,
  MoveUp,
  MoveDown,
} from 'lucide-react';
import { SubtitleCue, SubtitleMode } from '../types';
import { secondsToSrtTime, srtTimeToSeconds, adjustCueTimestamps, autoSmoothSubtitlePacing } from '../utils/srt';

interface SubtitleEditorProps {
  cues: SubtitleCue[];
  onChangeCues: (updatedCues: SubtitleCue[]) => void;
  subtitleMode: SubtitleMode;
  onChangeMode: (mode: SubtitleMode) => void;
  showSpeaker: boolean;
  onToggleSpeaker: () => void;
  currentTime: number;
  onJumpToTime: (seconds: number) => void;
  targetLanguage: string;
}

export const SubtitleEditor: React.FC<SubtitleEditorProps> = ({
  cues,
  onChangeCues,
  subtitleMode,
  onChangeMode,
  showSpeaker,
  onToggleSpeaker,
  currentTime,
  onJumpToTime,
  targetLanguage,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [editingCueId, setEditingCueId] = useState<number | null>(null);

  // Filter cues
  const filteredCues = cues.filter((c) => {
    const query = searchQuery.toLowerCase();
    return (
      c.text_original.toLowerCase().includes(query) ||
      (c.text_translated && c.text_translated.toLowerCase().includes(query)) ||
      (c.speaker && c.speaker.toLowerCase().includes(query))
    );
  });

  const handleCueUpdate = (id: number, field: keyof SubtitleCue, value: string | number) => {
    const updated = cues.map((c) => {
      if (c.id === id) {
        const newCue = { ...c, [field]: value };
        if (field === 'start') {
          newCue.startSeconds = srtTimeToSeconds(String(value));
        } else if (field === 'end') {
          newCue.endSeconds = srtTimeToSeconds(String(value));
        } else if (field === 'startSeconds') {
          newCue.start = secondsToSrtTime(Number(value));
        } else if (field === 'endSeconds') {
          newCue.end = secondsToSrtTime(Number(value));
        }
        return newCue;
      }
      return c;
    });
    onChangeCues(updated);
  };

  const handleAddCue = () => {
    const lastCue = cues[cues.length - 1];
    const newStartSec = lastCue ? lastCue.endSeconds + 0.2 : 0;
    const newEndSec = newStartSec + 3.0;

    const newCue: SubtitleCue = {
      id: Date.now(),
      start: secondsToSrtTime(newStartSec),
      end: secondsToSrtTime(newEndSec),
      startSeconds: newStartSec,
      endSeconds: newEndSec,
      speaker: 'Speaker 1',
      text_original: 'New subtitle cue text...',
      text_translated: 'Văn bản phụ đề dịch mới...',
    };
    onChangeCues([...cues, newCue]);
  };

  const handleDeleteCue = (id: number) => {
    onChangeCues(cues.filter((c) => c.id !== id));
  };

  const handleNudgeCue = (id: number, target: 'start' | 'end', deltaSec: number) => {
    const updated = cues.map((c) => {
      if (c.id === id) {
        let newStart = c.startSeconds;
        let newEnd = c.endSeconds;
        if (target === 'start') {
          newStart = Math.max(0, newStart + deltaSec);
          if (newStart >= newEnd) newEnd = newStart + 0.5;
        } else {
          newEnd = Math.max(newStart + 0.5, newEnd + deltaSec);
        }
        return {
          ...c,
          startSeconds: Number(newStart.toFixed(3)),
          endSeconds: Number(newEnd.toFixed(3)),
          start: secondsToSrtTime(newStart),
          end: secondsToSrtTime(newEnd),
        };
      }
      return c;
    });
    onChangeCues(updated);
  };

  return (
    <div className="h-full flex flex-col bg-[#070709] border border-white/5 rounded-2xl overflow-hidden shadow-2xl select-none">
      {/* Editor Header Bar */}
      <div className="px-4 py-3 bg-[#0a0a0d] border-b border-white/5 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="font-extrabold text-xs uppercase tracking-wider text-zinc-200">
            Biên Tập Phụ Đề ({cues.length})
          </span>
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 border border-white/10 text-zinc-400 font-mono">
            {targetLanguage}
          </span>
        </div>

        {/* Search & Add Cue */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1 sm:w-48">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 transform -translate-y-1/2" />
            <input
              type="text"
              placeholder="Tìm kiếm phụ đề..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-zinc-200 placeholder-zinc-500 focus:outline-none focus:border-white/30"
            />
          </div>

          <button
            type="button"
            onClick={handleAddCue}
            className="px-3 py-1.5 rounded-xl bg-white text-black hover:bg-zinc-200 font-bold text-xs flex items-center gap-1 shadow-md transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Thêm Dòng</span>
          </button>
        </div>
      </div>

      {/* Subtitles Table / Card List */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-3 space-y-2">
        {filteredCues.length === 0 ? (
          <div className="py-16 text-center text-zinc-500 text-xs">
            {searchQuery ? 'Không tìm thấy dòng phụ đề nào khớp với từ khóa.' : 'Chưa có dòng phụ đề nào được tạo.'}
          </div>
        ) : (
          filteredCues.map((cue, index) => {
            const isActive = currentTime >= cue.startSeconds && currentTime <= cue.endSeconds;
            const isEditing = editingCueId === cue.id;

            return (
              <div
                key={cue.id}
                onClick={() => onJumpToTime(cue.startSeconds)}
                onDoubleClick={() => setEditingCueId(cue.id)}
                className={`group relative p-3 rounded-xl border transition-all duration-150 cursor-pointer ${
                  isActive
                    ? 'bg-white/10 border-white/30 shadow-xl shadow-white/5'
                    : 'bg-[#0d0d10] border-white/5 hover:border-white/15 hover:bg-white/5'
                }`}
              >
                {/* Active Indicator Bar */}
                {isActive && (
                  <div className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-white shadow-[0_0_8px_rgba(255,255,255,0.8)]" />
                )}

                <div className="flex items-start justify-between gap-3">
                  {/* Left Column: Number & Timestamps */}
                  <div className="flex flex-col gap-1 flex-shrink-0 w-28 text-[11px] font-mono">
                    <div className="flex items-center gap-1.5 text-zinc-400">
                      <span className="font-bold text-white">#{index + 1}</span>
                      {cue.speaker && (
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-sans font-semibold truncate max-w-[65px]">
                          {cue.speaker}
                        </span>
                      )}
                    </div>

                    <div className="text-[10px] text-zinc-400 space-y-0.5">
                      <div className="flex items-center gap-1">
                        <span className="text-zinc-600">IN:</span>
                        <input
                          type="text"
                          value={cue.start}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => handleCueUpdate(cue.id, 'start', e.target.value)}
                          className="w-16 bg-white/5 px-1 py-0.2 rounded border border-white/5 text-zinc-200 font-mono text-[10px] focus:outline-none focus:border-white/30"
                        />
                      </div>
                      <div className="flex items-center gap-1">
                        <span className="text-zinc-600">OUT:</span>
                        <input
                          type="text"
                          value={cue.end}
                          onClick={(e) => e.stopPropagation()}
                          onChange={(e) => handleCueUpdate(cue.id, 'end', e.target.value)}
                          className="w-16 bg-white/5 px-1 py-0.2 rounded border border-white/5 text-zinc-200 font-mono text-[10px] focus:outline-none focus:border-white/30"
                        />
                      </div>
                    </div>

                    {/* Quick Micro Nudge Buttons */}
                    <div className="flex items-center gap-1 pt-1 opacity-0 group-hover:opacity-100 transition">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleNudgeCue(cue.id, 'start', -0.1);
                        }}
                        className="px-1 py-0.5 rounded bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white text-[9px]"
                        title="Lùi 0.1s"
                      >
                        -0.1s
                      </button>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleNudgeCue(cue.id, 'end', 0.1);
                        }}
                        className="px-1 py-0.5 rounded bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white text-[9px]"
                        title="Tới 0.1s"
                      >
                        +0.1s
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Original & Translated Text */}
                  <div className="flex-1 space-y-1.5 min-w-0" onClick={(e) => e.stopPropagation()}>
                    {/* Original Source Text */}
                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-zinc-500">
                        Nguyên Văn Gốc
                      </span>
                      <textarea
                        rows={1}
                        value={cue.text_original}
                        onChange={(e) => handleCueUpdate(cue.id, 'text_original', e.target.value)}
                        className="w-full bg-white/5 border border-white/5 hover:border-white/10 focus:border-white/25 rounded-lg px-2.5 py-1.5 text-xs text-zinc-300 placeholder-zinc-600 focus:outline-none resize-none transition"
                        placeholder="Văn bản gốc..."
                      />
                    </div>

                    {/* Translated Text */}
                    <div className="space-y-0.5">
                      <span className="text-[9px] uppercase font-bold tracking-wider text-emerald-400">
                        Bản Dịch AI ({targetLanguage})
                      </span>
                      <textarea
                        rows={2}
                        value={cue.text_translated || ''}
                        onChange={(e) => handleCueUpdate(cue.id, 'text_translated', e.target.value)}
                        className="w-full bg-white/5 border border-emerald-500/20 hover:border-emerald-500/40 focus:border-emerald-400 rounded-lg px-2.5 py-1.5 text-xs font-medium text-white placeholder-zinc-600 focus:outline-none resize-none transition"
                        placeholder="Văn bản dịch..."
                      />
                    </div>
                  </div>

                  {/* Actions: Seek & Delete */}
                  <div className="flex flex-col items-center gap-1.5 flex-shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onJumpToTime(cue.startSeconds);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition"
                      title="Chuyển video tới mốc thời gian này"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteCue(cue.id);
                      }}
                      className="p-1.5 rounded-lg bg-white/5 hover:bg-rose-500/20 text-zinc-500 hover:text-rose-400 transition"
                      title="Xóa dòng phụ đề"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
