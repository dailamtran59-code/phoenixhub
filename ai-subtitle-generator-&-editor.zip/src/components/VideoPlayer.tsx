import React, { useRef, useEffect, useState } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Settings,
  Subtitles,
  Upload,
  Sparkles,
  Move,
  RotateCcw,
  FastForward,
  Rewind,
  Eye,
  Languages,
} from 'lucide-react';
import { SubtitleCue, SubtitleMode, SubtitleStyleConfig, DEFAULT_SUBTITLE_STYLE } from '../types';
import { computeSubtitleCssStyle, computeSubtitleBgClass, stripSpeakerPrefix } from '../utils/subtitleStyle';

interface VideoPlayerProps {
  videoUrl: string | null;
  subtitles: SubtitleCue[];
  subtitleMode: SubtitleMode;
  onChangeSubtitleMode?: (mode: SubtitleMode) => void;
  showSpeaker: boolean;
  onToggleSpeaker?: () => void;
  onTimeUpdate?: (currentTime: number) => void;
  seekTime?: number | null;
  dubbedAudioUrl?: string | null;
  subtitleStyle?: SubtitleStyleConfig;
  onChangeSubtitleStyle?: (newStyle: SubtitleStyleConfig) => void;
  onSelectVideoFile?: (file: File) => void;
  fileName?: string;
}

export const VideoPlayer: React.FC<VideoPlayerProps> = ({
  videoUrl,
  subtitles,
  subtitleMode,
  onChangeSubtitleMode,
  showSpeaker,
  onToggleSpeaker,
  onTimeUpdate,
  seekTime,
  dubbedAudioUrl,
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
  onChangeSubtitleStyle,
  onSelectVideoFile,
  fileName,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoFrameRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [useDubbedAudio, setUseDubbedAudio] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [originalAudioDucking, setOriginalAudioDucking] = useState(0.15); // 15% background when dubbing
  const [dubbedAudioVolume, setDubbedAudioVolume] = useState(1.0);
  const [isMuted, setIsMuted] = useState(false);
  const [activeCue, setActiveCue] = useState<SubtitleCue | null>(null);

  // Dynamic responsive frame width scaling
  const [containerWidth, setContainerWidth] = useState<number>(640);
  const [isDraggingSubtitle, setIsDraggingSubtitle] = useState<boolean>(false);
  const [showSettings, setShowSettings] = useState<boolean>(false);

  // Measure container width for responsive font scaling
  useEffect(() => {
    if (!videoFrameRef.current) return;
    const observer = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0) {
          setContainerWidth(entry.contentRect.width);
        }
      }
    });
    observer.observe(videoFrameRef.current);
    return () => observer.disconnect();
  }, []);

  // Sync seekTime from parent
  useEffect(() => {
    if (seekTime !== undefined && seekTime !== null && videoRef.current) {
      videoRef.current.currentTime = seekTime;
      if (!isPlaying) {
        videoRef.current.play().catch(() => {});
        setIsPlaying(true);
      }
    }
  }, [seekTime]);

  // Sync audio playback with video and handle ducking
  useEffect(() => {
    const video = videoRef.current;
    const audio = audioRef.current;
    if (!video) return;

    if (isMuted) {
      video.volume = 0;
      if (audio) audio.volume = 0;
    } else if (dubbedAudioUrl && useDubbedAudio) {
      video.volume = Math.max(0, Math.min(1, volume * originalAudioDucking));
      if (audio) {
        audio.volume = Math.max(0, Math.min(1, volume * dubbedAudioVolume));
        audio.currentTime = video.currentTime;
        if (isPlaying) {
          audio.play().catch(() => {});
        } else {
          audio.pause();
        }
      }
    } else {
      video.volume = Math.max(0, Math.min(1, volume));
      if (audio) {
        audio.pause();
      }
    }
  }, [isPlaying, dubbedAudioUrl, useDubbedAudio, volume, isMuted, originalAudioDucking, dubbedAudioVolume]);

  // Track active subtitle cue during video playback
  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const curr = videoRef.current.currentTime;
    setCurrentTime(curr);
    onTimeUpdate?.(curr);

    if (audioRef.current && dubbedAudioUrl && useDubbedAudio) {
      if (Math.abs(audioRef.current.currentTime - curr) > 0.15) {
        audioRef.current.currentTime = curr;
      }
    }

    let cue = subtitles.find(
      (c) => curr >= c.startSeconds && curr <= c.endSeconds
    );
    if (!cue && subtitles.length > 0) {
      cue = subtitles.find((c, idx) => {
        const nextCue = subtitles[idx + 1];
        const maxExtend = nextCue ? Math.min(c.endSeconds + 0.5, nextCue.startSeconds) : c.endSeconds + 0.5;
        return curr >= c.startSeconds && curr <= maxExtend;
      }) || null;
    }
    setActiveCue(cue || null);
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    if (videoRef.current) {
      videoRef.current.volume = val;
      setIsMuted(val === 0);
    }
  };

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      containerRef.current.requestFullscreen();
    }
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return '00:00';
    const m = Math.floor(seconds / 60);
    const s = Math.floor(seconds % 60);
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && onSelectVideoFile) {
      onSelectVideoFile(file);
    }
  };

  // Drag subtitle handler
  const handleContainerMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDraggingSubtitle || !videoFrameRef.current || !onChangeSubtitleStyle) return;
    const rect = videoFrameRef.current.getBoundingClientRect();
    const relY = Math.max(5, Math.min(92, ((e.clientY - rect.top) / rect.height) * 100));
    const relX = Math.max(10, Math.min(90, ((e.clientX - rect.left) / rect.width) * 100));

    onChangeSubtitleStyle({
      ...subtitleStyle,
      positionY: Math.round(relY),
      positionX: Math.round(relX),
    });
  };

  // Responsive scale ratio relative to base 640px width
  const scaleRatio = Math.max(0.45, Math.min(2.5, containerWidth / 640));
  const computedCss = computeSubtitleCssStyle(subtitleStyle, scaleRatio);
  const computedBgClass = computeSubtitleBgClass(subtitleStyle.bgStyle);

  const cleanOriginal = stripSpeakerPrefix(activeCue?.text_original);
  const cleanTranslated = stripSpeakerPrefix(activeCue?.text_translated);

  const posY = subtitleStyle.positionY !== undefined ? subtitleStyle.positionY : (
    subtitleStyle.position === 'top' ? 12 : subtitleStyle.position === 'middle' ? 50 : 82
  );
  const posX = subtitleStyle.positionX !== undefined ? subtitleStyle.positionX : 50;

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full rounded-2xl bg-[#050505] border border-white/10 overflow-hidden shadow-2xl flex flex-col select-none"
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="video/*,audio/*"
        onChange={handleFileChange}
        className="hidden"
      />

      {/* Top Preview Status Bar */}
      <div className="px-4 py-2 bg-[#09090b] border-b border-white/5 flex items-center justify-between text-xs text-zinc-400">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-zinc-200 text-[11px] uppercase tracking-wider">
            Live Renderer Stage
          </span>
          {fileName && (
            <span className="text-[10px] text-zinc-500 font-mono hidden sm:inline truncate max-w-[200px]">
              • {fileName}
            </span>
          )}
        </div>

        {/* Subtitle Mode Pill Selector */}
        {onChangeSubtitleMode && (
          <div className="flex items-center gap-1 bg-white/5 p-0.5 rounded-lg border border-white/5 text-[10px]">
            {(['bilingual', 'translated', 'original'] as SubtitleMode[]).map((mode) => (
              <button
                key={mode}
                type="button"
                onClick={() => onChangeSubtitleMode(mode)}
                className={`px-2 py-0.5 rounded-md font-semibold capitalize transition cursor-pointer ${
                  subtitleMode === mode
                    ? 'bg-white text-black font-bold shadow-sm'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {mode === 'bilingual' ? 'Song Ngữ' : mode === 'translated' ? 'Bản Dịch' : 'Gốc'}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Video Canvas Stage */}
      <div
        ref={videoFrameRef}
        onMouseMove={handleContainerMouseMove}
        onMouseUp={() => setIsDraggingSubtitle(false)}
        className="relative flex-1 min-h-[320px] bg-[#000000] flex items-center justify-center overflow-hidden"
      >
        {dubbedAudioUrl && <audio ref={audioRef} src={dubbedAudioUrl} />}
        {videoUrl ? (
          <video
            ref={videoRef}
            src={videoUrl}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={() => {
              if (videoRef.current) setDuration(videoRef.current.duration);
            }}
            onClick={togglePlay}
            className="w-full h-full object-contain cursor-pointer"
          />
        ) : (
          <div className="p-8 text-center flex flex-col items-center justify-center gap-3">
            <div className="w-14 h-14 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-300">
              <Subtitles className="w-7 h-7 text-zinc-300" />
            </div>
            <div>
              <p className="text-sm font-bold text-zinc-200">
                {fileName ? `Dự Án: "${fileName}"` : 'Sân Khấu Preview Video'}
              </p>
              <p className="text-xs text-zinc-400 mt-1 max-w-sm leading-relaxed">
                Tải tệp video hoặc chọn phiên làm việc trước đó để bắt đầu xem trước lồng tiếng & chỉnh sửa phụ đề thời gian thực.
              </p>
            </div>
            {onSelectVideoFile && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="mt-2 px-5 py-2.5 bg-white text-black hover:bg-zinc-200 rounded-full text-xs font-bold flex items-center gap-2 shadow-xl transition cursor-pointer"
              >
                <Upload className="w-4 h-4" />
                Gắn Tệp Video Nguồn
              </button>
            )}
          </div>
        )}

        {/* Live Movable & Responsive Subtitle Overlay */}
        {activeCue && (
          <div
            style={{
              top: `${posY}%`,
              left: `${posX}%`,
              transform: 'translate(-50%, -50%)',
            }}
            onMouseDown={() => setIsDraggingSubtitle(true)}
            className="absolute z-20 cursor-grab active:cursor-grabbing max-w-[92%] transition-all"
            title="Nhấn giữ & Kéo để di chuyển vị trí phụ đề trên khung hình Video"
          >
            <div
              style={computedCss}
              className={`text-center font-medium leading-snug rounded-xl px-4 py-2 flex flex-col items-center justify-center relative group/sub shadow-2xl ${computedBgClass}`}
            >
              <div className="absolute -top-2 right-2 opacity-0 group-hover/sub:opacity-100 transition text-[9px] bg-white text-black font-bold px-1.5 py-0.5 rounded flex items-center gap-1 shadow">
                <Move className="w-2.5 h-2.5" /> Kéo thả
              </div>

              {showSpeaker && activeCue.speaker && (
                <span className="block text-[0.7em] uppercase font-bold text-cyan-300 tracking-wider mb-0.5">
                  [{activeCue.speaker}]
                </span>
              )}

              {subtitleMode === 'original' && <div>{cleanOriginal}</div>}

              {subtitleMode === 'translated' && (
                <div>{cleanTranslated || cleanOriginal}</div>
              )}

              {subtitleMode === 'bilingual' && (
                <div className="space-y-1">
                  <div>{cleanOriginal}</div>
                  {cleanTranslated && (
                    <div className="font-semibold text-[0.9em] opacity-95">
                      {cleanTranslated}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Video Transport & Control Bar */}
      <div className="bg-[#09090b] border-t border-white/5 p-3 space-y-2">
        {/* Seekbar */}
        <div className="relative flex items-center">
          <input
            id="video-seek-slider"
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            className="w-full h-1.5 bg-zinc-800 accent-white rounded-lg cursor-pointer"
          />
        </div>

        <div className="flex items-center justify-between text-xs text-zinc-300">
          {/* Left Playback Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              id="btn-toggle-play"
              type="button"
              onClick={togglePlay}
              className="p-2 rounded-xl bg-white text-black hover:bg-zinc-200 transition shadow cursor-pointer font-bold"
            >
              {isPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
            </button>

            <button
              type="button"
              onClick={() => {
                if (videoRef.current) {
                  videoRef.current.currentTime = Math.max(0, videoRef.current.currentTime - 5);
                }
              }}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition cursor-pointer"
              title="Lùi 5s"
            >
              <Rewind className="w-3.5 h-3.5" />
            </button>

            <button
              type="button"
              onClick={() => {
                if (videoRef.current) {
                  videoRef.current.currentTime = Math.min(duration, videoRef.current.currentTime + 5);
                }
              }}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition cursor-pointer"
              title="Tua 5s"
            >
              <FastForward className="w-3.5 h-3.5" />
            </button>

            <div className="flex items-center gap-1.5 pl-1">
              <button
                id="btn-toggle-mute"
                type="button"
                onClick={toggleMute}
                className="text-zinc-400 hover:text-white transition cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                id="video-volume-slider"
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={isMuted ? 0 : volume}
                onChange={handleVolumeChange}
                className="w-16 h-1 bg-zinc-800 accent-white cursor-pointer hidden sm:block"
              />
            </div>

            <span className="text-zinc-400 text-[11px] font-mono pl-1">
              {formatTime(currentTime)} / {formatTime(duration)}
            </span>
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2">
            {dubbedAudioUrl && (
              <button
                id="btn-toggle-dubbed-audio"
                type="button"
                onClick={() => setUseDubbedAudio(!useDubbedAudio)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold transition flex items-center gap-1.5 border cursor-pointer ${
                  useDubbedAudio
                    ? 'bg-purple-950/50 text-purple-300 border-purple-500/40 shadow-sm'
                    : 'bg-white/5 text-zinc-400 border-white/5 hover:text-white'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5 text-purple-400" />
                {useDubbedAudio ? 'Lồng tiếng: BẬT' : 'Lồng tiếng: TẮT'}
              </button>
            )}

            {onToggleSpeaker && (
              <button
                type="button"
                onClick={onToggleSpeaker}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition border cursor-pointer ${
                  showSpeaker
                    ? 'bg-white/15 text-white border-white/20'
                    : 'bg-white/5 text-zinc-400 border-white/5 hover:text-zinc-200'
                }`}
                title="Hiển thị tag tên người nói"
              >
                Tag Speaker
              </button>
            )}

            <button
              id="btn-subtitle-settings"
              type="button"
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl transition cursor-pointer ${
                showSettings ? 'bg-white/20 text-white' : 'bg-white/5 text-zinc-400 hover:text-white'
              }`}
              title="Cài đặt nhanh âm lượng & ducking"
            >
              <Settings className="w-4 h-4" />
            </button>

            <button
              id="btn-toggle-fullscreen"
              type="button"
              onClick={toggleFullscreen}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition cursor-pointer"
              title="Toàn màn hình"
            >
              <Maximize className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Quick Subtitle & Audio Mixer Flyout */}
        {showSettings && (
          <div className="mt-2 p-3 rounded-xl bg-black/60 border border-white/10 text-xs text-zinc-300 space-y-3 animate-fade">
            <div className="flex items-center justify-between font-semibold text-zinc-200">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" /> Bộ Trộn Âm Lượng Video & Dubbing
              </span>
              <span className="text-[10px] text-zinc-500 font-mono">
                Font: {subtitleStyle.fontSize}px • {subtitleStyle.fontFamily}
              </span>
            </div>

            {dubbedAudioUrl && (
              <div className="p-3 rounded-xl bg-white/5 border border-white/5 space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-zinc-300">Nhạc Nền / Tiếng Gốc (Audio Ducking):</span>
                    <span className="font-mono text-zinc-200 font-bold">{Math.round(originalAudioDucking * 100)}%</span>
                  </div>
                  <input
                    id="slider-original-audio-ducking"
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={originalAudioDucking}
                    onChange={(e) => setOriginalAudioDucking(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-zinc-800 accent-cyan-400 rounded cursor-pointer"
                  />
                  <div className="flex items-center justify-between text-[10px] text-zinc-500">
                    <span>0% (Tắt hẳn tiếng gốc)</span>
                    <span>15% (Làm mờ nền khuyên dùng)</span>
                    <span>100% (Giữ nguyên)</span>
                  </div>
                </div>

                <div className="space-y-1 pt-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-semibold text-purple-300">Âm Lượng Giọng Đọc Lồng Tiếng:</span>
                    <span className="font-mono text-purple-200 font-bold">{Math.round(dubbedAudioVolume * 100)}%</span>
                  </div>
                  <input
                    id="slider-dubbed-audio-volume"
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={dubbedAudioVolume}
                    onChange={(e) => setDubbedAudioVolume(parseFloat(e.target.value))}
                    className="w-full h-1.5 bg-zinc-800 accent-purple-400 rounded cursor-pointer"
                  />
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
