declare module 'mp4box' {
  export interface MP4MediaTrack {
    id: number;
    created: Date;
    modified: Date;
    volume: number;
    track_width: number;
    track_height: number;
    timescale: number;
    duration: number;
    bitrate: number;
    codec: string;
    language: string;
    nb_samples: number;
    video?: {
      width: number;
      height: number;
    };
    audio?: {
      sample_rate: number;
      channel_count: number;
      sample_size: number;
    };
    samples_duration?: number;
  }

  export interface MP4Info {
    duration: number;
    timescale: number;
    isFragmented: boolean;
    isProgressive: boolean;
    hasIOD: boolean;
    brands: string[];
    created: Date;
    modified: Date;
    tracks: MP4MediaTrack[];
    audioTracks: MP4MediaTrack[];
    videoTracks: MP4MediaTrack[];
    otherTracks: MP4MediaTrack[];
  }

  export interface MP4Sample {
    track_id: number;
    description: any;
    is_rap: boolean;
    is_sync: boolean;
    timescale: number;
    dts: number;
    cts: number;
    duration: number;
    size: number;
    data: Uint8Array;
  }

  export class DataStream {
    static BIG_ENDIAN: boolean;
    static LITTLE_ENDIAN: boolean;
    buffer: ArrayBuffer;
    constructor(buffer?: ArrayBuffer, byteOffset?: number, endianness?: boolean);
    writeUint8(val: number): void;
    writeUint16(val: number): void;
    writeUint32(val: number): void;
  }

  export interface MP4File {
    onReady?: (info: MP4Info) => void;
    onError?: (e: string | Error) => void;
    onSamples?: (track_id: number, user: any, samples: MP4Sample[]) => void;
    appendBuffer(data: ArrayBuffer): number;
    start(): void;
    stop(): void;
    flush(): void;
    setExtractionOptions(track_id: number, user?: any, options?: { nbSamples?: number; rapAlignment?: boolean }): void;
    unsetExtractionOptions(track_id: number): void;
    getTrackById(track_id: number): any;
  }

  export function createFile(keepBuffers?: boolean): MP4File;

  const mp4box: {
    createFile: (keepBuffers?: boolean) => MP4File;
    DataStream: typeof DataStream;
  };

  export default mp4box;
}
