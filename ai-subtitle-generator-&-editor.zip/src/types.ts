export interface SubtitleCue {
  id: number;
  start: string; // "00:00:01,200"
  end: string;   // "00:00:04,500"
  startSeconds: number;
  endSeconds: number;
  speaker?: string;
  text_original: string;
  text_translated: string;
  customVolume?: number;
  box?: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export type SubtitleMode = 'original' | 'translated' | 'bilingual';

export type ChunkStatus = 'pending' | 'processing' | 'completed' | 'error';

export interface ProcessingChunk {
  id: string;
  chunkIndex: number;
  startTimeSeconds: number;
  endTimeSeconds: number;
  status: ChunkStatus;
  progress: number;
  errorMessage?: string;
  subtitles: SubtitleCue[];
  detectedLanguage?: string;
  isoCode?: string;
  confidence?: number;
  hasSpeech?: boolean;
}

export interface DetailedLanguageInfo {
  detectedLanguage: string;
  isoCode: string;
  confidence: number;
  dialect?: string;
  speechSpeed?: string;
  audioQuality?: string;
  sampleTranscription?: string;
}

export interface TranscribeOptions {
  sourceLanguage: string; // 'auto' or specific language
  targetLanguage: string;
  enableDiarization: boolean;
  chunkDurationMinutes: number; // e.g. 5 or 10 minutes
  maxCharsPerLine: number;
}

export interface LanguageInfo {
  detectedLanguage: string;
  isoCode: string;
  confidence: number;
}

export interface SessionHistoryItem {
  id: string;
  fileName: string;
  fileSize: number;
  durationSeconds: number;
  createdAt: string;
  detectedLanguage: string;
  isoCode: string;
  subtitles: SubtitleCue[];
  targetLanguage: string;
  videoUrl?: string;
}

export interface TargetLanguageOption {
  code: string;
  name: string;
  nativeName: string;
}

export const TARGET_LANGUAGES: TargetLanguageOption[] = [
  { code: 'vi', name: 'Vietnamese', nativeName: 'Tiếng Việt' },
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'zh', name: 'Chinese (Simplified)', nativeName: '中文 (简体)' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '中文 (繁體)' },
  { code: 'ja', name: 'Japanese', nativeName: '日本語' },
  { code: 'ko', name: 'Korean', nativeName: '한국어' },
  { code: 'fr', name: 'French', nativeName: 'Français' },
  { code: 'es', name: 'Spanish', nativeName: 'Español' },
  { code: 'de', name: 'German', nativeName: 'Deutsch' },
  { code: 'ru', name: 'Russian', nativeName: 'Русский' },
  { code: 'pt', name: 'Portuguese', nativeName: 'Português' },
  { code: 'it', name: 'Italian', nativeName: 'Italiano' },
  { code: 'th', name: 'Thai', nativeName: 'ไทย' },
  { code: 'id', name: 'Indonesian', nativeName: 'Bahasa Indonesia' },
  { code: 'ms', name: 'Malay', nativeName: 'Bahasa Melayu' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'ar', name: 'Arabic', nativeName: 'العربية' },
];

export type VoicePersonaId = 'female_lively' | 'male_expressive' | 'female_gentle' | 'male_anchor' | 'male_dynamic';

export interface VoicePersona {
  id: VoicePersonaId;
  name: string;
  gender: 'female' | 'male';
  voiceName: string;
  description: string;
  badge: string;
  sampleText: string;
  stylePrompt: string;
}

export const VOICE_PERSONAS: VoicePersona[] = [
  {
    id: 'female_lively',
    name: 'Cô gái hoạt ngôn',
    gender: 'female',
    voiceName: 'Kore',
    badge: 'Phổ biến',
    description: 'Giọng nữ trẻ trung, tươi vui, hoạt ngôn, diễn cảm tự nhiên.',
    sampleText: 'Xin chào các bạn, hôm nay chúng ta cùng khám phá điều thú vị này nhé!',
    stylePrompt: 'Đọc bằng giọng nữ hoạt ngôn, truyền cảm, nhịp điệu tự nhiên, ngắt nghỉ câu chuẩn xác theo dấu câu.',
  },
  {
    id: 'male_expressive',
    name: 'Nam Việt Nam truyền cảm',
    gender: 'male',
    voiceName: 'Fenrir',
    badge: 'Khuyên dùng',
    description: 'Giọng nam Việt Nam ấm áp, chân thật, truyền cảm xúc mạnh mẽ.',
    sampleText: 'Chào mừng các bạn đã quay trở lại với video ngày hôm nay.',
    stylePrompt: 'Đọc bằng giọng nam Việt Nam truyền cảm, ấm áp, ngắt nhịp câu rõ ràng và lôi cuốn.',
  },
  {
    id: 'female_gentle',
    name: 'Nữ dịu dàng / Trầm ấm',
    gender: 'female',
    voiceName: 'Zephyr',
    badge: 'Sâu lắng',
    description: 'Giọng nữ nhẹ nhàng, ngọt ngào, thích hợp cho truyện đọc, tâm sự.',
    sampleText: 'Hãy lắng nghe những giây phút bình yên nhất trong tâm hồn bạn.',
    stylePrompt: 'Đọc bằng giọng nữ dịu dàng, trầm ấm, mượt mà và sâu lắng.',
  },
  {
    id: 'male_anchor',
    name: 'Nam MC Tin tức / Chững chạc',
    gender: 'male',
    voiceName: 'Puck',
    badge: 'Chuyên nghiệp',
    description: 'Giọng nam chuẩn đài truyền hình, phát âm tròn vành rõ chữ, tự tin.',
    sampleText: 'Sau đây là bản tin cập nhật những sự kiện nổi bật nhất trong ngày.',
    stylePrompt: 'Đọc bằng giọng nam chững chạc, phát âm chuẩn xác, phong thái MC tin tức chuyên nghiệp.',
  },
  {
    id: 'male_dynamic',
    name: 'Nam Review Phim / Năng động',
    gender: 'male',
    voiceName: 'Charon',
    badge: 'Kịch tính',
    description: 'Giọng nam nhịp điệu nhanh, dồn dập, cực kỳ thích hợp cho Review phim hoặc video ngắn.',
    sampleText: 'Mọi chuyện bắt đầu từ khi anh ấy phát hiện ra bí mật kinh hoàng này!',
    stylePrompt: 'Đọc bằng giọng nam dồn dập, lôi cuốn, kịch tính, nhịp điệu review phim.',
  },
];

export interface DubbingConfig {
  personaId: VoicePersonaId;
  useTranslatedText: boolean;
  speechRate: number; // 0.8 - 1.5
  autoSyncTimings: boolean;
}

export type SubtitleFontFamily = 'sans' | 'serif' | 'mono' | 'impact' | 'montserrat' | 'space';
export type SubtitleGlowEffect = 'none' | 'soft' | 'neon' | 'gold' | 'intense';
export type SubtitleBgStyle = 'none' | 'black-translucent' | 'black-solid' | 'glass' | 'blur';
export type SubtitlePosition = 'bottom' | 'middle' | 'top';

export interface SubtitleStyleConfig {
  fontFamily: SubtitleFontFamily;
  fontSize: number; // 14 - 48
  textColor: string; // e.g. '#FFFFFF', '#FACC15', '#06B6D4'
  strokeColor: string; // 'none' | '#000000' | '#ffffff' | '#ef4444' | '#3b82f6'
  strokeWidth: number; // 0 - 4
  glowEffect: SubtitleGlowEffect;
  bgStyle: SubtitleBgStyle;
  position: SubtitlePosition;
  positionY: number; // 0 - 100 (percentage from top)
  positionX: number; // 0 - 100 (percentage from left)
  blurIntensity?: number; // 0 - 30 (pixels)
}

export const DEFAULT_SUBTITLE_STYLE: SubtitleStyleConfig = {
  fontFamily: 'sans',
  fontSize: 22,
  textColor: '#FFFFFF',
  strokeColor: '#000000',
  strokeWidth: 2,
  glowEffect: 'soft',
  bgStyle: 'black-translucent',
  position: 'bottom',
  positionY: 82,
  positionX: 50,
  blurIntensity: 14,
};

export type ActiveStudioTool = 'import' | 'ocr' | 'translate' | 'voice' | 'subtitle' | 'style' | 'export';

export interface StudioToolRailItem {
  id: ActiveStudioTool;
  label: string;
  sublabel: string;
  iconName: string;
}
