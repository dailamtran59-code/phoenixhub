/**
 * Helper utility to extract audio from video/audio files in browser
 * and slice audio into chunks encoded as 16kHz mono WAV for fast transmission.
 */

export interface AudioChunk {
  index: number;
  startTimeSeconds: number;
  endTimeSeconds: number;
  base64Wav: string;
}

/**
 * Decodes a sample slice (e.g. first 15MB) of a video file for quick language detection
 * without loading the entire multi-hundred megabyte file into WebAudio memory.
 */
export async function decodeFileSampleBuffer(
  file: File,
  maxBytes = 15 * 1024 * 1024,
  onProgress?: (stage: string, percent: number) => void
): Promise<AudioBuffer> {
  onProgress?.('Reading sample audio buffer...', 10);
  const blobSlice = file.slice(0, Math.min(file.size, maxBytes));
  const arrayBuffer = await blobSlice.arrayBuffer();

  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AudioCtx({ sampleRate: 16000 });

  try {
    const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    onProgress?.('Sample audio decoding complete', 100);
    audioCtx.close();
    return decodedBuffer;
  } catch {
    audioCtx.close();
    // Fallback to full file decode if header/slice cannot be decoded on certain video containers
    return decodeFileAudioBuffer(file, onProgress);
  }
}

/**
 * Decodes an MP4/video file's audio track into an AudioBuffer using web browser AudioContext
 */
export async function decodeFileAudioBuffer(
  file: File,
  onProgress?: (stage: string, percent: number) => void
): Promise<AudioBuffer> {
  onProgress?.('Reading video file...', 10);
  const arrayBuffer = await file.arrayBuffer();

  onProgress?.('Decoding audio track from video...', 40);
  
  // Use standard AudioContext
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const audioCtx = new AudioCtx({ sampleRate: 16000 }); // Downsample to 16kHz for speech recognition efficiency

  try {
    const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    onProgress?.('Audio decoding complete', 100);
    audioCtx.close();
    return decodedBuffer;
  } catch (err) {
    audioCtx.close();
    throw new Error('Could not decode audio from video file. Ensure file contains a valid audio track. ' + String(err));
  }
}

/**
 * Converts an AudioBuffer (or section of it) into a 16kHz mono WAV Base64 string
 */
export function audioBufferToWavBase64(
  audioBuffer: AudioBuffer,
  startSeconds = 0,
  durationSeconds?: number
): string {
  const sampleRate = 16000;
  const numChannels = 1; // Mono is optimal for speech recognition

  const startSample = Math.floor(startSeconds * audioBuffer.sampleRate);
  const totalSamplesToExtract = durationSeconds
    ? Math.floor(durationSeconds * audioBuffer.sampleRate)
    : audioBuffer.length - startSample;
  
  const actualEndSample = Math.min(startSample + totalSamplesToExtract, audioBuffer.length);
  const sampleCount = Math.max(0, actualEndSample - startSample);

  if (sampleCount === 0) {
    throw new Error('Selected audio section is empty');
  }

  // Extract PCM samples and downmix to mono if needed
  const monoSamples = new Float32Array(sampleCount);
  const origChannels = audioBuffer.numberOfChannels;
  const origSampleRate = audioBuffer.sampleRate;

  // Simple resampling ratio if origSampleRate != 16000
  const ratio = origSampleRate / sampleRate;
  const outputSampleCount = Math.floor(sampleCount / ratio);
  const outputSamples = new Float32Array(outputSampleCount);

  // Extract raw channel data
  const channelData: Float32Array[] = [];
  for (let c = 0; c < origChannels; c++) {
    channelData.push(audioBuffer.getChannelData(c));
  }

  for (let i = 0; i < outputSampleCount; i++) {
    const origIndex = startSample + Math.floor(i * ratio);
    let sum = 0;
    for (let c = 0; c < origChannels; c++) {
      if (origIndex < channelData[c].length) {
        sum += channelData[c][origIndex];
      }
    }
    outputSamples[i] = sum / origChannels;
  }

  // Build 16-bit PCM WAV File Header & Data
  const bytesPerSample = 2; // 16-bit
  const blockAlign = numChannels * bytesPerSample;
  const dataSize = outputSampleCount * blockAlign;
  const bufferLength = 44 + dataSize;

  const wavBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(wavBuffer);

  /* RIFF identifier */
  writeString(view, 0, 'RIFF');
  /* RIFF chunk length */
  view.setUint32(4, 36 + dataSize, true);
  /* RIFF type */
  writeString(view, 8, 'WAVE');
  /* format chunk identifier */
  writeString(view, 12, 'fmt ');
  /* format chunk length */
  view.setUint32(16, 16, true);
  /* sample format (raw PCM) */
  view.setUint16(20, 1, true);
  /* channel count */
  view.setUint16(22, numChannels, true);
  /* sample rate */
  view.setUint32(24, sampleRate, true);
  /* byte rate (sampleRate * blockAlign) */
  view.setUint32(28, sampleRate * blockAlign, true);
  /* block align */
  view.setUint16(32, blockAlign, true);
  /* bits per sample */
  view.setUint16(34, 16, true);
  /* data chunk identifier */
  writeString(view, 36, 'data');
  /* data chunk length */
  view.setUint32(40, dataSize, true);

  // Write PCM samples
  let offset = 44;
  for (let i = 0; i < outputSampleCount; i++) {
    const s = Math.max(-1, Math.min(1, outputSamples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    offset += 2;
  }

  // Convert ArrayBuffer to Base64 efficiently in 8KB chunks
  const bytes = new Uint8Array(wavBuffer);
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, i + chunkSize);
    binary += String.fromCharCode.apply(null, chunk as unknown as number[]);
  }

  return btoa(binary);
}

export function audioBufferToWavBlob(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;

  let interleaved: Float32Array;
  if (numChannels === 2) {
    const left = buffer.getChannelData(0);
    const right = buffer.getChannelData(1);
    interleaved = new Float32Array(left.length + right.length);
    for (let i = 0; i < left.length; i++) {
      interleaved[i * 2] = left[i];
      interleaved[i * 2 + 1] = right[i];
    }
  } else {
    interleaved = buffer.getChannelData(0);
  }

  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  const dataSize = interleaved.length * bytesPerSample;
  const headerSize = 44;
  const totalSize = headerSize + dataSize;

  const arrayBuffer = new ArrayBuffer(totalSize);
  const view = new DataView(arrayBuffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataSize, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataSize, true);

  let offset = 44;
  for (let i = 0; i < interleaved.length; i++) {
    const s = Math.max(-1, Math.min(1, interleaved[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    offset += 2;
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

import { SubtitleCue } from '../types';
import { stripSpeakerPrefix } from './subtitleStyle';

export interface GenerateDubbingOptions {
  cues: SubtitleCue[];
  videoDuration: number;
  voiceName: string;
  stylePrompt?: string;
  model?: string;
  speakingSpeed?: number;
  volume?: number;
  useTranslated?: boolean;
  perCueVolumes?: Record<number, number>;
  perCueSpeeds?: Record<number, number>;
  onProgress?: (percent: number, message: string) => void;
}

export interface GenerateDubbingResult {
  audioBlob: Blob;
  audioUrl: string;
  audioDuration: number;
  adjustedCues: SubtitleCue[];
  ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[];
}

/**
 * Trims an AudioBuffer to maxSamples and applies a smooth linear fade-out over fadeMs at the end
 * to prevent audible clicks or abrupt cuts.
 */
export function trimAudioBufferWithFadeOut(
  buffer: AudioBuffer,
  maxSamples: number,
  fadeMs = 25
): AudioBuffer {
  const targetLen = Math.max(1, Math.min(Math.floor(maxSamples), buffer.length));
  if (targetLen >= buffer.length) {
    return buffer;
  }

  const OfflineAudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const channels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;

  const tempCtx = new OfflineAudioContextClass(channels, targetLen, sampleRate);
  const newBuffer = tempCtx.createBuffer(channels, targetLen, sampleRate);

  const fadeSamples = Math.min(targetLen, Math.floor((fadeMs / 1000) * sampleRate));
  const fadeStart = targetLen - fadeSamples;

  for (let ch = 0; ch < channels; ch++) {
    const srcData = buffer.getChannelData(ch);
    const dstData = newBuffer.getChannelData(ch);

    // Copy initial portion
    dstData.set(srcData.subarray(0, targetLen));

    // Apply linear fade-out in the last fadeSamples
    if (fadeSamples > 0) {
      for (let i = 0; i < fadeSamples; i++) {
        const idx = fadeStart + i;
        const factor = (fadeSamples - i) / fadeSamples;
        dstData[idx] = dstData[idx] * factor;
      }
    }
  }

  return newBuffer;
}

/**
 * Assembles dubbed audio clips into a single master AudioBuffer,
 * preserving original subtitle start timestamps and applying smooth fade-out truncation if needed.
 */
export async function assembleDubbedAudioBuffer({
  ttsResults,
  validCues,
  videoDuration = 0,
  masterVolume = 1.0,
  masterSpeakingSpeed = 1.0,
  perCueVolumes = {},
  perCueSpeeds = {},
}: {
  ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[];
  validCues: SubtitleCue[];
  videoDuration?: number;
  masterVolume?: number;
  masterSpeakingSpeed?: number;
  perCueVolumes?: Record<number, number>;
  perCueSpeeds?: Record<number, number>;
}): Promise<AudioBuffer> {
  const sortedResults = [...ttsResults].sort((a, b) => a.startSeconds - b.startSeconds);

  const lastCueEnd = validCues[validCues.length - 1]?.endSeconds || 0;
  const masterDurationSec = Math.max(videoDuration || 0, lastCueEnd + 2, 5);

  const sampleRate = 44100;
  const totalSamples = Math.floor(masterDurationSec * sampleRate);
  const OfflineAudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const offlineCtx = new OfflineAudioContextClass(1, totalSamples, sampleRate);

  for (let idx = 0; idx < sortedResults.length; idx++) {
    const item = sortedResults[idx];
    const nextItem = sortedResults[idx + 1];

    const cueVolMult = (perCueVolumes[item.cueId] ?? 1.0) * masterVolume;
    const speechDurationSec = item.audioBuffer.duration;
    const speedFactor = perCueSpeeds[item.cueId] ?? masterSpeakingSpeed;

    // 1. MUST ALWAYS start strictly at item.startSeconds (original video time when character speaks)
    const startSec = Math.max(0, item.startSeconds);

    // 2. Available time window calculation:
    // - If cues genuinely overlap in original data (nextItem.startSeconds < item.endSeconds, e.g. 2 speakers talking simultaneously),
    //   allow up to cue's own end time so both tracks mix without cutting the first speaker.
    // - Otherwise (standard sequential dialog), strictly limit to nextItem.startSeconds so AI speech never bleeds into the next cue.
    let availableSec = Infinity;
    if (nextItem) {
      const naturalSlot = nextItem.startSeconds - startSec;
      const isGenuineOverlap = nextItem.startSeconds < item.endSeconds;
      availableSec = isGenuineOverlap
        ? Math.max(0.15, item.endSeconds - startSec)
        : Math.max(0.15, naturalSlot);
    }
    const actualDuration = speechDurationSec / speedFactor;

    const source = offlineCtx.createBufferSource();
    source.playbackRate.value = speedFactor;

    if (actualDuration > availableSec && isFinite(availableSec)) {
      // Cắt buffer TTS cho vừa khoảng trống, kèm fade-out 25ms cuối để không bị click tiếng
      const targetSamples = Math.floor(availableSec * speedFactor * item.audioBuffer.sampleRate);
      const trimmedBuffer = trimAudioBufferWithFadeOut(item.audioBuffer, targetSamples, 25);
      source.buffer = trimmedBuffer;
    } else {
      source.buffer = item.audioBuffer;
    }

    const gain = offlineCtx.createGain();
    gain.gain.setValueAtTime(cueVolMult, startSec);

    source.connect(gain);
    gain.connect(offlineCtx.destination);

    source.start(startSec);
  }

  return await offlineCtx.startRendering();
}

export async function generateFullDubbedAudio(
  options: GenerateDubbingOptions
): Promise<GenerateDubbingResult> {
  const {
    cues,
    videoDuration = 0,
    voiceName = 'Kore',
    stylePrompt = '',
    model = 'gemini-3.1-flash-tts-preview',
    speakingSpeed = 1.0,
    volume = 1.0,
    useTranslated = true,
    perCueVolumes = {},
    perCueSpeeds = {},
    onProgress,
  } = options;

  if (!cues || cues.length === 0) {
    throw new Error('Danh sách phụ đề trống, không thể tạo lồng tiếng.');
  }

  const getCueText = (c: SubtitleCue) => {
    const raw = (useTranslated ? (c.text_translated || c.text_original) : (c.text_original || c.text_translated)) || '';
    return stripSpeakerPrefix(raw).trim();
  };

  const validCues = cues.filter((c) => getCueText(c).length > 0);
  if (validCues.length === 0) {
    throw new Error('Không có nội dung văn bản phụ đề nào để tổng hợp giọng nói.');
  }

  onProgress?.(5, 'Đang chuẩn bị môi trường xử lý âm thanh AI...');

  const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
  const audioCtx = new AudioCtxClass({ sampleRate: 44100 });
  if (audioCtx.state === 'suspended') {
    try {
      await audioCtx.resume();
    } catch {
      // ignore
    }
  }

  const totalCount = validCues.length;
  const ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer }[] = [];
  const CONCURRENCY = 5;
  let nextIndex = 0;
  let completedCount = 0;

  async function fetchTtsForCue(cue: SubtitleCue, text: string) {
    for (let attempt = 1; attempt <= 4; attempt++) {
      try {
        const res = await fetch('/api/tts/single', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            text,
            voiceName,
            stylePrompt,
            model,
            allowFallback: true,
          }),
        });

        const data = await res.json();
        if (res.ok && data.audioBase64) {
          const binary = atob(data.audioBase64);
          const bytes = new Uint8Array(binary.length);
          for (let b = 0; b < binary.length; b++) {
            bytes[b] = binary.charCodeAt(b);
          }
          const audioBuffer = await audioCtx.decodeAudioData(bytes.buffer.slice(0));
          return {
            cueId: cue.id,
            startSeconds: cue.startSeconds,
            endSeconds: cue.endSeconds,
            audioBuffer,
          };
        }

        if (res.status === 429 && attempt < 4) {
          await new Promise((resolve) => setTimeout(resolve, 1500 * attempt));
          continue;
        }
      } catch {
        if (attempt < 4) {
          await new Promise((resolve) => setTimeout(resolve, 1000 * attempt));
          continue;
        }
      }
    }
    return null;
  }

  async function worker() {
    while (nextIndex < validCues.length) {
      const myIndex = nextIndex++;
      const cue = validCues[myIndex];
      const text = getCueText(cue);
      if (text) {
        const result = await fetchTtsForCue(cue, text);
        if (result) {
          ttsResults.push(result);
        }
      }
      completedCount++;
      const progressPct = Math.min(85, Math.round(10 + (completedCount / totalCount) * 75));
      onProgress?.(progressPct, `Đang lồng tiếng câu ${completedCount} / ${totalCount}...`);
    }
  }

  const poolSize = Math.min(CONCURRENCY, validCues.length);
  await Promise.all(Array.from({ length: poolSize }, () => worker()));

  if (ttsResults.length === 0) {
    throw new Error('Không nhận được dữ liệu âm thanh từ server. Vui lòng kiểm tra lại kết nối.');
  }

  onProgress?.(88, 'Đang ghép âm thanh đa kênh và căn chỉnh timeline...');

  const masterAudioBuffer = await assembleDubbedAudioBuffer({
    ttsResults,
    validCues,
    videoDuration,
    masterVolume: volume,
    masterSpeakingSpeed: speakingSpeed,
    perCueVolumes,
    perCueSpeeds,
  });

  onProgress?.(95, 'Đang kết xuất tệp âm thanh WAV chất lượng cao...');

  const audioBlob = audioBufferToWavBlob(masterAudioBuffer);
  const audioUrl = URL.createObjectURL(audioBlob);

  onProgress?.(100, 'Lồng tiếng thành công!');

  return {
    audioBlob,
    audioUrl,
    audioDuration: masterAudioBuffer.duration,
    adjustedCues: cues,
    ttsResults,
  };
}

function writeString(view: DataView, offset: number, string: string) {

  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

