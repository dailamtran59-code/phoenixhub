/**
 * Dubbing Timing Engine & Synchronization Diagnostics
 * Handles sync health reporting, queue concurrency, and in-memory TTS caching.
 */

import { SubtitleCue } from '../types';

export interface CueSyncDiagnostic {
  cueId: number;
  text: string;
  startSeconds: number;
  endSeconds: number;
  allocatedSlotSec: number;
  actualDurationSec: number;
  status: 'PERFECT' | 'NATURAL_PAUSE' | 'FADE_OUT_TRIMMED' | 'OVERLAPPED_MIXED';
  fadeMs?: number;
  silenceGapSec?: number;
  speedMultiplier: number;
  volumeMultiplier: number;
  engineUsed: string;
}

export interface DubbingSyncReport {
  totalCues: number;
  perfectCues: number;
  trimmedCues: number;
  overlappingCues: number;
  naturalPausesCues: number;
  syncHealthScore: number; // 0 - 100%
  totalOriginalSubtitleDuration: number;
  totalMasterAudioDuration: number;
  diagnostics: CueSyncDiagnostic[];
  timestamp: string;
}

/**
 * Generates an Auto Sync Report comparing cues to their assembled audio timing
 */
export function analyzeDubbingSync({
  cues,
  ttsResults,
  masterAudioDuration,
  masterSpeakingSpeed = 1.0,
  perCueSpeeds = {},
  perCueVolumes = {},
}: {
  cues: SubtitleCue[];
  ttsResults: { cueId: number; startSeconds: number; endSeconds: number; audioBuffer: AudioBuffer; engine?: string }[];
  masterAudioDuration: number;
  masterSpeakingSpeed?: number;
  perCueSpeeds?: Record<number, number>;
  perCueVolumes?: Record<number, number>;
}): DubbingSyncReport {
  const ttsMap = new Map(ttsResults.map((r) => [r.cueId, r]));
  const sortedCues = [...cues].sort((a, b) => a.startSeconds - b.startSeconds);

  let perfectCount = 0;
  let trimmedCount = 0;
  let overlappedCount = 0;
  let naturalPauseCount = 0;

  const diagnostics: CueSyncDiagnostic[] = [];

  for (let i = 0; i < sortedCues.length; i++) {
    const cue = sortedCues[i];
    const nextCue = sortedCues[i + 1];
    const tts = ttsMap.get(cue.id);

    const speed = perCueSpeeds[cue.id] ?? masterSpeakingSpeed;
    const vol = perCueVolumes[cue.id] ?? 1.0;
    const rawText = cue.text_translated || cue.text_original || '';

    if (!tts) {
      continue;
    }

    const startSec = Math.max(0, cue.startSeconds);
    const speechDuration = tts.audioBuffer.duration;
    const actualDurationSec = speechDuration / speed;

    let allocatedSlotSec = Infinity;
    if (nextCue) {
      const naturalSlot = nextCue.startSeconds - startSec;
      const isGenuineOverlap = nextCue.startSeconds < cue.endSeconds;
      allocatedSlotSec = isGenuineOverlap
        ? Math.max(0.15, cue.endSeconds - startSec)
        : Math.max(0.15, naturalSlot);
    }

    let status: CueSyncDiagnostic['status'] = 'PERFECT';
    let silenceGapSec: number | undefined;
    let fadeMs: number | undefined;

    if (nextCue && nextCue.startSeconds < cue.endSeconds) {
      status = 'OVERLAPPED_MIXED';
      overlappedCount++;
    } else if (actualDurationSec > allocatedSlotSec && isFinite(allocatedSlotSec)) {
      status = 'FADE_OUT_TRIMMED';
      fadeMs = 25;
      trimmedCount++;
    } else if (nextCue && actualDurationSec < nextCue.startSeconds - startSec) {
      status = 'NATURAL_PAUSE';
      silenceGapSec = Math.max(0, (nextCue.startSeconds - startSec) - actualDurationSec);
      naturalPauseCount++;
    } else {
      status = 'PERFECT';
      perfectCount++;
    }

    diagnostics.push({
      cueId: cue.id,
      text: rawText,
      startSeconds: cue.startSeconds,
      endSeconds: cue.endSeconds,
      allocatedSlotSec: isFinite(allocatedSlotSec) ? allocatedSlotSec : cue.endSeconds - startSec,
      actualDurationSec,
      status,
      fadeMs,
      silenceGapSec,
      speedMultiplier: speed,
      volumeMultiplier: vol,
      engineUsed: tts.engine || 'gemini-3.1',
    });
  }

  const totalEvaluated = diagnostics.length || 1;
  // High score when no collision or cleanly handled
  const healthScore = Math.max(0, Math.min(100, Math.round(((perfectCount + naturalPauseCount + overlappedCount * 0.9 + trimmedCount * 0.7) / totalEvaluated) * 100)));

  const totalSubtitleDuration = sortedCues.reduce((acc, curr) => acc + (curr.endSeconds - curr.startSeconds), 0);

  return {
    totalCues: sortedCues.length,
    perfectCues: perfectCount,
    trimmedCues: trimmedCount,
    overlappingCues: overlappedCount,
    naturalPausesCues: naturalPauseCount,
    syncHealthScore: healthScore,
    totalOriginalSubtitleDuration: totalSubtitleDuration,
    totalMasterAudioDuration: masterAudioDuration,
    diagnostics,
    timestamp: new Date().toLocaleTimeString(),
  };
}

/**
 * LRU In-Memory Cache for synthesised audio buffers
 */
class TtsBufferCache {
  private cache = new Map<string, { buffer: AudioBuffer; timestamp: number; engine: string }>();
  private maxItems = 200;

  private generateKey(text: string, voiceName: string, model: string, speed: number): string {
    return `${voiceName}::${model}::${speed.toFixed(2)}::${text.trim()}`;
  }

  get(text: string, voiceName: string, model: string, speed: number = 1.0): { buffer: AudioBuffer; engine: string } | null {
    const key = this.generateKey(text, voiceName, model, speed);
    const item = this.cache.get(key);
    if (!item) return null;
    item.timestamp = Date.now();
    return { buffer: item.buffer, engine: item.engine };
  }

  set(text: string, voiceName: string, model: string, speed: number, buffer: AudioBuffer, engine: string): void {
    if (this.cache.size >= this.maxItems) {
      let oldestKey: string | null = null;
      let oldestTime = Infinity;
      for (const [k, v] of this.cache.entries()) {
        if (v.timestamp < oldestTime) {
          oldestTime = v.timestamp;
          oldestKey = k;
        }
      }
      if (oldestKey) {
        this.cache.delete(oldestKey);
      }
    }
    const key = this.generateKey(text, voiceName, model, speed);
    this.cache.set(key, { buffer, timestamp: Date.now(), engine });
  }

  clear(): void {
    this.cache.clear();
  }
}

export const globalTtsCache = new TtsBufferCache();

/**
 * Concurrency Queue with Worker Pool for TTS requests (3-5 workers)
 */
export async function runConcurrentQueue<T, R>(
  items: T[],
  workerFn: (item: T, index: number) => Promise<R>,
  concurrency = 3,
  onProgress?: (completed: number, total: number) => void
): Promise<R[]> {
  const results: R[] = new Array(items.length);
  let currentIndex = 0;
  let completedCount = 0;

  const runWorker = async () => {
    while (currentIndex < items.length) {
      const idx = currentIndex++;
      try {
        const res = await workerFn(items[idx], idx);
        results[idx] = res;
      } catch (err) {
        console.error(`Queue error on item index ${idx}:`, err);
      } finally {
        completedCount++;
        if (onProgress) {
          onProgress(completedCount, items.length);
        }
      }
    }
  };

  const poolSize = Math.min(concurrency, items.length);
  const workers = Array.from({ length: poolSize }, () => runWorker());
  await Promise.all(workers);

  return results;
}
