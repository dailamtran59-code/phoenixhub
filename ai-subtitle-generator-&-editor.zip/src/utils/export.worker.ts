import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
import { createFile, DataStream, MP4Info, MP4Sample, MP4MediaTrack } from 'mp4box';
import { SubtitleCue, SubtitleStyleConfig } from '../types';
import { SubtitleCursor, renderSubtitleOnCanvas, getFontFamilyDefinitions } from './subtitleRendererCore';
import { ExportProgressStats } from './exportVideo';

interface DemuxedTrackInfo {
  track: MP4MediaTrack;
  description?: Uint8Array;
  fps: number;
  durationSeconds: number;
  samples: MP4Sample[];
}

function normalizeFramerate(rawFps: number): number {
  if (!rawFps || isNaN(rawFps) || rawFps <= 0) return 30;

  const standardRates = [
    { target: 23.976, exact: 24000 / 1001 },
    { target: 24, exact: 24 },
    { target: 25, exact: 25 },
    { target: 29.97, exact: 30000 / 1001 },
    { target: 30, exact: 30 },
    { target: 48, exact: 48 },
    { target: 50, exact: 50 },
    { target: 59.94, exact: 60000 / 1001 },
    { target: 60, exact: 60 },
  ];

  for (const { target, exact } of standardRates) {
    if (Math.abs(rawFps - target) < 0.15 || Math.abs(rawFps - exact) < 0.15) {
      return target;
    }
  }

  return Math.min(120, Math.max(1, Math.round(rawFps * 1000) / 1000));
}

function getTrackExtradata(mp4boxFile: any, trackId: number): Uint8Array | undefined {
  try {
    const track = mp4boxFile.getTrackById(trackId);
    if (!track?.mdia?.minf?.stbl?.stsd?.entries) return undefined;

    for (const entry of track.mdia.minf.stbl.stsd.entries) {
      const box = entry.avcC || entry.hvcC || entry.vpcC || entry.av1C;
      if (box) {
        const stream = new DataStream(undefined, 0, DataStream.BIG_ENDIAN);
        box.write(stream);
        return new Uint8Array(stream.buffer, 8);
      }
    }
  } catch (err) {
    console.warn('[MP4Box Worker] Failed to extract extradata box:', err);
  }
  return undefined;
}

async function demuxVideoFile(
  arrayBuffer: ArrayBuffer,
  onProgress?: (percent: number, msg: string) => void
): Promise<DemuxedTrackInfo> {
  return new Promise((resolve, reject) => {
    const mp4boxFile = createFile();
    let videoTrack: MP4MediaTrack | null = null;
    const collectedSamples: MP4Sample[] = [];

    let isFinished = false;
    let timeoutId: any = null;

    const finishDemux = () => {
      if (isFinished) return;
      isFinished = true;
      if (timeoutId) clearTimeout(timeoutId);

      if (!videoTrack) {
        return reject(new Error('Video track không tồn tại sau khi demux'));
      }

      const timescale = videoTrack.timescale || 1000;
      const durationSeconds = videoTrack.duration ? videoTrack.duration / timescale : 1;
      const sampleCount = collectedSamples.length || videoTrack.nb_samples || 1;

      let rawFps = 30;
      if (sampleCount > 0 && durationSeconds > 0) {
        rawFps = sampleCount / durationSeconds;
      }

      const realFps = normalizeFramerate(rawFps);
      const extradata = getTrackExtradata(mp4boxFile, videoTrack.id);

      resolve({
        track: videoTrack,
        description: extradata,
        fps: realFps,
        durationSeconds,
        samples: collectedSamples,
      });
    };

    mp4boxFile.onError = (err) => {
      if (isFinished) return;
      isFinished = true;
      if (timeoutId) clearTimeout(timeoutId);
      reject(new Error(typeof err === 'string' ? err : 'MP4Box Demuxing failed'));
    };

    mp4boxFile.onReady = (info: MP4Info) => {
      if (!info.videoTracks || info.videoTracks.length === 0) {
        if (timeoutId) clearTimeout(timeoutId);
        return reject(new Error('Không tìm thấy video track trong tệp nguồn'));
      }

      videoTrack = info.videoTracks[0];
      mp4boxFile.setExtractionOptions(videoTrack.id, null, { nbSamples: 1000 });
      mp4boxFile.start();
    };

    mp4boxFile.onSamples = (trackId: number, _user: any, samples: MP4Sample[]) => {
      if (videoTrack && trackId === videoTrack.id) {
        collectedSamples.push(...samples);

        if (videoTrack.nb_samples > 0) {
          const demuxPercent = Math.min(18, 5 + Math.round((collectedSamples.length / videoTrack.nb_samples) * 13));
          onProgress?.(demuxPercent, `Đang phân tích khung hình gốc (${collectedSamples.length}/${videoTrack.nb_samples})...`);

          if (collectedSamples.length >= videoTrack.nb_samples) {
            finishDemux();
          }
        }
      }
    };

    try {
      (arrayBuffer as any).fileStart = 0;
      mp4boxFile.appendBuffer(arrayBuffer);
      mp4boxFile.flush();

      // Fallback check after flush
      timeoutId = setTimeout(() => {
        if (videoTrack && collectedSamples.length > 0) {
          finishDemux();
        } else {
          isFinished = true;
          reject(new Error('Timeout phân tích cấu trúc video trong Worker'));
        }
      }, 30000);
    } catch (e) {
      if (timeoutId) clearTimeout(timeoutId);
      reject(e);
    }
  });
}

self.onmessage = async (e: MessageEvent) => {
  const {
    type,
    videoArrayBuffer,
    audioData,
    subtitles = [],
    subtitleStyle,
    fileName = 'video_dubbed.mp4',
    performanceMode = 'prefer-hardware',
  } = e.data || {};

  if (type !== 'START') return;

  const startTime = performance.now();

  try {
    self.postMessage({ type: 'PROGRESS', percent: 3, message: 'Worker: Đang phân tích luồng video MP4...' });

    self.postMessage({ type: 'PROGRESS', percent: 5, message: 'Worker: Đang demux MP4 metadata...' });
    const demuxInfo = await demuxVideoFile(videoArrayBuffer, (percent, msg) => {
      self.postMessage({ type: 'PROGRESS', percent, message: `Worker: ${msg}` });
    });

    const width = demuxInfo.track.video?.width || 1280;
    const height = demuxInfo.track.video?.height || 720;
    const duration = Math.max(0.1, demuxInfo.durationSeconds || 1);
    const sourceFps = demuxInfo.fps || 30;

    const encWidth = width % 2 === 0 ? width : width - 1;
    const encHeight = height % 2 === 0 ? height : height - 1;

    // Check OffscreenCanvas support
    if (typeof OffscreenCanvas === 'undefined') {
      self.postMessage({
        type: 'ERROR',
        error: 'OffscreenCanvas không được hỗ trợ trong Worker',
        canFallbackToMain: true,
      });
      return;
    }

    const canvas = new OffscreenCanvas(encWidth, encHeight);
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
    if (!ctx) {
      self.postMessage({
        type: 'ERROR',
        error: 'Không thể tạo ngữ cảnh Canvas 2D trong Worker',
        canFallbackToMain: true,
      });
      return;
    }

    // Configure Muxer
    const muxerOptions: any = {
      target: new ArrayBufferTarget(),
      video: {
        codec: 'avc',
        width: encWidth,
        height: encHeight,
      },
      fastStart: 'in-memory',
      firstTimestampBehavior: 'offset',
    };

    if (audioData) {
      muxerOptions.audio = {
        codec: 'aac',
        numberOfChannels: Math.min(2, audioData.numberOfChannels),
        sampleRate: audioData.sampleRate,
      };
    }

    const muxer = new Muxer(muxerOptions);

    // Choose VideoEncoder configuration
    const targetBitrate =
      encWidth * encHeight > 1920 * 1080
        ? 8_000_000
        : encWidth * encHeight > 1280 * 720
        ? 4_500_000
        : 2_500_000;

    const candidateCodecs = [
      'avc1.640028',
      'avc1.4D0020',
      'avc1.42E01E',
    ];

    let chosenConfig: VideoEncoderConfig | null = null;
    if (typeof VideoEncoder !== 'undefined') {
      for (const codec of candidateCodecs) {
        const config: VideoEncoderConfig = {
          codec,
          width: encWidth,
          height: encHeight,
          bitrate: targetBitrate,
          framerate: sourceFps,
          hardwareAcceleration: performanceMode,
        };
        try {
          const support = await VideoEncoder.isConfigSupported(config);
          if (support.supported && support.config) {
            chosenConfig = support.config;
            break;
          }
        } catch {
          // ignore
        }
      }
    }

    if (!chosenConfig) {
      chosenConfig = {
        codec: 'avc1.42E01E',
        width: encWidth,
        height: encHeight,
        bitrate: targetBitrate,
        framerate: sourceFps,
        hardwareAcceleration: performanceMode,
      };
    }

    self.postMessage({
      type: 'PROGRESS',
      percent: 22,
      message: `Worker: Khởi tạo Bộ mã hóa phần cứng (${chosenConfig.codec} @ ${sourceFps} FPS)...`,
    });

    let encoderError: Error | null = null;
    const videoEncoder = new VideoEncoder({
      output: (chunk, meta) => muxer.addVideoChunk(chunk, meta as any),
      error: (e) => {
        console.error('[Worker VideoEncoder Error]', e);
        encoderError = new Error(`VideoEncoder: ${e.message}`);
      },
    });

    videoEncoder.configure(chosenConfig);

    // Encode Audio if present
    if (audioData && typeof AudioEncoder !== 'undefined' && typeof AudioData !== 'undefined') {
      self.postMessage({ type: 'PROGRESS', percent: 24, message: 'Worker: Đang đóng gói luồng âm thanh AAC...' });

      const audioEncoder = new AudioEncoder({
        output: (chunk, meta) => muxer.addAudioChunk(chunk, meta as any),
        error: (e) => console.error('[Worker AudioEncoder Error]', e),
      });

      audioEncoder.configure({
        codec: 'mp4a.40.2',
        numberOfChannels: Math.min(2, audioData.numberOfChannels),
        sampleRate: audioData.sampleRate,
        bitrate: 160_000,
      });

      const sampleRate = audioData.sampleRate;
      const numChannels = Math.min(2, audioData.numberOfChannels);
      const audioLen = audioData.length;
      const framesPerChunk = Math.round(sampleRate * 0.5); // 500ms chunks

      for (let offset = 0; offset < audioLen; offset += framesPerChunk) {
        const frameCount = Math.min(framesPerChunk, audioLen - offset);
        const planarData = new Float32Array(frameCount * numChannels);

        for (let c = 0; c < numChannels; c++) {
          const channelArr = audioData.channelData[c];
          planarData.set(channelArr.subarray(offset, offset + frameCount), c * frameCount);
        }

        const audioDataObj = new AudioData({
          format: 'f32-planar',
          sampleRate,
          numberOfFrames: frameCount,
          numberOfChannels: numChannels,
          timestamp: Math.round((offset / sampleRate) * 1e6),
          data: planarData,
        });

        audioEncoder.encode(audioDataObj);
        audioDataObj.close();
      }

      await audioEncoder.flush();
      audioEncoder.close();
    }

    // Check direct VideoDecoder compatibility
    if (
      typeof VideoDecoder === 'undefined' ||
      !demuxInfo ||
      demuxInfo.samples.length === 0 ||
      !demuxInfo.description
    ) {
      self.postMessage({
        type: 'ERROR',
        error: 'VideoDecoder không hỗ trợ định dạng MP4 này trong Worker',
        canFallbackToMain: true,
      });
      return;
    }

    const decoderCodec = demuxInfo.track.codec || 'avc1.42E01E';
    const testDecoderConfig: VideoDecoderConfig = {
      codec: decoderCodec,
      codedWidth: encWidth,
      codedHeight: encHeight,
      description: demuxInfo.description,
      hardwareAcceleration: performanceMode,
    };

    let canUseDirectDecoder = false;
    try {
      const decSupport = await VideoDecoder.isConfigSupported(testDecoderConfig);
      if (decSupport.supported) {
        canUseDirectDecoder = true;
      }
    } catch (decErr) {
      console.warn('[Worker VideoDecoder] isConfigSupported error:', decErr);
    }

    if (!canUseDirectDecoder) {
      self.postMessage({
        type: 'ERROR',
        error: 'Cấu hình giải mã phần cứng không được hỗ trợ trong Worker',
        canFallbackToMain: true,
      });
      return;
    }

    // Direct VideoDecoder pipeline in Worker
    const subtitleCursor = new SubtitleCursor(subtitles);
    let encodedFrames = 0;
    const totalFrames = demuxInfo.samples.length;
    let decoderError: Error | null = null;
    let frameIndex = 0;

    const videoDecoder = new VideoDecoder({
      output: (decodedFrame: VideoFrame) => {
        try {
          if (encoderError) throw encoderError;

          // 1. Draw decoded frame onto OffscreenCanvas
          ctx.drawImage(decodedFrame, 0, 0, encWidth, encHeight);

          // 2. Render burned subtitle cue
          const mediaTimeSec = (decodedFrame.timestamp || 0) / 1e6;
          const activeCue = subtitleCursor.getActiveCue(mediaTimeSec);
          const textToRender = activeCue?.text_translated || activeCue?.text_original;

          if (activeCue && textToRender) {
            renderSubtitleOnCanvas(
              ctx,
              null,
              textToRender,
              subtitleStyle,
              encWidth,
              encHeight,
              activeCue.box
            );
          }

          // 3. Create VideoFrame from OffscreenCanvas and encode
          const isKeyFrame = frameIndex % Math.round(sourceFps * 2) === 0;
          const outFrame = new VideoFrame(canvas, {
            timestamp: decodedFrame.timestamp,
            duration: decodedFrame.duration || Math.round((1 / sourceFps) * 1e6),
          });

          videoEncoder.encode(outFrame, { keyFrame: isKeyFrame });

          outFrame.close();
          decodedFrame.close();

          encodedFrames++;
          frameIndex++;

          // Progress & Stats reporting
          const elapsedSec = (performance.now() - startTime) / 1000;
          const currentFps = encodedFrames / Math.max(0.1, elapsedSec);
          const progressPercent = Math.min(98, Math.round(28 + (encodedFrames / totalFrames) * 70));
          const remainingFrames = Math.max(0, totalFrames - encodedFrames);
          const etaSec = currentFps > 0 ? remainingFrames / currentFps : null;

          if (encodedFrames % 10 === 0 || encodedFrames === totalFrames) {
            self.postMessage({
              type: 'PROGRESS',
              percent: progressPercent,
              message: `Worker xử lý: ${encodedFrames}/${totalFrames} khung hình (${Math.round(currentFps)} FPS, ${Math.round(mediaTimeSec)}s / ${Math.round(duration)}s)`,
            });

            const stats: ExportProgressStats = {
              percent: progressPercent,
              message: `Khung hình ${encodedFrames}/${totalFrames}`,
              currentFrame: encodedFrames,
              totalFrames,
              fps: Math.round(currentFps * 10) / 10,
              sourceFps,
              elapsedSeconds: Math.round(elapsedSec),
              etaSeconds: etaSec ? Math.round(etaSec) : null,
              codec: chosenConfig.codec,
              acceleration: chosenConfig.hardwareAcceleration || performanceMode,
              pipeline: 'WebCodecs Decoder (Worker)',
              encodeQueueSize: videoEncoder.encodeQueueSize,
            };

            self.postMessage({
              type: 'STATS',
              stats,
            });
          }
        } catch (renderErr: any) {
          decoderError = renderErr;
          decodedFrame.close();
        }
      },
      error: (e) => {
        console.error('[Worker VideoDecoder Error]', e);
        decoderError = new Error(`VideoDecoder error: ${e.message}`);
      },
    });

    videoDecoder.configure({
      codec: decoderCodec,
      codedWidth: encWidth,
      codedHeight: encHeight,
      description: demuxInfo.description,
      hardwareAcceleration: performanceMode,
    });

    for (const sample of demuxInfo.samples) {
      if (decoderError) throw decoderError;
      if (encoderError) throw encoderError;

      while (videoDecoder.decodeQueueSize > 8 || videoEncoder.encodeQueueSize > 8) {
        await new Promise((r) => setTimeout(r, 8));
      }

      const timescale = sample.timescale || demuxInfo.track.timescale || 1000;
      const timestampMicroseconds = Math.round((sample.cts * 1_000_000) / timescale);
      const durationMicroseconds = Math.round((sample.duration * 1_000_000) / timescale);

      const chunk = new EncodedVideoChunk({
        type: sample.is_sync ? 'key' : 'delta',
        timestamp: timestampMicroseconds,
        duration: durationMicroseconds,
        data: sample.data,
      });

      videoDecoder.decode(chunk);
    }

    await videoDecoder.flush();
    videoDecoder.close();

    self.postMessage({ type: 'PROGRESS', percent: 99, message: 'Worker: Đang hoàn tất đóng gói file MP4...' });
    await videoEncoder.flush();
    videoEncoder.close();
    muxer.finalize();

    const { buffer } = muxer.target as ArrayBufferTarget;
    const totalElapsedSec = (performance.now() - startTime) / 1000;
    const avgFps = encodedFrames / Math.max(0.1, totalElapsedSec);

    (self as any).postMessage(
      {
        type: 'DONE',
        buffer,
        fileName: fileName.endsWith('.mp4') ? fileName : `${fileName}.mp4`,
        sizeBytes: buffer.byteLength,
        resolution: `${encWidth}x${encHeight}`,
        duration,
        renderTime: Math.round(totalElapsedSec * 10) / 10,
        avgFps: Math.round(avgFps * 10) / 10,
        sourceFps,
        codec: chosenConfig.codec,
        acceleration: chosenConfig.hardwareAcceleration || performanceMode,
        pipeline: 'WebCodecs Decoder (Worker)',
      },
      [buffer]
    );
  } catch (err: any) {
    console.error('[Worker Export Fatal Error]', err);
    self.postMessage({
      type: 'ERROR',
      error: err?.message || 'Lỗi không xác định trong Web Worker',
      canFallbackToMain: true,
    });
  }
};
