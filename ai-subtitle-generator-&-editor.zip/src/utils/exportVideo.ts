import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
import { createFile, DataStream, MP4Info, MP4Sample, MP4MediaTrack, MP4File } from 'mp4box';
import { SubtitleCue, SubtitleStyleConfig, DEFAULT_SUBTITLE_STYLE } from '../types';
import { SubtitleCursor, renderSubtitleOnCanvas, getFontFamilyDefinitions } from './subtitleRendererCore';

export interface ExportProgressStats {
  percent: number;
  message: string;
  currentFrame: number;
  totalFrames: number;
  fps: number;
  sourceFps: number;
  elapsedSeconds: number;
  etaSeconds: number | null;
  codec: string;
  acceleration: string;
  pipeline: 'WebCodecs Decoder (Worker)' | 'WebCodecs Decoder (Direct)' | 'Frame-Stepped Fallback';
  encodeQueueSize: number;
}

export interface ExportResult {
  success: boolean;
  fileName: string;
  sizeBytes: number;
  resolution: string;
  duration: number;
  downloadUrl: string;
  renderTime: number; // in seconds
  avgFps: number;
  sourceFps: number;
  codec: string;
  acceleration: string;
  pipeline: string;
}

interface DemuxedTrackInfo {
  track: MP4MediaTrack;
  description?: Uint8Array;
  fps: number;
  durationSeconds: number;
  samples: MP4Sample[];
}

/**
 * Snaps raw floating FPS calculation to standard broadcast/cinema framerates
 */
function normalizeFramerate(rawFps: number): number {
  if (!rawFps || isNaN(rawFps) || rawFps <= 0) return 30;

  const standardRates = [
    { target: 23.976, exact: 24000 / 1001 },
    { target: 24, exact: 24 },
    { target: 25, exact: 25 },
    { target: 29.97, exact: 30000 / 1001 },
    { target: 30, exact: 30 },
    { target: 48, exact: 48 },
    { target: 50, exact: 50 },
    { target: 59.94, exact: 60000 / 1001 },
    { target: 60, exact: 60 },
  ];

  for (const { target, exact } of standardRates) {
    if (Math.abs(rawFps - target) < 0.15 || Math.abs(rawFps - exact) < 0.15) {
      return target;
    }
  }

  return Math.min(120, Math.max(1, Math.round(rawFps * 1000) / 1000));
}

/**
 * Extracts extradata (avcC/hvcC/vpcC/av1C) description buffer from MP4Box track
 */
function getTrackExtradata(mp4boxFile: any, trackId: number): Uint8Array | undefined {
  try {
    const track = mp4boxFile.getTrackById(trackId);
    if (!track?.mdia?.minf?.stbl?.stsd?.entries) return undefined;

    for (const entry of track.mdia.minf.stbl.stsd.entries) {
      const box = entry.avcC || entry.hvcC || entry.vpcC || entry.av1C;
      if (box) {
        const stream = new DataStream(undefined, 0, DataStream.BIG_ENDIAN);
        box.write(stream);
        // The first 8 bytes are the box header (size + 4CC identifier), description starts at offset 8
        return new Uint8Array(stream.buffer, 8);
      }
    }
  } catch (err) {
    console.warn('[MP4Box] Failed to extract extradata box:', err);
  }
  return undefined;
}

/**
 * Demuxes an MP4 ArrayBuffer using mp4box.js to extract exact video track info, FPS, and samples
 */
async function demuxVideoFile(
  arrayBuffer: ArrayBuffer,
  onProgress?: (percent: number, msg: string) => void
): Promise<DemuxedTrackInfo> {
  return new Promise((resolve, reject) => {
    const mp4boxFile = createFile();
    let videoTrack: MP4MediaTrack | null = null;
    const collectedSamples: MP4Sample[] = [];

    mp4boxFile.onError = (err) => {
      reject(new Error(typeof err === 'string' ? err : 'MP4Box Demuxing failed'));
    };

    mp4boxFile.onReady = (info: MP4Info) => {
      if (!info.videoTracks || info.videoTracks.length === 0) {
        return reject(new Error('Không tìm thấy video track trong tệp nguồn'));
      }

      videoTrack = info.videoTracks[0];

      // Extract all samples for the video track
      mp4boxFile.setExtractionOptions(videoTrack.id, null, { nbSamples: 1000 });
      mp4boxFile.start();
    };

    mp4boxFile.onSamples = (trackId: number, _user: any, samples: MP4Sample[]) => {
      if (videoTrack && trackId === videoTrack.id) {
        collectedSamples.push(...samples);

        if (videoTrack.nb_samples > 0) {
          const demuxPercent = Math.min(18, 5 + Math.round((collectedSamples.length / videoTrack.nb_samples) * 13));
          onProgress?.(demuxPercent, `Đang phân tích khung hình gốc (${collectedSamples.length}/${videoTrack.nb_samples})...`);

          if (collectedSamples.length >= videoTrack.nb_samples) {
            finishDemux();
          }
        }
      }
    };

    const finishDemux = () => {
      if (!videoTrack) {
        return reject(new Error('Video track không tồn tại sau khi demux'));
      }

      const timescale = videoTrack.timescale || 1000;
      const durationSeconds = videoTrack.duration ? videoTrack.duration / timescale : 1;
      const sampleCount = collectedSamples.length || videoTrack.nb_samples || 1;

      let rawFps = 30;
      if (sampleCount > 0 && durationSeconds > 0) {
        rawFps = sampleCount / durationSeconds;
      }

      const realFps = normalizeFramerate(rawFps);
      const extradata = getTrackExtradata(mp4boxFile, videoTrack.id);

      resolve({
        track: videoTrack,
        description: extradata,
        fps: realFps,
        durationSeconds,
        samples: collectedSamples,
      });
    };

    try {
      (arrayBuffer as any).fileStart = 0;
      mp4boxFile.appendBuffer(arrayBuffer);
      mp4boxFile.flush();

      // Safety timeout for samples completion
      setTimeout(() => {
        if (videoTrack && collectedSamples.length > 0) {
          finishDemux();
        } else {
          reject(new Error('Timeout phân tích cấu trúc video (MP4Box)'));
        }
      }, 10000);
    } catch (e) {
      reject(e);
    }
  });
}

/**
 * Preloads selected custom subtitle font before any canvas rendering begins (B2)
 */
async function preloadSubtitleFont(style: SubtitleStyleConfig): Promise<void> {
  try {
    const fontDef = getFontFamilyDefinitions(style?.fontFamily);
    if (typeof document !== 'undefined' && document.fonts) {
      await document.fonts.load(`700 40px ${fontDef.canvas}`);
      await document.fonts.ready;
    }
  } catch (err) {
    console.warn('[Font Preload] Warning preloading subtitle font:', err);
  }
}

/**
 * Web Worker Export Pipeline (Off-main-thread processing for zero UI lag)
 */
async function exportDubbedVideoWorker({
  videoUrl,
  dubbedAudioUrl,
  subtitles = [],
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
  fileName = 'video_dubbed.mp4',
  performanceMode = 'prefer-hardware',
  onProgress,
  onStats,
}: {
  videoUrl: string;
  dubbedAudioUrl?: string | null;
  subtitles?: SubtitleCue[];
  subtitleStyle?: SubtitleStyleConfig;
  fileName?: string;
  performanceMode?: 'prefer-software' | 'no-preference' | 'prefer-hardware';
  onProgress?: (progress: number, msg: string) => void;
  onStats?: (stats: ExportProgressStats) => void;
}): Promise<ExportResult> {
  if (typeof Worker === 'undefined' || typeof OffscreenCanvas === 'undefined') {
    throw new Error('Web Worker hoặc OffscreenCanvas không được hỗ trợ');
  }

  // Preload subtitle font to guarantee crisp canvas text
  await preloadSubtitleFont(subtitleStyle);

  // Fetch video arrayBuffer
  onProgress?.(4, 'Đang nạp dữ liệu video vào Web Worker...');
  const res = await fetch(videoUrl);
  if (!res.ok) throw new Error(`Không thể nạp tệp video (${res.status})`);
  const videoArrayBuffer = await res.arrayBuffer();

  // Decode audio data on main thread if provided and prepare channel arrays
  let audioDataPayload: {
    channelData: Float32Array[];
    sampleRate: number;
    numberOfChannels: number;
    length: number;
  } | null = null;

  if (dubbedAudioUrl) {
    onProgress?.(10, 'Đang giải mã âm thanh lồng tiếng...');
    try {
      const aRes = await fetch(dubbedAudioUrl);
      const aBuf = await aRes.arrayBuffer();
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const aCtx = new AudioCtxClass({ sampleRate: 48000 });
      if (aCtx.state === 'suspended') await aCtx.resume();
      const decoded = await aCtx.decodeAudioData(aBuf);
      const numChannels = Math.min(2, decoded.numberOfChannels);
      const channelData: Float32Array[] = [];
      for (let c = 0; c < numChannels; c++) {
        channelData.push(decoded.getChannelData(c));
      }
      audioDataPayload = {
        channelData,
        sampleRate: decoded.sampleRate,
        numberOfChannels: numChannels,
        length: decoded.length,
      };
      try {
        await aCtx.close();
      } catch {
        // ignore
      }
    } catch (aErr) {
      console.warn('[Export Worker] Failed to pre-decode audio for worker:', aErr);
    }
  }

  const worker = new Worker(new URL('./export.worker.ts', import.meta.url), { type: 'module' });

  return new Promise<ExportResult>((resolve, reject) => {
    let isSettled = false;
    let lastActivityTime = Date.now();

    const cleanup = () => {
      isSettled = true;
      clearInterval(watchdogInterval);
      try {
        worker.terminate();
      } catch {
        // ignore
      }
    };

    const watchdogInterval = setInterval(() => {
      if (isSettled) {
        clearInterval(watchdogInterval);
        return;
      }
      if (Date.now() - lastActivityTime > 40000) {
        cleanup();
        reject(new Error('Web Worker không phản hồi, tự động chuyển sang chế độ kết xuất trực tiếp'));
      }
    }, 5000);

    worker.onmessage = (e: MessageEvent) => {
      if (isSettled) return;
      lastActivityTime = Date.now();
      const data = e.data;
      if (!data) return;

      if (data.type === 'PROGRESS') {
        onProgress?.(data.percent, data.message);
      } else if (data.type === 'STATS') {
        onStats?.(data.stats);
      } else if (data.type === 'DONE') {
        const finalBlob = new Blob([data.buffer], { type: 'video/mp4' });
        const downloadUrl = URL.createObjectURL(finalBlob);
        onProgress?.(100, `Xuất video MP4 thành công (${data.renderTime}s, ${data.avgFps} FPS, ${data.sourceFps} FPS gốc)!`);
        cleanup();
        resolve({
          success: true,
          fileName: data.fileName,
          sizeBytes: data.sizeBytes,
          resolution: data.resolution,
          duration: data.duration,
          downloadUrl,
          renderTime: data.renderTime,
          avgFps: data.avgFps,
          sourceFps: data.sourceFps,
          codec: data.codec,
          acceleration: data.acceleration,
          pipeline: data.pipeline,
        });
      } else if (data.type === 'ERROR') {
        cleanup();
        reject(new Error(data.error || 'Worker export error'));
      }
    };

    worker.onerror = (err) => {
      if (isSettled) return;
      cleanup();
      reject(new Error(err?.message || 'Lỗi trong luồng Web Worker'));
    };

    // Transfer videoArrayBuffer
    worker.postMessage(
      {
        type: 'START',
        videoArrayBuffer,
        audioData: audioDataPayload,
        subtitles,
        subtitleStyle,
        fileName,
        performanceMode,
      },
      [videoArrayBuffer]
    );
  });
}

/**
 * Main Thread Export Pipeline (Fallback when Web Worker / OffscreenCanvas is unavailable)
 */
async function exportDubbedVideoMainThread({
  videoUrl,
  dubbedAudioUrl,
  subtitles = [],
  subtitleStyle = DEFAULT_SUBTITLE_STYLE,
  fileName = 'video_dubbed.mp4',
  performanceMode = 'prefer-hardware',
  onProgress,
  onStats,
}: {
  videoUrl: string;
  dubbedAudioUrl?: string | null;
  subtitles?: SubtitleCue[];
  subtitleStyle?: SubtitleStyleConfig;
  fileName?: string;
  performanceMode?: 'prefer-software' | 'no-preference' | 'prefer-hardware';
  onProgress?: (progress: number, msg: string) => void;
  onStats?: (stats: ExportProgressStats) => void;
}): Promise<ExportResult> {
  const startTime = performance.now();
  onProgress?.(2, 'Đang chuẩn bị môi trường & nạp cấu hình phông chữ...');

  if (typeof window === 'undefined') {
    throw new Error('Môi trường trình duyệt không hợp lệ');
  }

  // 1. Preload subtitle font to guarantee crisp canvas text
  await preloadSubtitleFont(subtitleStyle);

  // 2. Fetch video source ArrayBuffer for MP4Box demuxing
  onProgress?.(5, 'Đang nạp dữ liệu video và giải nén metadata...');
  let videoArrayBuffer: ArrayBuffer | null = null;
  try {
    const res = await fetch(videoUrl);
    videoArrayBuffer = await res.arrayBuffer();
  } catch (err) {
    console.warn('[Export] Could not fetch video ArrayBuffer directly, will use DOM video element:', err);
  }

  // 3. Demux video file with MP4Box to get real FPS and sample track
  let demuxInfo: DemuxedTrackInfo | null = null;
  if (videoArrayBuffer) {
    try {
      demuxInfo = await demuxVideoFile(videoArrayBuffer.slice(0), (percent, msg) => {
        onProgress?.(percent, msg);
      });
    } catch (demuxErr) {
      console.warn('[Export] MP4Box demuxing warning, will fallback to HTMLVideoElement dimensions:', demuxErr);
    }
  }

  // 4. Create and load HTMLVideoElement for fallback / dimension confirmation
  const video = document.createElement('video');
  video.style.position = 'fixed';
  video.style.opacity = '0';
  video.style.pointerEvents = 'none';
  video.style.width = '1px';
  video.style.height = '1px';
  video.style.top = '-9999px';
  video.src = videoUrl;
  video.crossOrigin = 'anonymous';
  video.muted = true;
  video.playsInline = true;
  video.preload = 'auto';
  document.body.appendChild(video);

  try {
    await new Promise<void>((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        cleanup();
        reject(new Error('Hết thời gian tải video (Timeout 15s). Vui lòng thử lại.'));
      }, 15000);

      const onLoaded = () => {
        clearTimeout(timeoutId);
        cleanup();
        resolve();
      };
      const onError = () => {
        clearTimeout(timeoutId);
        cleanup();
        reject(new Error('Không thể tải dữ liệu video.'));
      };
      const cleanup = () => {
        video.removeEventListener('loadedmetadata', onLoaded);
        video.removeEventListener('error', onError);
      };

      if (video.readyState >= 1 && video.videoWidth > 0) {
        clearTimeout(timeoutId);
        resolve();
      } else {
        video.addEventListener('loadedmetadata', onLoaded);
        video.addEventListener('error', onError);
      }
    });

    const width = demuxInfo?.track.video?.width || video.videoWidth || 1280;
    const height = demuxInfo?.track.video?.height || video.videoHeight || 720;
    const duration = Math.max(0.1, demuxInfo?.durationSeconds || video.duration || 1);
    const sourceFps = demuxInfo?.fps ? demuxInfo.fps : 30;

    // Dimension must be even for H.264 video encoding
    const encWidth = width % 2 === 0 ? width : width - 1;
    const encHeight = height % 2 === 0 ? height : height - 1;

    // 5. Decode audio stream if provided
    let audioBuffer: AudioBuffer | null = null;
    let audioCtx: AudioContext | null = null;
    const targetAudioSource = dubbedAudioUrl || null;

    if (targetAudioSource) {
      onProgress?.(20, 'Đang giải mã luồng âm thanh lồng tiếng AAC...');
      try {
        const audioRes = await fetch(targetAudioSource);
        const audioArrayBuf = await audioRes.arrayBuffer();
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        audioCtx = new AudioCtxClass({ sampleRate: 48000 });
        if (audioCtx.state === 'suspended') {
          await audioCtx.resume();
        }
        audioBuffer = await audioCtx.decodeAudioData(audioArrayBuf);
      } catch (err) {
        console.warn('Không thể nạp dubbedAudioUrl:', err);
      }
    }

    // 6. Canvas for rendering
    const canvas = document.createElement('canvas');
    canvas.width = encWidth;
    canvas.height = encHeight;
    const ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
    if (!ctx) throw new Error('Không thể khởi tạo Canvas 2D');

    // 7. Configure MP4 Muxer with real FPS timescale
    const muxerOptions: any = {
      target: new ArrayBufferTarget(),
      video: {
        codec: 'avc',
        width: encWidth,
        height: encHeight,
      },
      fastStart: 'in-memory',
      firstTimestampBehavior: 'offset',
    };

    if (audioBuffer) {
      muxerOptions.audio = {
        codec: 'aac',
        numberOfChannels: Math.min(2, audioBuffer.numberOfChannels),
        sampleRate: audioBuffer.sampleRate,
      };
    }

    const muxer = new Muxer(muxerOptions);

    // 8. Select optimal VideoEncoder configuration with real detected FPS (A1)
    const targetBitrate =
      encWidth * encHeight > 1920 * 1080
        ? 8_000_000
        : encWidth * encHeight > 1280 * 720
        ? 4_500_000
        : 2_500_000;

    const candidateCodecs = [
      'avc1.640028', // High Profile Level 4.0
      'avc1.4D0020', // Main Profile Level 3.2
      'avc1.42E01E', // Baseline Profile Level 3.0
    ];

    let chosenConfig: VideoEncoderConfig | null = null;
    if ('VideoEncoder' in window) {
      for (const codec of candidateCodecs) {
        const config: VideoEncoderConfig = {
          codec,
          width: encWidth,
          height: encHeight,
          bitrate: targetBitrate,
          framerate: sourceFps,
          hardwareAcceleration: performanceMode,
        };
        try {
          const support = await VideoEncoder.isConfigSupported(config);
          if (support.supported && support.config) {
            chosenConfig = support.config;
            break;
          }
        } catch {
          // ignore
        }
      }
    }

    if (!chosenConfig) {
      chosenConfig = {
        codec: 'avc1.42E01E',
        width: encWidth,
        height: encHeight,
        bitrate: targetBitrate,
        framerate: sourceFps,
        hardwareAcceleration: performanceMode,
      };
    }

    onProgress?.(22, `Khởi tạo Bộ mã hóa phần cứng (${chosenConfig.codec} @ ${sourceFps} FPS)...`);

    let encoderError: Error | null = null;
    const videoEncoder = new VideoEncoder({
      output: (chunk, meta) => muxer.addVideoChunk(chunk, meta as any),
      error: (e) => {
        console.error('[WebCodecs VideoEncoder Error]', e);
        encoderError = new Error(`VideoEncoder: ${e.message}`);
      },
    });

    videoEncoder.configure(chosenConfig);

    // 9. Encode Audio Chunks into Muxer
    if (audioBuffer) {
      onProgress?.(24, 'Đang đóng gói luồng âm thanh AAC...');
      const audioEncoder = new AudioEncoder({
        output: (chunk, meta) => muxer.addAudioChunk(chunk, meta as any),
        error: (e) => console.error('[AudioEncoder Error]', e),
      });

      audioEncoder.configure({
        codec: 'mp4a.40.2',
        numberOfChannels: Math.min(2, audioBuffer.numberOfChannels),
        sampleRate: audioBuffer.sampleRate,
        bitrate: 160_000,
      });

      const sampleRate = audioBuffer.sampleRate;
      const numChannels = Math.min(2, audioBuffer.numberOfChannels);
      const audioLen = audioBuffer.length;
      const framesPerChunk = Math.round(sampleRate * 0.5); // 500ms chunks

      for (let offset = 0; offset < audioLen; offset += framesPerChunk) {
        const frameCount = Math.min(framesPerChunk, audioLen - offset);
        const planarData = new Float32Array(frameCount * numChannels);

        for (let c = 0; c < numChannels; c++) {
          const channelData = audioBuffer.getChannelData(c);
          planarData.set(channelData.subarray(offset, offset + frameCount), c * frameCount);
        }

        const audioData = new AudioData({
          format: 'f32-planar',
          sampleRate,
          numberOfFrames: frameCount,
          numberOfChannels: numChannels,
          timestamp: Math.round((offset / sampleRate) * 1e6),
          data: planarData,
        });

        audioEncoder.encode(audioData);
        audioData.close();
      }

      await audioEncoder.flush();
      audioEncoder.close();
    }

    // 10. Execution: Try Direct WebCodecs Demux → VideoDecoder Pipeline (A2)
    const subtitleCursor = new SubtitleCursor(subtitles);
    let pipelineUsed: 'WebCodecs Decoder (Direct)' | 'Frame-Stepped Fallback' = 'WebCodecs Decoder (Direct)';
    let encodedFrames = 0;
    const totalFrames = demuxInfo?.samples?.length || Math.max(1, Math.ceil(duration * sourceFps));

    // Check if VideoDecoder can be used with demuxed samples
    let canUseDirectDecoder = false;
    let decoderCodec = demuxInfo?.track.codec || 'avc1.42E01E';

    if (
      'VideoDecoder' in window &&
      demuxInfo &&
      demuxInfo.samples.length > 0 &&
      demuxInfo.description
    ) {
      const testDecoderConfig: VideoDecoderConfig = {
        codec: decoderCodec,
        codedWidth: encWidth,
        codedHeight: encHeight,
        description: demuxInfo.description,
        hardwareAcceleration: performanceMode,
      };

      try {
        const decSupport = await VideoDecoder.isConfigSupported(testDecoderConfig);
        if (decSupport.supported) {
          canUseDirectDecoder = true;
        }
      } catch (decErr) {
        console.warn('[VideoDecoder] isConfigSupported check failed:', decErr);
      }
    }

    if (canUseDirectDecoder && demuxInfo && demuxInfo.samples.length > 0) {
      // --- DIRECT PIPELINE: VideoDecoder -> Canvas -> VideoEncoder ---
      onProgress?.(28, `Bắt đầu giải mã phần cứng trực tiếp (${demuxInfo.samples.length} khung hình @ ${sourceFps} FPS)...`);

      let decoderError: Error | null = null;
      let frameIndex = 0;

      const videoDecoder = new VideoDecoder({
        output: (decodedFrame: VideoFrame) => {
          try {
            if (encoderError) throw encoderError;

            // 1. Draw decoded frame directly to canvas
            ctx.drawImage(decodedFrame, 0, 0, encWidth, encHeight);

            // 2. Render burned subtitle cue
            const mediaTimeSec = (decodedFrame.timestamp || 0) / 1e6;
            const activeCue = subtitleCursor.getActiveCue(mediaTimeSec);
            const textToRender = activeCue?.text_translated || activeCue?.text_original;

            if (activeCue && textToRender) {
              renderSubtitleOnCanvas(
                ctx,
                canvas,
                textToRender,
                subtitleStyle,
                encWidth,
                encHeight,
                activeCue.box
              );
            }

            // 3. Create new VideoFrame from canvas and encode with original timestamp
            const isKeyFrame = frameIndex % Math.round(sourceFps * 2) === 0;
            const outFrame = new VideoFrame(canvas, {
              timestamp: decodedFrame.timestamp,
              duration: decodedFrame.duration || Math.round((1 / sourceFps) * 1e6),
            });

            videoEncoder.encode(outFrame, { keyFrame: isKeyFrame });

            // Close frames immediately to guarantee zero memory leaks
            outFrame.close();
            decodedFrame.close();

            encodedFrames++;
            frameIndex++;

            // Update stats
            const elapsedSec = (performance.now() - startTime) / 1000;
            const currentFps = encodedFrames / Math.max(0.1, elapsedSec);
            const progressPercent = Math.min(98, Math.round(28 + (encodedFrames / totalFrames) * 70));
            const remainingFrames = Math.max(0, totalFrames - encodedFrames);
            const etaSec = currentFps > 0 ? remainingFrames / currentFps : null;

            if (encodedFrames % 10 === 0 || encodedFrames === totalFrames) {
              onProgress?.(
                progressPercent,
                `Giải mã & kết xuất: ${encodedFrames}/${totalFrames} (${Math.round(currentFps)} FPS, ${Math.round(mediaTimeSec)}s / ${Math.round(duration)}s)`
              );

              onStats?.({
                percent: progressPercent,
                message: `Khung hình ${encodedFrames}/${totalFrames}`,
                currentFrame: encodedFrames,
                totalFrames,
                fps: Math.round(currentFps * 10) / 10,
                sourceFps,
                elapsedSeconds: Math.round(elapsedSec),
                etaSeconds: etaSec ? Math.round(etaSec) : null,
                codec: chosenConfig.codec,
                acceleration: chosenConfig.hardwareAcceleration || performanceMode,
                pipeline: 'WebCodecs Decoder (Direct)',
                encodeQueueSize: videoEncoder.encodeQueueSize,
              });
            }
          } catch (renderErr: any) {
            decoderError = renderErr;
            decodedFrame.close();
          }
        },
        error: (e) => {
          console.error('[VideoDecoder Error]', e);
          decoderError = new Error(`VideoDecoder error: ${e.message}`);
        },
      });

      videoDecoder.configure({
        codec: decoderCodec,
        codedWidth: encWidth,
        codedHeight: encHeight,
        description: demuxInfo.description,
        hardwareAcceleration: performanceMode,
      });

      // Feed demuxed chunks with backpressure protection
      for (const sample of demuxInfo.samples) {
        if (decoderError) throw decoderError;
        if (encoderError) throw encoderError;

        // Drain queues if backpressure builds up
        while (videoDecoder.decodeQueueSize > 8 || videoEncoder.encodeQueueSize > 8) {
          await new Promise((r) => setTimeout(r, 8));
        }

        const timescale = sample.timescale || demuxInfo.track.timescale || 1000;
        const timestampMicroseconds = Math.round((sample.cts * 1_000_000) / timescale);
        const durationMicroseconds = Math.round((sample.duration * 1_000_000) / timescale);

        const chunk = new EncodedVideoChunk({
          type: sample.is_sync ? 'key' : 'delta',
          timestamp: timestampMicroseconds,
          duration: durationMicroseconds,
          data: sample.data,
        });

        videoDecoder.decode(chunk);
      }

      await videoDecoder.flush();
      videoDecoder.close();

    } else {
      // --- FALLBACK PIPELINE: Frame-Stepped Seek Engine (A2 point 5) ---
      pipelineUsed = 'Frame-Stepped Fallback';
      console.warn('[Export Pipeline] Falling back to frame-stepped seek mode (VideoDecoder unsupported for this source/browser).');
      onProgress?.(28, `Đang kết xuất khung hình qua chế độ dự phòng (${totalFrames} frames @ ${sourceFps} FPS)...`);

      const drainQueueIfNeeded = async () => {
        if (videoEncoder.encodeQueueSize > 6) {
          let waitCount = 0;
          while (videoEncoder.encodeQueueSize > 2 && waitCount < 20) {
            await new Promise((r) => setTimeout(r, 10));
            waitCount++;
          }
        }
      };

      for (let frameIdx = 0; frameIdx < totalFrames; frameIdx++) {
        if (encoderError) throw encoderError;

        const mediaTime = Math.min(duration, frameIdx / sourceFps);

        // Seek video to exact frame timestamp with timeout safety
        await new Promise<void>((resolve) => {
          let done = false;
          const timer = setTimeout(() => {
            if (!done) {
              done = true;
              resolve();
            }
          }, 120);

          const onSeeked = () => {
            if (!done) {
              done = true;
              clearTimeout(timer);
              video.removeEventListener('seeked', onSeeked);
              resolve();
            }
          };

          video.addEventListener('seeked', onSeeked, { once: true });
          video.currentTime = mediaTime;
        });

        // 1. Draw source video frame
        ctx.drawImage(video, 0, 0, encWidth, encHeight);

        // 2. Render burned subtitle
        const activeCue = subtitleCursor.getActiveCue(mediaTime);
        const textToRender = activeCue?.text_translated || activeCue?.text_original;
        if (activeCue && textToRender) {
          renderSubtitleOnCanvas(
            ctx,
            video,
            textToRender,
            subtitleStyle,
            encWidth,
            encHeight,
            activeCue.box
          );
        }

        // 3. Create VideoFrame and encode
        const timestampMicroseconds = Math.round(mediaTime * 1e6);
        const frame = new VideoFrame(canvas, { timestamp: timestampMicroseconds });
        const isKeyFrame = frameIdx % Math.round(sourceFps * 2) === 0;

        videoEncoder.encode(frame, { keyFrame: isKeyFrame });
        frame.close();
        encodedFrames++;

        await drainQueueIfNeeded();

        // Progress & stats update
        const elapsedSec = (performance.now() - startTime) / 1000;
        const currentFps = encodedFrames / Math.max(0.1, elapsedSec);
        const progressPercent = Math.min(98, Math.round(28 + (frameIdx / totalFrames) * 70));
        const remainingFrames = Math.max(0, totalFrames - encodedFrames);
        const etaSec = currentFps > 0 ? remainingFrames / currentFps : null;

        if (frameIdx % 5 === 0 || frameIdx === totalFrames - 1) {
          onProgress?.(
            progressPercent,
            `Đang xử lý khung hình ${encodedFrames}/${totalFrames} (${Math.round(currentFps)} FPS, ${Math.round(mediaTime)}s / ${Math.round(duration)}s)`
          );

          onStats?.({
            percent: progressPercent,
            message: `Khung hình ${encodedFrames}/${totalFrames}`,
            currentFrame: encodedFrames,
            totalFrames,
            fps: Math.round(currentFps * 10) / 10,
            sourceFps,
            elapsedSeconds: Math.round(elapsedSec),
            etaSeconds: etaSec ? Math.round(etaSec) : null,
            codec: chosenConfig.codec,
            acceleration: chosenConfig.hardwareAcceleration || performanceMode,
            pipeline: 'Frame-Stepped Fallback',
            encodeQueueSize: videoEncoder.encodeQueueSize,
          });
        }
      }
    }

    // 11. Flush and finalize Muxer
    onProgress?.(99, 'Đang hoàn tất đóng gói file MP4 chất lượng cao...');
    await videoEncoder.flush();
    videoEncoder.close();
    muxer.finalize();

    const { buffer } = muxer.target as ArrayBufferTarget;
    const finalBlob = new Blob([buffer], { type: 'video/mp4' });
    const downloadUrl = URL.createObjectURL(finalBlob);

    const totalElapsedSec = (performance.now() - startTime) / 1000;
    const avgFps = encodedFrames / Math.max(0.1, totalElapsedSec);

    // 12. Cleanup
    if (audioCtx && audioCtx.state !== 'closed') {
      try {
        audioCtx.close();
      } catch {
        // ignore
      }
    }

    onProgress?.(100, `Xuất video MP4 thành công (${Math.round(totalElapsedSec)}s, ${Math.round(avgFps)} FPS, ${sourceFps} FPS gốc)!`);

    return {
      success: true,
      fileName: fileName.endsWith('.mp4') ? fileName : `${fileName}.mp4`,
      sizeBytes: finalBlob.size,
      resolution: `${encWidth}x${encHeight}`,
      duration,
      downloadUrl,
      renderTime: Math.round(totalElapsedSec * 10) / 10,
      avgFps: Math.round(avgFps * 10) / 10,
      sourceFps,
      codec: chosenConfig.codec,
      acceleration: chosenConfig.hardwareAcceleration || performanceMode,
      pipeline: pipelineUsed,
    };
  } finally {
    if (document.body.contains(video)) {
      document.body.removeChild(video);
    }
  }
}

/**
 * High-performance, zero-freeze Video MP4 export engine.
 * Automatically delegates decoding & encoding to a background Web Worker (OffscreenCanvas)
 * to keep UI 100% smooth and lag-free during export, with automated fallback to Main Thread.
 */
export async function exportDubbedVideo(options: {
  videoUrl: string;
  dubbedAudioUrl?: string | null;
  subtitles?: SubtitleCue[];
  subtitleStyle?: SubtitleStyleConfig;
  fileName?: string;
  performanceMode?: 'prefer-software' | 'no-preference' | 'prefer-hardware';
  onProgress?: (progress: number, msg: string) => void;
  onStats?: (stats: ExportProgressStats) => void;
}): Promise<ExportResult> {
  try {
    // 1. Try Web Worker pipeline first (Off-main-thread processing)
    return await exportDubbedVideoWorker(options);
  } catch (workerErr: any) {
    console.warn('[Export Pipeline] Web Worker export error or not supported, falling back to Main Thread pipeline:', workerErr);
    options.onProgress?.(5, 'Đang chuyển sang chế độ kết xuất trực tiếp...');
    return await exportDubbedVideoMainThread(options);
  }
}

/**
 * Instant, rock-solid direct file download utility.
 * Guarantees cross-browser and iframe download execution.
 */
export async function directDownloadFile(url: string, suggestedName: string): Promise<void> {
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', suggestedName);
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();

  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
  }, 1000);
}
