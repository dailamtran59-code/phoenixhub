import { SubtitleCue, SubtitleMode } from '../types';

/**
 * Converts seconds (e.g. 125.45) to SRT timestamp format "00:02:05,450"
 */
export function secondsToSrtTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) seconds = 0;
  
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  const millis = Math.floor((seconds % 1) * 1000);

  const pad = (num: number, size = 2) => String(num).padStart(size, '0');

  return `${pad(hours)}:${pad(minutes)}:${pad(secs)},${pad(millis, 3)}`;
}

/**
 * Parses SRT timestamp format "00:02:05,450" or "00:02:05.450" into seconds
 */
export function srtTimeToSeconds(srtTime: string): number {
  if (!srtTime) return 0;
  const clean = srtTime.trim().replace('.', ',');
  const parts = clean.split(':');
  if (parts.length !== 3) return 0;

  const hours = parseFloat(parts[0]);
  const minutes = parseFloat(parts[1]);
  const secParts = parts[2].split(',');
  const seconds = parseFloat(secParts[0]);
  const millis = secParts[1] ? parseFloat(secParts[1]) : 0;

  return hours * 3600 + minutes * 60 + seconds + millis / 1000;
}

/**
 * Splits text into lines respecting max characters per line (default 42)
 * and max lines per cue (default 2)
 */
export function formatSubtitleText(text: string, maxCharsPerLine = 42, maxLines = 2): string {
  if (!text) return '';
  const words = text.split(' ');
  const lines: string[] = [];
  let currentLine = '';

  for (const word of words) {
    if ((currentLine + (currentLine ? ' ' : '') + word).length <= maxCharsPerLine) {
      currentLine += (currentLine ? ' ' : '') + word;
    } else {
      if (currentLine) lines.push(currentLine);
      currentLine = word;
    }
  }
  if (currentLine) lines.push(currentLine);

  // Limit to maxLines if needed, joining extra lines
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines - 1);
    const rest = lines.slice(maxLines - 1).join(' ');
    kept.push(rest);
    return kept.join('\n');
  }

  return lines.join('\n');
}

/**
 * Sanitizes and validates subtitle cues programmatically:
 * 1. Fixes invalid/inverted timestamps (start >= end)
 * 2. Splits wall-of-text cues (> 80 chars or multi-sentences) into standard sub-cues
 * 3. Sorts cues chronologically
 * 4. Ensures SRT time strings match seconds exactly
 */
export function sanitizeAndValidateCues(cues: SubtitleCue[], maxChars = 42): SubtitleCue[] {
  if (!cues || cues.length === 0) return [];

  const sanitized: SubtitleCue[] = [];

  for (const rawCue of cues) {
    let startSec = typeof rawCue.startSeconds === 'number' && !isNaN(rawCue.startSeconds)
      ? rawCue.startSeconds
      : srtTimeToSeconds(rawCue.start);

    let endSec = typeof rawCue.endSeconds === 'number' && !isNaN(rawCue.endSeconds)
      ? rawCue.endSeconds
      : srtTimeToSeconds(rawCue.end);

    // Fix negative start times
    if (startSec < 0) startSec = 0;

    const origText = (rawCue.text_original || '').trim();
    const transText = (rawCue.text_translated || '').trim();
    const primaryText = transText || origText;

    // Fix inverted or zero duration timestamps (e.g. start > end)
    if (endSec <= startSec) {
      const charCount = Math.max(origText.length, transText.length, 10);
      const estDuration = Math.max(1.8, Math.min(8.0, charCount / 16));
      endSec = startSec + estDuration;
    }

    // Check if cue is a giant wall of text that needs auto-splitting
    if (primaryText.length > 80 || (origText.length > 80)) {
      // Split by sentences or punctuation
      const sentences = primaryText
        .split(/(?<=[.!?])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);

      const origSentences = origText
        .split(/(?<=[.!?])\s+/)
        .map((s) => s.trim())
        .filter(Boolean);

      if (sentences.length > 1) {
        const totalDuration = endSec - startSec;
        const count = sentences.length;
        const segmentDuration = totalDuration / count;

        for (let i = 0; i < count; i++) {
          const subStart = startSec + i * segmentDuration;
          const subEnd = subStart + segmentDuration;
          const subOrig = origSentences[i] || origText;
          const subTrans = sentences[i];

          sanitized.push({
            id: Date.now() + Math.random() * 10000,
            startSeconds: Number(subStart.toFixed(3)),
            endSeconds: Number(subEnd.toFixed(3)),
            start: secondsToSrtTime(subStart),
            end: secondsToSrtTime(subEnd),
            speaker: rawCue.speaker,
            text_original: formatSubtitleText(subOrig, maxChars, 2),
            text_translated: formatSubtitleText(subTrans, maxChars, 2),
          });
        }
        continue;
      }
    }

    // Normal cue formatting
    sanitized.push({
      ...rawCue,
      id: rawCue.id || Date.now() + Math.random() * 1000,
      startSeconds: Number(startSec.toFixed(3)),
      endSeconds: Number(endSec.toFixed(3)),
      start: secondsToSrtTime(startSec),
      end: secondsToSrtTime(endSec),
      text_original: formatSubtitleText(origText, maxChars, 2),
      text_translated: formatSubtitleText(transText, maxChars, 2),
    });
  }

  // Sort chronologically by start time
  sanitized.sort((a, b) => a.startSeconds - b.startSeconds);

  return sanitized;
}

/**
 * Generates valid SRT string from array of SubtitleCues according to selected mode.
 * Mode 'original': only original text
 * Mode 'translated': only translated text
 * Mode 'bilingual': line 1 original, line 2 translated
 */
export function buildSrtContent(cues: SubtitleCue[], mode: SubtitleMode, showSpeaker = true): string {
  if (!cues || cues.length === 0) return '';

  return cues.map((cue, index) => {
    const cueIndex = index + 1;
    const startStr = cue.start.includes(',') ? cue.start : secondsToSrtTime(cue.startSeconds);
    const endStr = cue.end.includes(',') ? cue.end : secondsToSrtTime(cue.endSeconds);

    let textStr = '';
    const speakerPrefix = (showSpeaker && cue.speaker && cue.speaker.trim()) ? `[${cue.speaker.trim()}]: ` : '';

    if (mode === 'original') {
      textStr = speakerPrefix + (cue.text_original || '');
    } else if (mode === 'translated') {
      textStr = speakerPrefix + (cue.text_translated || cue.text_original || '');
    } else if (mode === 'bilingual') {
      const orig = cue.text_original || '';
      const trans = cue.text_translated || '';
      if (speakerPrefix) {
        textStr = `${speakerPrefix}${orig}\n${trans}`;
      } else {
        textStr = `${orig}\n${trans}`;
      }
    }

    return `${cueIndex}\n${startStr} --> ${endStr}\n${textStr}\n`;
  }).join('\n');
}

/**
 * Generates TXT transcript content
 */
export function buildTxtContent(cues: SubtitleCue[], mode: SubtitleMode, showSpeaker = true): string {
  if (!cues || cues.length === 0) return '';

  return cues.map((cue) => {
    const timestampStr = `[${secondsToSrtTime(cue.startSeconds).split(',')[0]} - ${secondsToSrtTime(cue.endSeconds).split(',')[0]}]`;
    const speakerStr = (showSpeaker && cue.speaker) ? `[${cue.speaker}] ` : '';

    if (mode === 'original') {
      return `${timestampStr} ${speakerStr}${cue.text_original}`;
    } else if (mode === 'translated') {
      return `${timestampStr} ${speakerStr}${cue.text_translated || cue.text_original}`;
    } else {
      return `${timestampStr} ${speakerStr}${cue.text_original}\n  -> ${cue.text_translated}`;
    }
  }).join('\n\n');
}

/**
 * Downloads a file with UTF-8 BOM encoding for complete compatibility with video editing software (Premiere Pro, CapCut, DaVinci Resolve)
 */
export function downloadFileWithBOM(content: string, filename: string, mimeType = 'text/plain;charset=utf-8') {
  // UTF-8 Byte Order Mark (BOM): 0xEF, 0xBB, 0xBF
  const bom = new Uint8Array([0xEF, 0xBB, 0xBF]);
  const blob = new Blob([bom, content], { type: mimeType });
  const url = URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  link.style.display = 'none';
  document.body.appendChild(link);
  link.click();

  setTimeout(() => {
    if (document.body.contains(link)) {
      document.body.removeChild(link);
    }
    URL.revokeObjectURL(url);
  }, 10000);
}

/**
 * Sorts and recalculates cue timestamps or offsets
 */
export function adjustCueTimestamps(cues: SubtitleCue[], offsetSeconds: number): SubtitleCue[] {
  return cues.map((cue) => {
    const newStartSec = Math.max(0, cue.startSeconds + offsetSeconds);
    const newEndSec = Math.max(newStartSec + 0.5, cue.endSeconds + offsetSeconds);

    return {
      ...cue,
      startSeconds: newStartSec,
      endSeconds: newEndSec,
      start: secondsToSrtTime(newStartSec),
      end: secondsToSrtTime(newEndSec),
    };
  });
}

/**
 * Auto Smooth & Align Subtitles:
 * 1. Ensures every cue has enough reading duration based on word/character count (min 1.6s).
 * 2. Connects consecutive cues with small gaps (<= 0.8s) so subtitles don't flicker off/on unnaturally.
 */
export function autoSmoothSubtitlePacing(
  cues: SubtitleCue[],
  minDurationBase = 1.6,
  maxGapFillSec = 0.8
): SubtitleCue[] {
  if (!cues || cues.length === 0) return [];

  // Sort chronologically
  const sorted = [...cues].sort((a, b) => a.startSeconds - b.startSeconds);

  for (let i = 0; i < sorted.length; i++) {
    const cue = sorted[i];
    const text = cue.text_translated || cue.text_original || '';
    const charCount = text.length;
    // Estimate comfortable reading duration: ~1.6s base + 40ms per char
    const minDur = Math.max(minDurationBase, Math.min(6.0, 1.6 + charCount * 0.04));

    let endSec = cue.endSeconds;
    if (endSec - cue.startSeconds < minDur) {
      endSec = cue.startSeconds + minDur;
    }

    const nextCue = sorted[i + 1];
    if (nextCue) {
      // If gap to next cue is smaller than maxGapFillSec, extend endSec to meet nextCue.startSeconds
      const gap = nextCue.startSeconds - endSec;
      if (gap > 0 && gap <= maxGapFillSec) {
        endSec = nextCue.startSeconds;
      } else if (endSec > nextCue.startSeconds - 0.1) {
        // If endSec overlaps into nextCue, trim endSec to avoid overlap
        endSec = Math.max(cue.startSeconds + 0.5, nextCue.startSeconds - 0.05);
      }
    }

    cue.endSeconds = Number(endSec.toFixed(3));
    cue.end = secondsToSrtTime(cue.endSeconds);
  }

  return sorted;
}
