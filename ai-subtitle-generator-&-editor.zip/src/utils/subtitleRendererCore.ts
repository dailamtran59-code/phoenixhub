import React from 'react';
import { SubtitleCue, SubtitleStyleConfig } from '../types';

export interface WrappedLine {
  text: string;
  width: number;
}

export interface ComputedSubtitleLayout {
  lines: string[];
  fontSize: number;
  lineHeight: number;
  totalWidth: number;
  totalHeight: number;
  paddingX: number;
  paddingY: number;
  boxX: number;
  boxY: number;
  boxWidth: number;
  boxHeight: number;
  fontFamilyCss: string;
  fontFamilyCanvas: string;
  scaleRatio: number;
  strokeWidth: number;
}

/**
 * Maps font family identifiers to clean typography stacks
 */
export function getFontFamilyDefinitions(fontFamily: string | undefined): { css: string; canvas: string } {
  switch (fontFamily) {
    case 'serif':
      return {
        css: "'Playfair Display', Georgia, Cambria, serif",
        canvas: "'Playfair Display', Georgia, Cambria, serif",
      };
    case 'mono':
      return {
        css: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', monospace",
        canvas: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace",
      };
    case 'impact':
      return {
        css: "Impact, 'Arial Black', -apple-system, BlinkMacSystemFont, sans-serif",
        canvas: "Impact, 'Arial Black', sans-serif",
      };
    case 'montserrat':
      return {
        css: "Montserrat, 'Helvetica Neue', -apple-system, BlinkMacSystemFont, sans-serif",
        canvas: "Montserrat, 'Helvetica Neue', sans-serif",
      };
    case 'space':
      return {
        css: "'Space Grotesk', -apple-system, BlinkMacSystemFont, sans-serif",
        canvas: "'Space Grotesk', sans-serif",
      };
    case 'sans':
    default:
      return {
        css: "'Plus Jakarta Sans', ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
        canvas: "'Plus Jakarta Sans', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      };
  }
}

/**
 * Strips speaker tags like "[SPEAKER 1]:" from text
 */
export function stripSpeakerPrefix(text: string | undefined | null): string {
  if (!text) return '';
  return text
    .replace(/^\[SPEAKER\s*\d+\]\s*:?/i, '')
    .replace(/^SPEAKER\s*\d+\s*:\s*/i, '')
    .replace(/\[SPEAKER\s*\d+\]/gi, '')
    .trim();
}

/**
 * Amortized O(1) Subtitle Cursor for high-speed sequential frame rendering
 */
export class SubtitleCursor {
  private cues: SubtitleCue[];
  private currentIndex: number = 0;

  constructor(cues: SubtitleCue[] = []) {
    // Ensure cues are sorted chronologically
    this.cues = [...cues].sort((a, b) => (a.startSeconds || 0) - (b.startSeconds || 0));
  }

  public getActiveCue(timeSec: number): SubtitleCue | null {
    if (this.cues.length === 0) return null;

    // Fast check current index
    const current = this.cues[this.currentIndex];
    if (current && timeSec >= current.startSeconds && timeSec <= current.endSeconds) {
      return current;
    }

    // If time moved forward, advance index
    if (current && timeSec > current.endSeconds) {
      while (
        this.currentIndex < this.cues.length - 1 &&
        timeSec > this.cues[this.currentIndex].endSeconds
      ) {
        this.currentIndex++;
      }
      const candidate = this.cues[this.currentIndex];
      if (candidate && timeSec >= candidate.startSeconds && timeSec <= candidate.endSeconds) {
        return candidate;
      }
    }

    // If time jumped backwards (e.g. seeking or loop), binary search or scan
    if (current && timeSec < current.startSeconds) {
      this.currentIndex = 0;
      while (
        this.currentIndex < this.cues.length &&
        timeSec > this.cues[this.currentIndex].endSeconds
      ) {
        this.currentIndex++;
      }
      const candidate = this.cues[this.currentIndex];
      if (candidate && timeSec >= candidate.startSeconds && timeSec <= candidate.endSeconds) {
        return candidate;
      }
    }

    // Check with smooth 0.3s tolerance if in a tiny gap between cues
    const candidate = this.cues[this.currentIndex];
    if (candidate) {
      const nextCue = this.cues[this.currentIndex + 1];
      const maxExtend = nextCue ? Math.min(candidate.endSeconds + 0.3, nextCue.startSeconds) : candidate.endSeconds + 0.3;
      if (timeSec >= candidate.startSeconds && timeSec <= maxExtend) {
        return candidate;
      }
    }

    return null;
  }

  public reset(): void {
    this.currentIndex = 0;
  }
}

/**
 * Word-wrapping utility with auto-fit font size bounds
 */
export function wrapSubtitleText(
  ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  text: string,
  maxWidth: number,
  initialFontSize: number,
  fontFamily: string,
  minFontSizeRatio: number = 0.75
): { lines: string[]; fontSize: number; maxLineWidth: number } {
  let currentFontSize = initialFontSize;
  const minFontSize = Math.max(12, Math.round(initialFontSize * minFontSizeRatio));

  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) {
    return { lines: [], fontSize: initialFontSize, maxLineWidth: 0 };
  }

  while (currentFontSize >= minFontSize) {
    ctx.font = `bold ${currentFontSize}px ${fontFamily}`;
    const lines: string[] = [];
    let currentLine = words[0];
    let fits = true;
    let maxLineWidth = 0;

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const testLine = `${currentLine} ${word}`;
      const width = ctx.measureText(testLine).width;

      if (width <= maxWidth) {
        currentLine = testLine;
      } else {
        const lineW = ctx.measureText(currentLine).width;
        if (lineW > maxLineWidth) maxLineWidth = lineW;
        lines.push(currentLine);
        currentLine = word;

        // Check if single word itself exceeds maxWidth
        if (ctx.measureText(word).width > maxWidth) {
          fits = false;
          break;
        }
      }
    }

    if (currentLine) {
      const lineW = ctx.measureText(currentLine).width;
      if (lineW > maxLineWidth) maxLineWidth = lineW;
      lines.push(currentLine);
    }

    // Limit maximum lines per subtitle cue frame to 3
    if (fits && lines.length <= 3 && maxLineWidth <= maxWidth) {
      return { lines, fontSize: currentFontSize, maxLineWidth };
    }

    // Step down font size slightly to fit nicely
    currentFontSize -= 1;
  }

  // Fallback with min font size
  ctx.font = `bold ${minFontSize}px ${fontFamily}`;
  const lines: string[] = [];
  let currentLine = words[0] || '';
  let maxLineWidth = 0;

  for (let i = 1; i < words.length; i++) {
    const testLine = `${currentLine} ${words[i]}`;
    if (ctx.measureText(testLine).width <= maxWidth) {
      currentLine = testLine;
    } else {
      const lineW = ctx.measureText(currentLine).width;
      if (lineW > maxLineWidth) maxLineWidth = lineW;
      lines.push(currentLine);
      currentLine = words[i];
    }
  }
  if (currentLine) {
    const lineW = ctx.measureText(currentLine).width;
    if (lineW > maxLineWidth) maxLineWidth = lineW;
    lines.push(currentLine);
  }

  return { lines: lines.slice(0, 3), fontSize: minFontSize, maxLineWidth };
}

/**
 * Computes exact unified layout parameters for a subtitle cue on a given frame resolution
 */
export function computeSubtitleLayout(
  ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  text: string,
  style: SubtitleStyleConfig,
  frameWidth: number,
  frameHeight: number
): ComputedSubtitleLayout {
  const scaleRatio = Math.max(0.4, Math.min(3.0, frameWidth / 800));
  const baseFontSize = Math.round((style.fontSize || 22) * scaleRatio);
  const strokeWidth = style.strokeWidth > 0 && style.strokeColor !== 'none'
    ? Math.max(1, Math.round(style.strokeWidth * scaleRatio))
    : 0;

  const fontDefs = getFontFamilyDefinitions(style.fontFamily);
  const maxAvailableTextWidth = Math.round(frameWidth * 0.88);

  const { lines, fontSize, maxLineWidth } = wrapSubtitleText(
    ctx,
    text,
    maxAvailableTextWidth,
    baseFontSize,
    fontDefs.canvas
  );

  const lineHeight = Math.round(fontSize * 1.32);
  const totalTextHeight = lines.length * lineHeight;

  const paddingX = Math.round(fontSize * 0.85);
  const paddingY = Math.round(fontSize * 0.45);

  const boxWidth = Math.min(frameWidth * 0.94, maxLineWidth + paddingX * 2);
  const boxHeight = totalTextHeight + paddingY * 2;

  // Position computation
  const posXPercent = style.positionX !== undefined ? style.positionX : 50;
  let posYPercent = style.positionY !== undefined ? style.positionY : (
    style.position === 'top' ? 14 : style.position === 'middle' ? 50 : 82
  );

  const centerX = Math.round(frameWidth * (posXPercent / 100));
  const centerY = Math.round(frameHeight * (posYPercent / 100));

  const boxX = Math.round(centerX - boxWidth / 2);
  const boxY = Math.round(centerY - boxHeight / 2);

  return {
    lines,
    fontSize,
    lineHeight,
    totalWidth: maxLineWidth,
    totalHeight: totalTextHeight,
    paddingX,
    paddingY,
    boxX,
    boxY,
    boxWidth,
    boxHeight,
    fontFamilyCss: fontDefs.css,
    fontFamilyCanvas: fontDefs.canvas,
    scaleRatio,
    strokeWidth,
  };
}

export type SubtitleBoundingBox = [number, number, number, number] | { x: number; y: number; width: number; height: number };

/**
 * Render Subtitle on Canvas (Used identically for WebCodecs Export and High-Res Preview)
 */
export function renderSubtitleOnCanvas(
  ctx: CanvasRenderingContext2D | OffscreenCanvasRenderingContext2D,
  rawSourceVideoOrCanvas: CanvasImageSource | null,
  text: string,
  style: SubtitleStyleConfig,
  frameWidth: number,
  frameHeight: number,
  ocrBox?: SubtitleBoundingBox
): void {
  const cleanText = stripSpeakerPrefix(text);
  if (!cleanText) return;

  const layout = computeSubtitleLayout(ctx, cleanText, style, frameWidth, frameHeight);
  if (layout.lines.length === 0) return;

  const cornerRadius = Math.max(6, Math.round(8 * layout.scaleRatio));

  ctx.save();

  // 1. Regional Blur or Background Box
  if (style.bgStyle === 'blur') {
    // Check if exact OCR region is provided
    let blurX = layout.boxX;
    let blurY = layout.boxY;
    let blurW = layout.boxWidth;
    let blurH = layout.boxHeight;

    if (ocrBox) {
      const pad = Math.round(12 * layout.scaleRatio);
      if (Array.isArray(ocrBox) && ocrBox.length === 4) {
        const [ymin, xmin, ymax, xmax] = ocrBox;
        blurX = Math.max(0, Math.round((xmin / 1000) * frameWidth) - pad);
        blurY = Math.max(0, Math.round((ymin / 1000) * frameHeight) - pad);
        blurW = Math.min(frameWidth - blurX, Math.round(((xmax - xmin) / 1000) * frameWidth) + pad * 2);
        blurH = Math.min(frameHeight - blurY, Math.round(((ymax - ymin) / 1000) * frameHeight) + pad * 2);
      } else if (typeof ocrBox === 'object' && 'x' in ocrBox) {
        const factorX = ocrBox.x <= 1 ? frameWidth : 1;
        const factorY = ocrBox.y <= 1 ? frameHeight : 1;
        blurX = Math.max(0, Math.round(ocrBox.x * factorX) - pad);
        blurY = Math.max(0, Math.round(ocrBox.y * factorY) - pad);
        blurW = Math.min(frameWidth - blurX, Math.round(ocrBox.width * factorX) + pad * 2);
        blurH = Math.min(frameHeight - blurY, Math.round(ocrBox.height * factorY) + pad * 2);
      }
    }

    const blurIntensity = style.blurIntensity !== undefined ? style.blurIntensity : 14;

    // Perform True Regional Blur using Canvas Context Filtering
    if (rawSourceVideoOrCanvas) {
      ctx.save();
      ctx.beginPath();
      if (typeof ctx.roundRect === 'function') {
        ctx.roundRect(blurX, blurY, blurW, blurH, cornerRadius);
      } else {
        ctx.rect(blurX, blurY, blurW, blurH);
      }
      ctx.clip();

      // Apply blur filter only to this clipped region
      ctx.filter = `blur(${Math.max(6, Math.round(blurIntensity * layout.scaleRatio))}px)`;
      ctx.drawImage(rawSourceVideoOrCanvas, 0, 0, frameWidth, frameHeight);
      ctx.restore();
    }

    // Add soft darkened scrim for readability
    ctx.fillStyle = 'rgba(0, 0, 0, 0.32)';
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight, cornerRadius);
    } else {
      ctx.rect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight);
    }
    ctx.fill();

    // Subtle edge border
    ctx.lineWidth = Math.max(1, Math.round(1 * layout.scaleRatio));
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
    ctx.stroke();

  } else if (style.bgStyle === 'black-translucent') {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight, cornerRadius);
    } else {
      ctx.rect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight);
    }
    ctx.fill();

    ctx.lineWidth = Math.max(1, Math.round(1 * layout.scaleRatio));
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
    ctx.stroke();

  } else if (style.bgStyle === 'black-solid') {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.95)';
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight, cornerRadius);
    } else {
      ctx.rect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight);
    }
    ctx.fill();

    ctx.lineWidth = Math.max(1, Math.round(1 * layout.scaleRatio));
    ctx.strokeStyle = 'rgba(39, 39, 42, 0.9)';
    ctx.stroke();

  } else if (style.bgStyle === 'glass') {
    ctx.fillStyle = 'rgba(24, 24, 27, 0.65)';
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') {
      ctx.roundRect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight, cornerRadius);
    } else {
      ctx.rect(layout.boxX, layout.boxY, layout.boxWidth, layout.boxHeight);
    }
    ctx.fill();

    ctx.lineWidth = Math.max(1, Math.round(1.5 * layout.scaleRatio));
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.4)';
    ctx.stroke();
  }

  // 2. Render Text Lines with Stroke & Glow
  ctx.font = `bold ${layout.fontSize}px ${layout.fontFamilyCanvas}`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.lineJoin = 'round';
  ctx.miterLimit = 2;

  const startY = layout.boxY + layout.paddingY + Math.round(layout.fontSize / 2) + Math.round((layout.lineHeight - layout.fontSize) / 2);
  const centerX = layout.boxX + layout.boxWidth / 2;

  // Apply Glow / Shadow
  if (style.glowEffect === 'soft') {
    ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
    ctx.shadowBlur = Math.round(10 * layout.scaleRatio);
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = Math.round(3 * layout.scaleRatio);
  } else if (style.glowEffect === 'neon') {
    ctx.shadowColor = '#06b6d4';
    ctx.shadowBlur = Math.round(16 * layout.scaleRatio);
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
  } else if (style.glowEffect === 'gold') {
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = Math.round(16 * layout.scaleRatio);
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;
  } else if (style.glowEffect === 'intense') {
    ctx.shadowColor = 'rgba(0, 0, 0, 1)';
    ctx.shadowBlur = Math.round(20 * layout.scaleRatio);
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = Math.round(4 * layout.scaleRatio);
  } else {
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
  }

  layout.lines.forEach((line, index) => {
    const lineY = startY + index * layout.lineHeight;

    // Draw stroke / outline
    if (layout.strokeWidth > 0 && style.strokeColor !== 'none') {
      ctx.lineWidth = layout.strokeWidth;
      ctx.strokeStyle = style.strokeColor;
      ctx.strokeText(line, centerX, lineY);
    }

    // Draw main fill text
    ctx.fillStyle = style.textColor || '#FFFFFF';
    ctx.fillText(line, centerX, lineY);
  });

  ctx.restore();
}
