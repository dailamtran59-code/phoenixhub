import React from 'react';
import { SubtitleStyleConfig } from '../types';
import { getFontFamilyDefinitions, stripSpeakerPrefix } from './subtitleRendererCore';

export { stripSpeakerPrefix } from './subtitleRendererCore';

/**
 * Computes CSS styles for Live DOM Preview in VideoPlayer
 * Matches exactly with SubtitleRendererCore canvas rendering
 */
export function computeSubtitleCssStyle(
  config: SubtitleStyleConfig,
  scaleRatio: number = 1
): React.CSSProperties {
  const fontDefs = getFontFamilyDefinitions(config.fontFamily);
  const effectiveFontSize = Math.max(12, Math.round((config.fontSize || 22) * scaleRatio));
  const shadows: string[] = [];

  // Text Outline / Stroke simulation
  if (config.strokeWidth > 0 && config.strokeColor !== 'none') {
    const w = Math.max(1, Math.round(config.strokeWidth * scaleRatio));
    const c = config.strokeColor;
    shadows.push(`-${w}px -${w}px 0 ${c}`);
    shadows.push(`${w}px -${w}px 0 ${c}`);
    shadows.push(`-${w}px ${w}px 0 ${c}`);
    shadows.push(`${w}px ${w}px 0 ${c}`);
    shadows.push(`0 ${w}px 0 ${c}`);
    shadows.push(`0 -${w}px 0 ${c}`);
    shadows.push(`${w}px 0 0 ${c}`);
    shadows.push(`-${w}px 0 0 ${c}`);
  }

  // Glow / Brightness / Shadow effect
  if (config.glowEffect === 'soft') {
    shadows.push(`0 ${Math.round(3 * scaleRatio)}px ${Math.round(10 * scaleRatio)}px rgba(0, 0, 0, 0.95)`);
  } else if (config.glowEffect === 'neon') {
    shadows.push(`0 0 ${Math.round(10 * scaleRatio)}px #06b6d4, 0 0 ${Math.round(20 * scaleRatio)}px #06b6d4`);
  } else if (config.glowEffect === 'gold') {
    shadows.push(`0 0 ${Math.round(10 * scaleRatio)}px #f59e0b, 0 0 ${Math.round(20 * scaleRatio)}px #fbbf24`);
  } else if (config.glowEffect === 'intense') {
    shadows.push(`0 ${Math.round(4 * scaleRatio)}px ${Math.round(20 * scaleRatio)}px rgba(0, 0, 0, 1), 0 0 ${Math.round(15 * scaleRatio)}px rgba(0, 0, 0, 1)`);
  }

  const style: React.CSSProperties = {
    fontFamily: fontDefs.css,
    fontSize: `${effectiveFontSize}px`,
    lineHeight: 1.35,
    color: config.textColor || '#FFFFFF',
    textShadow: shadows.length > 0 ? shadows.join(', ') : 'none',
  };

  if (config.bgStyle === 'blur') {
    const intensity = config.blurIntensity !== undefined ? config.blurIntensity : 14;
    style.backdropFilter = `blur(${Math.max(6, Math.round(intensity * scaleRatio))}px)`;
    style.WebkitBackdropFilter = `blur(${Math.max(6, Math.round(intensity * scaleRatio))}px)`;
    style.backgroundColor = 'rgba(0, 0, 0, 0.32)';
    style.borderColor = 'rgba(255, 255, 255, 0.15)';
  }

  return style;
}

export function computeSubtitleBgClass(bgStyle: SubtitleStyleConfig['bgStyle']): string {
  switch (bgStyle) {
    case 'blur':
      return 'border border-white/15 shadow-2xl';
    case 'black-translucent':
      return 'bg-black/75 border border-white/10 backdrop-blur-sm shadow-2xl';
    case 'black-solid':
      return 'bg-black/95 border border-zinc-800 shadow-2xl';
    case 'glass':
      return 'bg-zinc-900/65 border border-indigo-500/40 backdrop-blur-md shadow-2xl';
    case 'none':
    default:
      return 'bg-transparent border-transparent shadow-none';
  }
}
