import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const tmpDir = '/tmp/test_probe';
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
const videoPath = path.join(tmpDir, 'test.mp4');
execSync(`ffmpeg -y -f lavfi -i testsrc=duration=1:size=320x240:rate=30 ${videoPath}`);

function probeVideo(filePath) {
  return new Promise((resolve, reject) => {
    ffmpeg.ffprobe(filePath, (err, metadata) => {
      if (err) return reject(err);
      const hasVideoStream = metadata && metadata.streams && metadata.streams.some(s => s.codec_type === 'video');
      if (!hasVideoStream) {
        return reject(new Error('Khong tim thấy video stream'));
      }
      resolve(metadata);
    });
  });
}

probeVideo(videoPath)
  .then(meta => console.log('ffprobe OK, duration:', meta.format.duration))
  .catch(err => console.error('ffprobe failed:', err));
